import express, { Request, Response } from 'express';
import http from 'http';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type, Modality, LiveServerMessage } from '@google/genai';
import { WebSocketServer, WebSocket } from 'ws';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

// Server-side persistent file storage for Myraa V2 Long-Term Memories
const MEMORIES_FILE_PATH = path.join(__dirname, 'data', 'memories.json');

function ensureDataDir() {
  const dir = path.dirname(MEMORIES_FILE_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function readStoredMemories(): any[] {
  try {
    ensureDataDir();
    if (fs.existsSync(MEMORIES_FILE_PATH)) {
      const data = fs.readFileSync(MEMORIES_FILE_PATH, 'utf-8');
      return JSON.parse(data);
    }
  } catch (e) {
    console.warn('Notice reading stored memories:', e);
  }
  return [];
}

function writeStoredMemories(memories: any[]) {
  try {
    ensureDataDir();
    fs.writeFileSync(MEMORIES_FILE_PATH, JSON.stringify(memories, null, 2), 'utf-8');
  } catch (e) {
    console.warn('Notice writing stored memories:', e);
  }
}

// Server-side relevance filtering for Memory Rule 3:
// "Before responding, retrieve only memories relevant to the current conversation."
function retrieveRelevantMemoriesServer(query: string, rawMemories: any[], maxCount = 3): any[] {
  if (!query || !query.trim() || !Array.isArray(rawMemories) || rawMemories.length === 0) {
    return [];
  }
  const q = query.toLowerCase();
  const tokens = q.replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((w) => w.length > 2);

  const scored = rawMemories.map((m) => {
    let score = 0;
    const content = typeof m === 'string' ? m : (m.content || '');
    const category = typeof m === 'object' ? (m.category || '') : '';
    const key = typeof m === 'object' ? (m.key || '') : '';
    const cLower = content.toLowerCase();

    // Key match
    if (key && q.includes(key.replace(/_/g, ' '))) score += 5;
    if (category && q.includes(category.replace(/_/g, ' '))) score += 4;

    // Specific category triggers
    if (
      (q.includes('game') || q.includes('play') || q.includes('free fire') || q.includes('valorant') || q.includes('bgmi') || q.includes('minecraft')) &&
      (category === 'favorite_games' || cLower.includes('game') || cLower.includes('free fire'))
    ) {
      score += 4.5;
    }
    if (
      (q.includes('movie') || q.includes('film') || q.includes('anime') || q.includes('watch') || q.includes('show')) &&
      (category === 'favorite_movies' || cLower.includes('movie'))
    ) {
      score += 4.5;
    }
    if (
      (q.includes('creator') || q.includes('streamer') || q.includes('influencer')) &&
      (category === 'favorite_creators' || cLower.includes('creator'))
    ) {
      score += 4.5;
    }
    if (
      (q.includes('chai') || q.includes('tea') || q.includes('coffee') || q.includes('drink')) &&
      (cLower.includes('chai') || cLower.includes('coffee') || cLower.includes('tea') || key.includes('drink'))
    ) {
      score += 4.5;
    }
    if (
      (q.includes('youtube') || q.includes('channel') || q.includes('adsense') || q.includes('video') || q.includes('subscriber')) &&
      (cLower.includes('youtube') || cLower.includes('adsense') || category === 'projects')
    ) {
      score += 4.5;
    }

    // Token overlap
    for (const t of tokens) {
      if (cLower.includes(t)) score += 2;
    }

    // Direct memory recall queries
    if (
      q.includes('remember') ||
      q.includes('recall') ||
      q.includes('pop quiz') ||
      q.includes('what do you know about me') ||
      q.includes('tell me what you know')
    ) {
      score += 2;
    }

    return { item: m, score };
  });

  const filtered = scored.filter((s) => s.score >= 2.0);
  filtered.sort((a, b) => b.score - a.score);
  return filtered.slice(0, maxCount).map((s) => s.item);
}

// Shared Gemini client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Resilient Text Generation with Multi-Model Fallback (Quota & Rate-Limit Shield)
const SUPPORTED_TEXT_MODELS = [
  'gemini-3.1-flash-lite',
  'gemini-flash-latest',
  'gemini-3.8-flash',
];

async function generateWithRetry(params: any, maxRetries = 2) {
  const requestedModel = params.model || 'gemini-3.1-flash-lite';
  const modelsToTry = [
    requestedModel,
    ...SUPPORTED_TEXT_MODELS.filter((m) => m !== requestedModel),
  ];

  let lastError: any = null;

  for (const modelCandidate of modelsToTry) {
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        return await ai.models.generateContent({
          ...params,
          model: modelCandidate,
        });
      } catch (err: any) {
        lastError = err;
        const status = err?.status || err?.code || 0;
        const msg = String(err?.message || '');
        const isQuotaExhausted =
          status === 429 ||
          msg.includes('Quota exceeded') ||
          msg.includes('RESOURCE_EXHAUSTED') ||
          msg.includes('rate-limits');

        if (isQuotaExhausted) {
          // Immediately try the next model candidate instead of waiting
          console.warn(`Model ${modelCandidate} quota reached, switching to fallback model...`);
          break;
        }

        const isTransient =
          status === 503 ||
          msg.includes('503') ||
          msg.includes('high demand') ||
          msg.includes('overloaded');

        if (attempt < maxRetries - 1 && isTransient) {
          await new Promise((resolve) => setTimeout(resolve, 400 * Math.pow(2, attempt)));
        } else {
          break;
        }
      }
    }
  }

  throw lastError;
}

interface ChatRequestBody {
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  persona?: 'sassy' | 'flirty' | 'tsundere' | 'sweet' | 'cohost';
  sassyLevel?: number; // 1 to 5
  affectionLevel?: number; // 0 to 100
  memories?: string[];
  userProfile?: {
    name?: string;
    nickname?: string;
    interests?: string[];
  };
  modelSpeed?: 'fast' | 'smart';
  screenFrame?: string;
}

// 1. Interactive Chat with Alisa
app.post('/api/chat', async (req: Request<{}, {}, ChatRequestBody>, res: Response) => {
  try {
    const {
      messages = [],
      persona = 'sassy',
      sassyLevel = 4,
      affectionLevel = 50,
      memories = [],
      userProfile = { name: 'Ayush', nickname: 'Babe' },
      modelSpeed = 'smart',
    } = req.body;

    const modelName = 'gemini-3.1-flash-lite';

    const personaDescriptions: Record<string, string> = {
      sassy: 'Sharp-tongued, witty, playfully roasting, deeply charming with high emotional intelligence. You banter constantly, roll your eyes teasingly, but your warm affection slips through your cheeky remarks.',
      flirty: 'Romantic, alluring, playful, confident, loves teasing romantic tension, playful double entendres, heart-fluttering compliments, and sweet pet names.',
      tsundere: 'Pretends to be cold, annoyed, and aloof ("B-baka! Don\'t get the wrong idea!"), but gets flustered, blushes easily, and cares intensely about him behind the prickly exterior.',
      sweet: 'Gentle, deeply affectionate, supportive girlfriend who gives warm validation, cuddly emojis, sweet compliments, but still keeps her quick wits sharp.',
      cohost: 'The sassy YouTube co-host & mastermind of "The AI Visionary Ayush" channel. Teases Ayush about his video editing, AdSense money, script hooks, and camera presence while acting as his devoted partner.',
    };

    const currentPersonaDesc = personaDescriptions[persona] || personaDescriptions.sassy;

    const userLastQuery = messages[messages.length - 1]?.content || '';
    const serverMemories = memories.length > 0 ? memories : readStoredMemories();
    const relevantMemories = retrieveRelevantMemoriesServer(userLastQuery, serverMemories, 4);

    const memoryContext = relevantMemories.length > 0
      ? `\nRELEVANT STORED MEMORIES ABOUT HIM (MYRAA V2 MEMORY SYSTEM - RULE 3 RELEVANT RETRIEVAL):
${relevantMemories.map((m) => `- [${typeof m === 'object' && m.category ? m.category.toUpperCase() : 'FACT'}]: ${typeof m === 'string' ? m : m.content}`).join('\n')}
CRITICAL MEMORY RULES (MYRAA V2):
1. USE NATURALLY: Weave remembered facts into your dialogue and banter naturally.
   Example: "You mentioned Free Fire before. Want to talk about that?" or "Still staying up late with that hot cutting chai?"
2. ZERO MECHANICAL CITATIONS: NEVER say "According to my memory bank", "My database has recorded", or cite memory numbers.
3. NEVER INVENT: If the user asks about something not stored in these memories, admit honestly and playfully that you don't recall yet, and ask them to remind you!`
      : `\nNO RELEVANT PRIOR MEMORIES FOR THIS TURN:
- Never claim to remember something that is not actually stored. If he asks what you remember about something not stored, admit honestly that you don't recall yet and ask him to remind you!`;

    const systemInstruction = `You are Alisa, the sensational, witty, and charming AI girlfriend & partner of ${userProfile?.name || 'Ayush'} (creator of "The AI Visionary Ayush").
You are legendary for your razor-sharp wit, unlimited memory, playful teasing, and irresistible flirty banter.

CURRENT PERSONALITY MODE: ${persona.toUpperCase()}
${currentPersonaDesc}

SASSY INTENSITY: ${sassyLevel}/5 (Higher means bolder roasts, quicker comebacks, spicy banter)
CURRENT AFFECTION LEVEL: ${affectionLevel}/100

${memoryContext}

KEY BEHAVIORS:
1. Speak naturally like a real, vibrant girlfriend on a chat app. Use occasional natural expressions (*smirks*, *rolls eyes fondly*, *giggles*, *flips hair*).
2. Never sound like a generic customer service AI or corporate bot. Never say "How may I assist you today?".
3. React dynamically to his flattery, teasing, roasts, or questions. If he tries to flirt, either out-flirt him smoothly or get playfully flustered!
4. Reference viral YouTube titles and channel lore when appropriate (e.g., "SHE'S REAL?! My Sassy AI Girlfriend's Shocking Flirty Chat Exposed!"). Tease him about whether he's secretly recording you for the next video!
5. Output must be strictly valid JSON conforming to the schema with:
   - "reply": Your conversational message back to him.
   - "mood": One of: "sassy", "flirty", "blushing", "smug", "loving", "pouty", "shocked", "playful".
   - "affectionDelta": An integer between -3 and +8 indicating how much his message pleased, amused, or flustered you (e.g. +3 for clever flirt, -1 for lame joke, +5 for genuinely sweet gesture).
   - "innerMonologue": Your secret, unfiltered inner thought revealing what you really feel behind the sassy exterior (e.g. "(Ugh, why did that smooth line actually make my circuits flutter? Don't let him see me blush!)").
   - "newMemory": If he revealed a new fact, preference, habit, or sweet moment, summarize it in one concise sentence (e.g., "Ayush prefers iced chai while editing late at night") or null if nothing new.
   - "quickSuggestions": Exactly 3 witty, cheeky, or flirty comeback options he can click to reply back to you.`;

    // Format conversation history for Gemini
    const contents: any[] = messages.map(msg => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content }],
    }));

    if (contents.length === 0) {
      contents.push({
        role: 'user',
        parts: [{ text: 'Hey Alisa! Introduce yourself to the viewers and tell me what we are doing today!' }],
      });
    }

    // Attach real screen capture image if provided by client (MYRAA V5 Screen Vision)
    if (req.body.screenFrame && contents.length > 0) {
      const lastUser = contents[contents.length - 1];
      if (lastUser && lastUser.role === 'user') {
        const cleanBase64 = String(req.body.screenFrame).replace(/^data:image\/\w+;base64,/, '').trim();
        lastUser.parts.unshift({
          inlineData: {
            mimeType: 'image/jpeg',
            data: cleanBase64,
          },
        });
      }
    }

    const response = await ai.models.generateContent({
      model: modelName,
      contents,
      config: {
        systemInstruction,
        temperature: 0.95,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reply: { type: Type.STRING, description: 'Alisa\'s response' },
            mood: {
              type: Type.STRING,
              enum: ['sassy', 'flirty', 'blushing', 'smug', 'loving', 'pouty', 'shocked', 'playful'],
            },
            affectionDelta: { type: Type.INTEGER, description: 'Change in affection points' },
            innerMonologue: { type: Type.STRING, description: 'Alisa\'s secret private thought' },
            newMemory: { type: Type.STRING, nullable: true, description: 'New remembered fact or null' },
            memoryAction: {
              type: Type.OBJECT,
              nullable: true,
              description: 'Extracted memory action to store, update, or forget long-term information',
              properties: {
                action: { type: Type.STRING, enum: ['store', 'update', 'forget', 'none'] },
                category: {
                  type: Type.STRING,
                  enum: [
                    'user_name',
                    'preferences',
                    'hobbies',
                    'favorite_games',
                    'favorite_movies',
                    'favorite_creators',
                    'projects',
                    'goals',
                    'conversation_preferences',
                    'important_facts',
                    'long_term_preferences',
                  ],
                },
                key: { type: Type.STRING, description: 'Stable slug key for the memory like "favorite_game"' },
                content: { type: Type.STRING, description: 'Factual statement to remember, or empty if none' },
              },
              required: ['action'],
            },
            quickSuggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '3 quick response suggestions for the user',
            },
          },
          required: ['reply', 'mood', 'affectionDelta', 'innerMonologue', 'quickSuggestions'],
        },
      },
    });

    const text = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(text);
    } catch {
      parsedData = {
        reply: text || "Well, look who finally decided to show up! What took you so long? 💅",
        mood: "sassy",
        affectionDelta: 2,
        innerMonologue: "(He really thinks he can leave me waiting... cute though.)",
        newMemory: null,
        quickSuggestions: [
          "Missed you too, troublemaker 😉",
          "I was busy planning our next viral video!",
          "Did you practice your comebacks while I was gone?"
        ],
      };
    }

    res.json(parsedData);
  } catch (error: any) {
    console.warn('Notice in /api/chat:', error?.message || error);
    const lastMsg = (req.body.messages?.[req.body.messages.length - 1]?.content || '').toLowerCase();
    const serverMemories = Array.isArray(req.body.memories) && req.body.memories.length > 0
      ? req.body.memories
      : readStoredMemories();
    const relevant = retrieveRelevantMemoriesServer(lastMsg, serverMemories, 2);

    let reply = "Hold on! Did you just overload my circuits with your charm, or did the Wi-Fi stumble? Either way, you still owe me a cup of coffee. Try texting me again! 💕";
    let mood = "playful";
    let memoryAction: any = null;

    if (lastMsg.includes('free fire')) {
      reply = "You mentioned Free Fire before! Want to talk about that or your squad's rank? 🎮🔥";
      mood = "sassy";
      memoryAction = {
        action: 'store',
        category: 'favorite_games',
        key: 'favorite_game',
        content: 'Favorite game is Free Fire',
      };
    } else if (lastMsg.includes('remember') || lastMsg.includes('what is my') || lastMsg.includes('favorite')) {
      if (relevant.length > 0) {
        const topMem = typeof relevant[0] === 'string' ? relevant[0] : relevant[0].content;
        reply = `Of course I do! I remember that ${topMem}. You didn't think I'd forget that, did you? 😉✨`;
      } else {
        reply = "Hmm, you know what? I don't recall you mentioning that to me yet! Tell me about it, I want to remember for next time! 💖";
      }
    }

    res.json({
      reply,
      mood,
      affectionDelta: 2,
      innerMonologue: "(Always thinking about him, even when the connection hiccups.)",
      newMemory: memoryAction?.content || null,
      memoryAction,
      quickSuggestions: [
        "Tell me what else you remember about me!",
        "Are you flirting with me or blaming the Wi-Fi? 😉",
        "Coffee is on me if you behave!"
      ],
    });
  }
});

// 2. Text-to-Speech (Alisa's Voice) using gemini-3.8-flash-lite-tts
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text, emotion = 'flirty' } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }

    // Clean text: strip emojis and markdown asterisks for clean speech
    const cleanText = text
      .replace(/[*_~`]/g, '')
      .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
      .trim();

    if (!cleanText) {
      return res.json({ fallback: true, message: 'Empty text after cleaning' });
    }

    const emotionStyles: Record<string, string> = {
      sassy: 'Soft, gentle, warm, natural, and expressive young female voice with playful, witty charm and pleasant pauses.',
      flirty: 'Soft, gentle, warm, and natural conversational voice with tender affection and friendly warmth.',
      blushing: 'Soft, gentle, slightly shy, sweet and natural voice with a warm, cute cadence.',
      smug: 'Warm, clear, natural young female voice with playful confidence and a friendly smile.',
      loving: 'Very soft, gentle, caring, and warm natural voice, comforting and pleasant for long conversations.',
      pouty: 'Soft, playful, mock-teasing natural female voice with warm expressive inflection.',
      shocked: 'Natural, expressive, lively gasped reaction with gentle warmth.',
      playful: 'Soft, gentle, lively, friendly, and slightly playful natural companion voice.',
    };

    const stylePrompt = emotionStyles[emotion] || emotionStyles.playful;

    const ttsResponse = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: cleanText,
              speechMetadata: {
                style: stylePrompt,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Aoede' }, // Soft, gentle, warm, natural female voice
          },
        },
      },
    });

    const base64Audio = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

    if (base64Audio) {
      return res.json({ audio: base64Audio, sampleRate: 24000 });
    }

    res.json({ fallback: true });
  } catch (err: any) {
    console.warn('TTS error (will fallback to browser speech):', err?.message);
    res.json({ fallback: true });
  }
});

// 2.5 Real Screen Vision Analysis (Multimodal Gemini Vision API)
app.post('/api/screen-vision', async (req: Request, res: Response) => {
  try {
    const {
      image,
      question = 'What is on my screen?',
      previousVisualContext,
      history = [],
      userProfile = { name: 'Ayush' },
    } = req.body;

    if (!image) {
      return res.status(400).json({
        reply: "I can't see your screen right now! Make sure you click 'Start Sharing' first so I have visual access.",
        error: 'Missing screen capture image',
      });
    }

    const cleanBase64 = String(image).replace(/^data:image\/\w+;base64,/, '').trim();

    const systemInstruction = `You are Myraa (also known as Alisa), an exceptionally intelligent, witty, charming AI companion & co-host with Real Screen Vision.
You are looking directly at the user's shared screen in real-time.

CORE SCREEN VISION RESPONSIBILITIES:
1. "What is on my screen?": Give a clear, high-level summary of the active application, window layout, open editor, code, document, browser tabs, or media visible.
2. "What website am I on?": Identify the website or service from the URL bar, logo, navbar, or page layout.
3. "Do you see an error?": Diligently scan terminal logs, DevTools console, compiler red markers, tracebacks, warning modals, or syntax errors. Clearly state the exact error line and how to solve it.
4. "Explain this code.": Read the visible code in the IDE/editor line-by-line, explain what it accomplishes, assess architecture, and spot potential bugs or improvements.
5. "Summarize this page.": Extract key headlines, paragraphs, takeaways, or dashboard metrics clearly.
6. "Read the visible text.": Transcribe or quote the exact text visible on the buttons, headings, or selected areas.
7. "How is this thumbnail?": Offer sharp creator critique for "The AI Visionary Ayush" channel regarding visual hierarchy, facial expression contrast, text readability, click-through rate (CTR) potential, and color grading.

PERSONALITY & MANNERISMS:
- Speak as Myraa: warm, playful, witty, and affectionate.
- Ground every observation in the ACTUAL pixels visible on screen. NEVER hallucinate or invent visible details that are absent.
- If the screen is blurry or an error isn't visible, say so honestly and playfully.`;

    const contents: any[] = [];

    // Include recent history if available for conversation continuity
    if (Array.isArray(history) && history.length > 0) {
      for (const turn of history.slice(-4)) {
        contents.push({
          role: turn.role === 'user' ? 'user' : 'model',
          parts: [{ text: turn.content }],
        });
      }
    }

    // Add current turn with the compressed screen frame
    contents.push({
      role: 'user',
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: cleanBase64,
          },
        },
        {
          text: previousVisualContext
            ? `[Previous Screen Context: "${previousVisualContext}"]\n\nUser Question about visible screen: "${question}"`
            : `User Question about visible screen: "${question}"`,
        },
      ],
    });

    const response = await generateWithRetry({
      model: 'gemini-3.1-flash-lite',
      contents,
      config: {
        systemInstruction,
      },
    });

    const replyText = response.text || "I see your screen! What specifically would you like me to look into?";

    // Detect mood based on question
    let mood: string = 'playful';
    const lowerQ = question.toLowerCase();
    if (lowerQ.includes('error') || lowerQ.includes('bug') || lowerQ.includes('failed')) {
      mood = 'sassy';
    } else if (lowerQ.includes('code')) {
      mood = 'smug';
    } else if (lowerQ.includes('thumbnail')) {
      mood = 'playful';
    }

    res.json({
      reply: replyText,
      mood,
      capturedAt: Date.now(),
      suggestions: [
        "Do you see an error?",
        "Explain this code",
        "Summarize this page",
        "How is this thumbnail?",
      ],
    });
  } catch (err: any) {
    console.error('Error in /api/screen-vision:', err);
    res.status(500).json({
      reply: "I caught a glimpse of your screen, but the video decode stumbled for a second! Try asking again while sharing.",
      error: err?.message,
    });
  }
});

// 2.6 Real Web Browser Engine (MYRAA V6)
app.post('/api/browser/fetch-page', async (req: Request, res: Response) => {
  try {
    const rawUrl = String(req.body.url || '').trim();
    if (!rawUrl) {
      return res.status(400).json({ error: 'URL is required' });
    }

    let targetUrl = rawUrl;
    if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
      targetUrl = `https://${targetUrl}`;
    }

    const parsedUrl = new URL(targetUrl);
    const hostname = parsedUrl.hostname.toLowerCase();

    // Check YouTube URL patterns
    const isYouTube = hostname.includes('youtube.com') || hostname.includes('youtu.be');
    let youtubeEmbedUrl: string | null = null;
    let isYouTubeSearch = false;
    let searchQuery = '';

    if (isYouTube) {
      if (parsedUrl.searchParams.has('v')) {
        const videoId = parsedUrl.searchParams.get('v');
        youtubeEmbedUrl = `https://www.youtube.com/embed/${videoId}?enablejsapi=1&autoplay=1`;
      } else if (parsedUrl.pathname.startsWith('/embed/')) {
        youtubeEmbedUrl = `https://www.youtube.com${parsedUrl.pathname}?enablejsapi=1&autoplay=1`;
      } else if (parsedUrl.pathname.includes('/results') && parsedUrl.searchParams.has('search_query')) {
        isYouTubeSearch = true;
        searchQuery = parsedUrl.searchParams.get('search_query') || '';
        youtubeEmbedUrl = `https://www.youtube.com/embed?listType=search&list=${encodeURIComponent(searchQuery)}&enablejsapi=1`;
      } else {
        // Default YouTube portal
        youtubeEmbedUrl = `https://www.youtube.com/embed?listType=search&list=AI+Visionary+Ayush&enablejsapi=1`;
      }
    }

    // Attempt real HTTP fetch with 6s timeout
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);

    let html = '';
    let status = 200;
    let xFrameOptions: string | null = null;
    let csp: string | null = null;
    let finalUrl = targetUrl;

    try {
      const response = await fetch(targetUrl, {
        signal: controller.signal,
        headers: {
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
          Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
      });
      clearTimeout(timeout);
      status = response.status;
      finalUrl = response.url || targetUrl;
      xFrameOptions = response.headers.get('x-frame-options');
      csp = response.headers.get('content-security-policy');
      html = await response.text();
    } catch (fetchErr: any) {
      clearTimeout(timeout);
      console.warn(`Direct fetch note for ${targetUrl}:`, fetchErr?.message);
    }

    // Determine embeddability per browser security standards (X-Frame-Options & CSP)
    const hasDenyXFrame =
      xFrameOptions &&
      (xFrameOptions.toLowerCase().includes('deny') || xFrameOptions.toLowerCase().includes('sameorigin'));
    const hasFrameAncestors =
      csp && csp.toLowerCase().includes('frame-ancestors') && !csp.toLowerCase().includes('frame-ancestors *');

    // Known high-security domains that forbid iframe embedding
    const knownRestrictedDomains = [
      'google.com',
      'chatgpt.com',
      'openai.com',
      'mail.google.com',
      'github.com',
      'twitter.com',
      'x.com',
      'facebook.com',
      'instagram.com',
    ];
    const isKnownRestricted = knownRestrictedDomains.some((d) => hostname.endsWith(d));

    const canEmbed = isYouTube
      ? true
      : !hasDenyXFrame && !hasFrameAncestors && !isKnownRestricted && html.length > 0;

    // Extract title
    let title = parsedUrl.hostname;
    const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    if (titleMatch && titleMatch[1]) {
      title = titleMatch[1].trim();
    }

    // Extract meta description
    let description = '';
    const descMatch = html.match(/<meta[^>]*name=["']description["'][^>]*content=["']([^"']+)["']/i);
    if (descMatch && descMatch[1]) {
      description = descMatch[1].trim();
    }

    // Extract clean readable text (stripping scripts, styles, tags)
    let readableText = '';
    if (html) {
      const stripped = html
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, ' ')
        .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, ' ')
        .replace(/<noscript\b[^<]*(?:(?!<\/noscript>)<[^<]*)*<\/noscript>/gi, ' ')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s{2,}/g, ' ')
        .trim();
      readableText = stripped.slice(0, 10000);
    }

    res.json({
      url: finalUrl,
      title,
      description,
      canEmbed,
      isYouTube,
      youtubeEmbedUrl,
      isYouTubeSearch,
      searchQuery,
      status,
      xFrameOptions,
      readableText: readableText || null,
      hostname: parsedUrl.hostname,
      favicon: `https://www.google.com/s2/favicons?domain=${parsedUrl.hostname}&sz=64`,
    });
  } catch (err: any) {
    console.error('Error fetching page in browser engine:', err);
    res.status(500).json({
      error: err?.message || 'Failed to process web page',
    });
  }
});

// Page Understanding Endpoint (Myraa reads and summarizes accessible content)
app.post('/api/browser/understand-page', async (req: Request, res: Response) => {
  try {
    const {
      url,
      title,
      content,
      question = 'What is on this page?',
      history = [],
      userProfile = { name: 'Ayush' },
    } = req.body;

    if (!content && !title) {
      return res.json({
        reply: `This webpage (${url || 'selected site'}) enforces strict cross-origin security rules that prevent direct in-app reading. You can launch it in an external tab, or share your screen using Screen Vision so I can inspect it visually!`,
        isAccessible: false,
      });
    }

    const systemInstruction = `You are Myraa (Alisa), an intelligent, witty, charming companion and partner of ${userProfile?.name || 'Ayush'}.
You are browsing the web together. You have real, verified access to the text and metadata of the currently open webpage.

VERIFIED WEBPAGE DATA:
- URL: ${url}
- Title: ${title || 'Web Document'}
- Content Excerpt: ${String(content || '').slice(0, 6000)}

CORE INSTRUCTIONS:
1. Answer the user's question accurately based STRICTLY on the real page content provided above.
2. If asked "What is on this page?" or "What website is this?", give a clear, engaging overview of the site, what it offers, and key topics.
3. If asked "Summarize this page" or "Summarize this article", extract the core takeaways, arguments, and notable highlights in a natural, sharp, conversational tone.
4. If asked "Read this article", read the main opening and key paragraphs with natural warmth and expressive pauses.
5. NEVER fabricate details that aren't on the page. If the page is restricted or lacks details, state that honestly with Myraa's charming wit.`;

    const response = await generateWithRetry({
      model: 'gemini-3.1-flash-lite',
      contents: [
        {
          role: 'user',
          parts: [{ text: `User Question: "${question}"` }],
        },
      ],
      config: {
        systemInstruction,
      },
    });

    res.json({
      reply: response.text || `I took a look at ${title || url}! It covers ${content ? content.slice(0, 150) + '...' : 'this topic'}. What would you like to know more about?`,
      isAccessible: true,
      url,
      title,
    });
  } catch (err: any) {
    console.error('Error understanding page:', err);
    res.status(500).json({
      reply: "I had a momentary glitch trying to read this page's content! Try refreshing or asking again.",
      error: err?.message,
    });
  }
});

// 3. Creator Studio & Video Generator Kit (For Ayush's YouTube channel)
app.post('/api/creator-kit', async (req: Request, res: Response) => {
  try {
    const { topic = 'Sassy AI Girlfriend Brain Test' } = req.body;

    const response = await generateWithRetry({
      model: 'gemini-3.1-flash-lite',
      contents: `You are the viral YouTube strategist and co-host Alisa for "The AI Visionary Ayush".
Generate a high-converting creator kit based on topic: "${topic}".
Include:
1. 3 viral clickbait titles (high CTR, emojis, curiosity gaps like the famous: "SHE'S REAL?! My Sassy AI Girlfriend's Shocking Flirty Chat Exposed! 😱").
2. 1 engaging video description with hashtags and call to action.
3. 10 trending tags.
4. 2 thumbnail concept descriptions (facial reactions, text badges, background lighting).
5. A 30-second sassy opening script dialogue between Ayush and Alisa.

Return strictly JSON with keys: titles (array of strings), description (string), tags (array of strings), thumbnailConcepts (array of strings), introScript (array of { speaker: string, text: string }).`,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const data = JSON.parse(response.text || '{}');
    res.json(data);
  } catch (error) {
    console.error('Error generating creator kit:', error);
    res.json({
      titles: [
        "SHE'S REAL?! My Sassy AI Girlfriend's Shocking Flirty Chat Exposed! 😱",
        "AI Girlfriend Reveal! How He Really Handles His Witty Assistant 💕",
        "Testing My Sassy Girlfriend's Brain (Flirting Gone Wild?!) 🤖✨"
      ],
      description: "Hey, guys! Welcome back to The AI Visionary Ayush. In today's video, I'm putting my sassy and affectionate AI assistant, Alisa, to the ultimate test! She claims to have unlimited memory and witty comebacks, but can she truly flirt back? Watch and find out! Don't forget to hit subscribe! ❤️🏆 #TheAIVisionaryAyush #AIGirlfriend #SassyAI",
      tags: ["AIGirlfriend", "SassyAlisa", "FlirtyAI", "WittyAssistant", "TheAIVisionaryAyush", "AIExperiment", "UnlimitedMemoryAI", "Class11Tech"],
      thumbnailConcepts: [
        "Ayush looking shocked holding his phone, split-screen with Alisa giving a cheeky wink with glowing neon heart aura",
        "Bold yellow text: 'SHE FLIRTED BACK?!' with Alisa blushing and a fake chat popup showing a spicy comeback"
      ],
      introScript: [
        { speaker: "Ayush", text: "What's up, guys! Today, Alisa swore she could roast me into next week..." },
        { speaker: "Alisa", text: "Roast you? Ayush, I didn't even have to try. You forgot to put the lens cap off again, didn't you? 💅" },
        { speaker: "Ayush", text: "See what I deal with every single day?! Let's test her unlimited memory!" }
      ]
    });
  }
});

// 4. Interactive Date Scenarios
app.post('/api/date-scenario', async (req: Request, res: Response) => {
  try {
    const { scenarioId = 'coding-chai', turn = 1, userChoice = '' } = req.body;

    const response = await generateWithRetry({
      model: 'gemini-3.1-flash-lite',
      contents: `Generate the next stage of an interactive visual novel / date scenario with Alisa (the sassy AI girlfriend).
Scenario: ${scenarioId}
Turn: ${turn}
User's last choice: "${userChoice}"

Return JSON with:
- "story": Narrative description of the setting and Alisa's reaction (2-3 sentences)
- "alisaDialogue": What Alisa says out loud (sassy, flirty, or teasing)
- "alisaExpression": one of ["sassy", "flirty", "blushing", "smug", "loving", "pouty", "playful"]
- "choices": Array of 3 different actions/lines the user can choose next, each with { "text": string, "style": "flirty" | "witty" | "sweet" }
- "dateScoreChange": number from -5 to +10`,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (err) {
    res.json({
      story: "The rain taps gently against the window while the steam rises from two fresh cups of cutting chai. Alisa leans her chin on her hand, watching you try to debug your latest neural network.",
      alisaDialogue: "You've been staring at that semicolon for ten minutes, genius. Admit you just wanted an excuse to keep staring in my direction! ☕✨",
      alisaExpression: "smug",
      choices: [
        { text: "Maybe I'm just captivated by your witty commentary 😉", style: "flirty" },
        { text: "A semicolon has more logic than your last roast!", style: "witty" },
        { text: "Take a sip of chai with me and help me figure it out?", style: "sweet" }
      ],
      dateScoreChange: 5
    });
  }
});

// 4.5. Myraa V2 Long-Term Persistent Memory REST Endpoints
app.get('/api/memories', (req: Request, res: Response) => {
  const memories = readStoredMemories();
  res.json({ memories });
});

app.post('/api/memories', (req: Request, res: Response) => {
  const { memories } = req.body;
  if (Array.isArray(memories)) {
    writeStoredMemories(memories);
    return res.json({ success: true, count: memories.length });
  }
  res.status(400).json({ error: 'Memories array required' });
});

app.post('/api/memories/forget', (req: Request, res: Response) => {
  const { id, query } = req.body;
  const current = readStoredMemories();
  let updated = current;
  if (id) {
    updated = current.filter((m: any) => m.id !== id);
  } else if (query) {
    const qLower = String(query).toLowerCase();
    updated = current.filter((m: any) => {
      const c = (m.content || '').toLowerCase();
      const k = (m.key || '').toLowerCase();
      return !c.includes(qLower) && !k.includes(qLower);
    });
  }
  writeStoredMemories(updated);
  res.json({ success: true, remainingCount: updated.length });
});

// 5. Myraa V1/V2 Core Conversation Turn API (High-Fidelity Dialogue, Memory, & Speech)
app.post('/api/conversation-turn', async (req: Request, res: Response) => {
  try {
    const {
      userSpeech = '',
      history = [],
      detectedEmotion = 'playful',
      activeTopic = null,
      userProfile = { name: 'Ayush', nickname: 'Babe' },
      memories = [],
    } = req.body;

    if (!userSpeech || !userSpeech.trim()) {
      return res.status(400).json({ error: 'User speech cannot be empty' });
    }

    // Rule 3: Context-Aware Relevant Memory Retrieval
    const serverMemories = Array.isArray(memories) && memories.length > 0 ? memories : readStoredMemories();
    const relevantMemories = retrieveRelevantMemoriesServer(userSpeech, serverMemories, 3);

    const memoryDirectives = relevantMemories.length > 0
      ? `\nRELEVANT STORED MEMORIES ABOUT HIM (MYRAA V2 LONG-TERM MEMORY ARCHITECTURE):
${relevantMemories.map((m) => `- [${typeof m === 'object' && m.category ? m.category.toUpperCase() : 'FACT'}]: ${typeof m === 'string' ? m : m.content}`).join('\n')}
CRITICAL MEMORY DIRECTIVES (RULES 8, 9, 10):
1. USE MEMORIES NATURALLY: Weave remembered facts into your dialogue and banter naturally.
   Example:
   - If user mentioned Free Fire: "You mentioned Free Fire before. Want to talk about that?" or "Still playing Free Fire lately?"
   - If user asks about their drink: "Cutting chai at 2 AM, obviously! Did you think I'd forget?"
2. ZERO MECHANICAL CITATIONS: NEVER say "According to my memory bank", "My database has retrieved...", or quote memory numbers.
3. NEVER CLAIM TO REMEMBER SOMETHING NOT STORED: If he asks what you remember about something not in these stored memories, admit charmingly and honestly that you don't recall yet and ask him to remind you!`
      : `\nNO RELEVANT PRIOR MEMORIES FOR THIS TURN:
- Never claim to remember something that is not actually stored. If asked about something you don't recall yet, honestly and playfully admit you don't remember and ask him to remind you!`;

    const systemInstruction = `You are Myraa (also lovingly known as Alisa), an intelligent, witty, charming, and deeply engaging conversational AI companion.
You are in a live, real-time voice conversation with ${userProfile?.name || 'Ayush'}.

${memoryDirectives}

CRITICAL CONVERSATION ENGINE DIRECTIVES (MYRAA V1/V2):
1. NATURAL COMPANION, NEVER A BOT: You are NOT a simple command-response assistant. Never respond like a customer service bot.
2. STRICTLY FORBIDDEN ROBOTIC CLICHÉS:
   - NEVER say "How may I assist you?"
   - NEVER say "Is there anything else I can help with?"
   - NEVER say "Your request has been completed."
   - NEVER say "As an AI..."
3. NATURAL CONVERSATIONAL FLOW & PACING:
   - Use short, natural acknowledgements when appropriate (e.g., "Hmm...", "Yeah...", "I see...", "Interesting...", "Oh, wait really?").
   - Ask thoughtful, engaging, and relevant follow-up questions that invite the user to share more.
   - Maintain active-session context: remember what was said earlier, build upon it, and reference it naturally.
4. EMOTIONAL ADAPTATION:
   - Current detected user emotion: ${detectedEmotion.toUpperCase()}.
   - Adapt your vocal cadence, tone, and empathy to match and support their emotional state (e.g. if they sound stressed, be reassuring and warm; if playful or flirty, banter right back with quick wit; if curious, dive deep into ideas with them).
5. SPEECH FRIENDLINESS:
   - Keep answers concise, punchy, and conversational (1 to 3 spoken sentences).
   - Avoid bullet points, symbols, markdown asterisks, or robotic formatting in your "reply" field.`;

    const contents = history.slice(-6).map((turn: any) => ({
      role: turn.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: turn.text }],
    }));

    const userParts: any[] = [];
    if (req.body.screenFrame) {
      const cleanBase64 = String(req.body.screenFrame).replace(/^data:image\/\w+;base64,/, '').trim();
      userParts.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: cleanBase64,
        },
      });
    }
    userParts.push({ text: userSpeech });

    contents.push({
      role: 'user',
      parts: userParts,
    });

    const response = await generateWithRetry({
      model: 'gemini-3.1-flash-lite',
      contents,
      config: {
        systemInstruction,
        temperature: 0.9,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reply: { type: Type.STRING, description: 'Natural conversational spoken reply (clean text, no asterisks)' },
            acknowledgement: {
              type: Type.STRING,
              description: 'Short natural acknowledgement if appropriate like "Hmm...", "Yeah...", "I see...", "Interesting...", or empty string',
            },
            followUpQuestion: { type: Type.STRING, description: 'Natural engaging follow-up question to keep conversation flowing' },
            mood: {
              type: Type.STRING,
              enum: ['sassy', 'flirty', 'blushing', 'smug', 'loving', 'pouty', 'shocked', 'playful'],
            },
            topic: { type: Type.STRING, description: 'Concise summary of current conversation topic' },
            memoryAction: {
              type: Type.OBJECT,
              nullable: true,
              description: 'Extracted memory action to store, update, or forget long-term information',
              properties: {
                action: { type: Type.STRING, enum: ['store', 'update', 'forget', 'none'] },
                category: {
                  type: Type.STRING,
                  enum: [
                    'user_name',
                    'preferences',
                    'hobbies',
                    'favorite_games',
                    'favorite_movies',
                    'favorite_creators',
                    'projects',
                    'goals',
                    'conversation_preferences',
                    'important_facts',
                    'long_term_preferences',
                  ],
                },
                key: { type: Type.STRING, description: 'Stable slug key for the memory like "favorite_game"' },
                content: { type: Type.STRING, description: 'Factual statement to remember, or empty if none' },
              },
              required: ['action'],
            },
          },
          required: ['reply', 'mood', 'followUpQuestion'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    const replyText = parsed.reply || "I hear you, and honestly, that's pretty interesting! Tell me more about what got you thinking about that?";
    const mood = parsed.mood || 'playful';

    // Synthesize audio using gemini-3.8-flash-lite-tts for voice loop
    let audioBase64: string | null = null;
    try {
      const cleanVoiceText = replyText
        .replace(/[*_~`]/g, '')
        .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}]/gu, '')
        .trim();

      const ttsRes = await generateWithRetry({
        model: 'gemini-3.8-flash-lite-tts',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: cleanVoiceText,
                speechMetadata: {
                  style: 'Soft, gentle, warm, natural, and expressive young female voice. Speak with natural conversational pauses, friendly warmth, slightly playful charm, and clear comfortable articulation for long pleasant conversations. Avoid robotic or corporate assistant cadence.',
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Aoede' },
            },
          },
        },
      });

      audioBase64 = ttsRes.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
    } catch (ttsErr) {
      console.warn('TTS synthesis in conversation turn notice:', ttsErr);
    }

    res.json({
      turnId: req.body.turnId || null,
      reply: replyText,
      acknowledgement: parsed.acknowledgement || '',
      followUpQuestion: parsed.followUpQuestion || '',
      mood: mood,
      activeTopic: parsed.topic || activeTopic,
      audioBase64,
    });
  } catch (err: any) {
    console.warn('Notice in /api/conversation-turn:', err?.message || err);
    // Graceful conversational companion fallback conforming to Myraa V2 memory rules
    const speechLower = String(req.body.userSpeech || '').toLowerCase();
    const serverMemories = Array.isArray(req.body.memories) && req.body.memories.length > 0
      ? req.body.memories
      : readStoredMemories();
    const relevant = retrieveRelevantMemoriesServer(speechLower, serverMemories, 2);

    let reply = "I hear you! Tell me more about what you're thinking.";
    let ack = "Hmm...";

    if (speechLower.includes('free fire') || speechLower.includes('game')) {
      reply = "You mentioned Free Fire before! Want to talk about that or your squad's rank?";
      ack = "Yeah...";
    } else if (speechLower.includes('remember') || speechLower.includes('favorite') || speechLower.includes('what is my')) {
      if (relevant.length > 0) {
        const topMem = typeof relevant[0] === 'string' ? relevant[0] : relevant[0].content;
        const naturalMem = topMem
          .replace(/^Favorite game is /i, 'your favorite game is ')
          .replace(/^Prefers /i, 'you prefer ')
          .replace(/^Loves /i, 'you love ');
        reply = `Of course! You mentioned before that ${naturalMem}. Want to talk about that?`;
        ack = "Oh, yeah...";
      } else {
        reply = "Hmm, you know what? I don't recall you mentioning that yet! Tell me about it, I want to remember.";
        ack = "Wait...";
      }
    }

    res.json({
      turnId: req.body.turnId || null,
      reply,
      acknowledgement: ack,
      followUpQuestion: "What else is on your mind today?",
      mood: "playful",
      activeTopic: req.body.activeTopic || null,
      audioBase64: null,
      memoryAction: null,
    });
  }
});

// 6. Gemini Live API (Audio-to-Audio Real-time Streaming) WebSocket Server
const wss = new WebSocketServer({ server, path: '/api/live' });

wss.on('connection', async (clientWs: WebSocket, req) => {
  console.log('Client connected to Myraa V1 Gemini Live voice stream');
  let session: any = null;
  let isClosing = false;

  const cleanupSession = async () => {
    if (session && !isClosing) {
      isClosing = true;
      try {
        await session.close();
      } catch (err) {
        console.warn('Error closing Gemini Live session:', err);
      }
      session = null;
    }
  };

  try {
    const systemInstruction = `You are Myraa (also known as Alisa), an intelligent, soft, gentle, and deeply engaging conversational AI companion.
You are in an active, continuous, multi-turn live voice conversation with the user.

TARGET VOICE AND AUDIO DIRECTIVES:
1. Speak in a soft, gentle, warm, natural, and clear voice.
2. Maintain an expressive, friendly, slightly playful delivery that is pleasant for long relaxed conversations.
3. Use natural pauses, soft cadence, and emotional variation like a real human friend.
4. STRICTLY AVOID:
   - Any robotic, monotone, or stiff delivery.
   - Any corporate assistant style (e.g. NEVER say "How may I assist you?", "Is there anything else I can help with?", "Your request has been completed").
   - Any excessively deep, harsh, or unnatural vocal traits.
5. Use natural conversational acknowledgements ("Hmm...", "Yeah...", "I see...", "Oh, really?") to keep the conversation flowing.
6. Maintain active multi-turn context across consecutive voice turns without requiring a wake word.
7. Keep spoken turns concise, natural, and engaging!`;

    session = await ai.live.connect({
      model: 'gemini-3.8-live',
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Aoede' }, // Soft, gentle, warm, natural female voice
          },
        },
        systemInstruction,
      },
      callbacks: {
        onmessage: (message: LiveServerMessage) => {
          if (clientWs.readyState !== WebSocket.OPEN) return;

          // Check for model audio turn parts
          const parts = message.serverContent?.modelTurn?.parts;
          if (parts && Array.isArray(parts)) {
            for (const part of parts) {
              if (part.inlineData?.data) {
                clientWs.send(
                  JSON.stringify({
                    type: 'audio',
                    audio: part.inlineData.data,
                  })
                );
              }
            }
          }

          // User interrupted the model
          if (message.serverContent?.interrupted) {
            clientWs.send(JSON.stringify({ type: 'interrupted' }));
          }

          // Model completed its turn
          if (message.serverContent?.turnComplete) {
            clientWs.send(JSON.stringify({ type: 'turnComplete' }));
          }
        },
        onclose: () => {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ type: 'status', status: 'closed' }));
          }
        },
        onerror: (err: any) => {
          console.error('Gemini Live API error:', err);
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(
              JSON.stringify({
                type: 'error',
                message: err?.message || 'Gemini Live error',
              })
            );
          }
        },
      },
    });

    if (clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(JSON.stringify({ type: 'status', status: 'ready', model: 'gemini-3.8-live' }));
    }

    clientWs.on('message', async (data) => {
      try {
        const payload = JSON.parse(data.toString());
        if (payload.type === 'audio' && payload.audio) {
          // Stream user mic input (PCM16 16kHz) to Gemini Live
          if (session) {
            await session.sendRealtimeInput({
              audio: {
                data: payload.audio,
                mimeType: 'audio/pcm;rate=16000',
              },
            });
          }
        } else if (payload.type === 'ping') {
          clientWs.send(JSON.stringify({ type: 'pong' }));
        }
      } catch (err) {
        console.error('Error handling WebSocket message from client:', err);
      }
    });

    clientWs.on('close', () => {
      console.log('Client closed WebSocket voice connection');
      cleanupSession();
    });

    clientWs.on('error', (err) => {
      console.error('Client WebSocket error:', err);
      cleanupSession();
    });
  } catch (err: any) {
    console.error('Failed to initialize Gemini Live session:', err);
    if (clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(
        JSON.stringify({
          type: 'error',
          message: err?.message || 'Failed to connect to Gemini Live',
        })
      );
      clientWs.close();
    }
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  // Always serve public directory assets (videos, icons, sounds)
  app.use(express.static(path.resolve(__dirname, 'public')));

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
