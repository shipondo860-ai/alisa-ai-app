# Alisa APK Installer Module (Android 15 Native Architecture)

This directory contains the production-grade Native Android 15 implementation of the **APK Installer** module for Alisa Voice Assistant.

## Security & Architecture Principles

1. **Strictly Non-Silent**: Android 15 security policies strictly prohibit background or silent APK installations without explicit user intervention.
2. **System PackageInstaller Integrity**: Uses Android's official `PackageInstaller` (`PackageInstaller.Session`) and `FileProvider` Content URI mechanisms (`Intent.ACTION_VIEW` + `FLAG_GRANT_READ_URI_PERMISSION`). Android's system installer verifies cryptographic signatures, Play Protect checks, and target SDK requirements.
3. **Unknown Apps Permission Guard (`android.permission.REQUEST_INSTALL_PACKAGES`)**:
   - Explicitly queries `context.packageManager.canRequestPackageInstalls()`.
   - If denied, directs the user directly to `Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES` with the app's package URI so they can deliberately authorize installation.
4. **Android 15 Specifics (API 35)**:
   - Configured with `compileSdk = 35` and `targetSdk = 35`.
   - Supports `PackageInstaller.SessionParams.setPackageSource(PackageInstaller.PACKAGE_SOURCE_OTHER)` introduced in Android 14+ for transparent installation provenance.
   - Preserves secure content URIs using AndroidX `FileProvider`.

## Web Preview vs Native Separation

- **Web Preview Sandbox**: Web browsers cannot directly invoke Android system `PackageInstaller` sessions or execute native intents without a host wrapper. In preview mode, Alisa parses the APK header/binary manifest on the client, audits the security permissions, enforces the "Install Unknown Apps" permission gate, simulates the authentic Android 15 system package installer confirmation dialog, and registers full audit logs into Alisa's Activity & Audit Log.
- **Native Android Bridge**: When packaged inside the Android app shell, `AndroidInstallerBridge.kt` connects the web UI directly to the native `PackageInstallerHelper.kt`.

## File Structure

- `AndroidManifest.xml`: Declares `REQUEST_INSTALL_PACKAGES`, `FileProvider`, package queries, and `InstallResultReceiver`.
- `res/xml/file_paths.xml`: FileProvider secure storage rules.
- `PackageInstallerHelper.kt`: Implements Android 15 Content URI Intents and `PackageInstaller.Session` streaming.
- `InstallResultReceiver.kt`: Broadcast receiver catching `STATUS_PENDING_USER_ACTION`, `STATUS_SUCCESS`, `STATUS_FAILURE_ABORTED`.
- `AndroidInstallerBridge.kt`: JavaScript interface bridge for WebView communication.
