package com.theaivisionary.alisa

import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.theaivisionary.alisa.installer.InstallResultReceiver
import com.theaivisionary.alisa.installer.PackageInstallerHelper
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class SelectedApkInfo(
    val uri: Uri,
    val localFile: File,
    val fileName: String,
    val fileSizeFormatted: String,
    val packageName: String?,
    val appName: String?,
    val versionName: String?,
    val versionCode: Long?
)

data class AuditLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()),
    val fileName: String,
    val packageName: String?,
    val status: String,
    val details: String
)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            AlisaAppTheme {
                AlisaMainScreen()
            }
        }
    }
}

@Composable
fun AlisaAppTheme(content: @Composable () -> Unit) {
    val darkColors = darkColorScheme(
        primary = Color(0xFF06B6D4),
        secondary = Color(0xFFA855F7),
        background = Color(0xFF0B0F19),
        surface = Color(0xFF131B2E),
        onPrimary = Color.Black,
        onSecondary = Color.White,
        onBackground = Color(0xFFE2E8F0),
        onSurface = Color(0xFFE2E8F0)
    )

    MaterialTheme(
        colorScheme = darkColors,
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlisaMainScreen() {
    var selectedTab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current

    var selectedApk by remember { mutableStateOf<SelectedApkInfo?>(null) }
    var installerStatus by remember { mutableStateOf<String>("idle") }
    var statusMessage by remember { mutableStateOf<String>("") }
    val auditLogs = remember { mutableStateListOf<AuditLogEntry>() }

    var hasUnknownSourcesPermission by remember {
        mutableStateOf(PackageInstallerHelper.canRequestPackageInstalls(context))
    }

    // Register receiver listener for PackageInstaller Session status updates
    DisposableEffect(Unit) {
        InstallResultReceiver.listener = { status, details ->
            installerStatus = status
            statusMessage = details
            selectedApk?.let { apk ->
                auditLogs.add(
                    0,
                    AuditLogEntry(
                        fileName = apk.fileName,
                        packageName = apk.packageName,
                        status = status,
                        details = details
                    )
                )
            }
        }
        onDispose {
            InstallResultReceiver.listener = null
        }
    }

    // System File Picker for APK files only
    val apkPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val apkInfo = extractApkInfo(context, uri)
            if (apkInfo != null) {
                selectedApk = apkInfo
                installerStatus = "APK selected"
                statusMessage = "Verified APK structure for ${apkInfo.fileName}"
                auditLogs.add(
                    0,
                    AuditLogEntry(
                        fileName = apkInfo.fileName,
                        packageName = apkInfo.packageName,
                        status = "APK selected",
                        details = "File picked via Android system picker. Size: ${apkInfo.fileSizeFormatted}"
                    )
                )
            } else {
                installerStatus = "Installation failed"
                statusMessage = "Selected file is not a valid Android APK archive."
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ALISA OS",
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = Color(0xFF06B6D4)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Android 15 Native",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0B0F19)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F172A)
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Download, contentDescription = "Installer") },
                    label = { Text("APK Installer") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF06B6D4),
                        indicatorColor = Color(0xFF1E293B)
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Mic, contentDescription = "Voice Assistant") },
                    label = { Text("Alisa Voice") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFA855F7),
                        indicatorColor = Color(0xFF1E293B)
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.History, contentDescription = "Audit Logs") },
                    label = { Text("Audit & Logs") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF38BDF8),
                        indicatorColor = Color(0xFF1E293B)
                    )
                )
            }
        },
        containerColor = Color(0xFF0B0F19)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> ApkInstallerScreen(
                    selectedApk = selectedApk,
                    installerStatus = installerStatus,
                    statusMessage = statusMessage,
                    hasUnknownSourcesPermission = hasUnknownSourcesPermission,
                    onSelectApk = {
                        // Accept only APK MIME types
                        apkPickerLauncher.launch("application/vnd.android.package-archive")
                    },
                    onRequestUnknownSourcesPermission = {
                        PackageInstallerHelper.openUnknownSourcesSettings(context)
                        hasUnknownSourcesPermission = PackageInstallerHelper.canRequestPackageInstalls(context)
                    },
                    onInstall = {
                        val apk = selectedApk
                        if (apk == null) return@ApkInstallerScreen

                        if (!PackageInstallerHelper.canRequestPackageInstalls(context)) {
                            hasUnknownSourcesPermission = false
                            installerStatus = "Installation failed"
                            statusMessage = "Install unknown apps permission is disabled. Please enable it in Settings."
                            auditLogs.add(
                                0,
                                AuditLogEntry(
                                    fileName = apk.fileName,
                                    packageName = apk.packageName,
                                    status = "Installation failed",
                                    details = "Blocked by Android OS: REQUEST_INSTALL_PACKAGES not granted."
                                )
                            )
                            PackageInstallerHelper.openUnknownSourcesSettings(context)
                            return@ApkInstallerScreen
                        }

                        installerStatus = "Preparing installer..."
                        statusMessage = "Passing APK URI to Android 15 PackageInstaller..."
                        auditLogs.add(
                            0,
                            AuditLogEntry(
                                fileName = apk.fileName,
                                packageName = apk.packageName,
                                status = "Preparing installer...",
                                details = "Initiating system installer intent with FileProvider content URI."
                            )
                        )

                        val result = PackageInstallerHelper.launchPackageInstallerIntent(context, apk.localFile)
                        result.onSuccess {
                            installerStatus = "Waiting for Android confirmation..."
                            statusMessage = "Android PackageInstaller dialog opened. Awaiting user confirmation."
                            auditLogs.add(
                                0,
                                AuditLogEntry(
                                    fileName = apk.fileName,
                                    packageName = apk.packageName,
                                    status = "Waiting for Android confirmation...",
                                    details = "Launched Android system package installer intent."
                                )
                            )
                        }.onFailure { err ->
                            installerStatus = "Installation failed"
                            statusMessage = err.localizedMessage ?: "Failed to launch Android package installer."
                            auditLogs.add(
                                0,
                                AuditLogEntry(
                                    fileName = apk.fileName,
                                    packageName = apk.packageName,
                                    status = "Installation failed",
                                    details = "Error: ${err.message}"
                                )
                            )
                        }
                    },
                    onCancel = {
                        selectedApk?.let { apk ->
                            auditLogs.add(
                                0,
                                AuditLogEntry(
                                    fileName = apk.fileName,
                                    packageName = apk.packageName,
                                    status = "Installation cancelled",
                                    details = "User clicked Cancel button in Alisa installer."
                                )
                            )
                        }
                        selectedApk = null
                        installerStatus = "Installation cancelled"
                        statusMessage = "Installation process cancelled by user."
                    }
                )

                1 -> AlisaVoiceScreen(
                    onOpenInstaller = { selectedTab = 0 }
                )

                2 -> AuditLogsScreen(logs = auditLogs)
            }
        }
    }
}

@Composable
fun ApkInstallerScreen(
    selectedApk: SelectedApkInfo?,
    installerStatus: String,
    statusMessage: String,
    hasUnknownSourcesPermission: Boolean,
    onSelectApk: () -> Unit,
    onRequestUnknownSourcesPermission: () -> Unit,
    onInstall: () -> Unit,
    onCancel: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Download,
                            contentDescription = null,
                            tint = Color(0xFF06B6D4),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Native Android 15 Package Installer",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Official Android package installer integration. No silent installs, strict signature verification, and transparent security audit.",
                        fontSize = 13.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }
        }

        // Unknown Apps Permission Warning
        if (!hasUnknownSourcesPermission) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF451A03)),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(Color(0xFFF59E0B), Color(0xFFD97706)))),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFF59E0B))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Install Unknown Apps Permission Disabled",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFCD34D),
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Android 15 requires explicit user authorization before installing APKs from Alisa. Tap below to enable the permission in Android Settings and return.",
                            fontSize = 12.sp,
                            color = Color(0xFFFDE68A)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onRequestUnknownSourcesPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Open Android Settings", color = Color.Black, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // Main Select APK Button
        item {
            Button(
                onClick = onSelectApk,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF06B6D4)
                )
            ) {
                Icon(
                    Icons.Default.FolderOpen,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Select APK",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            }
        }

        // Selected APK Metadata Card
        if (selectedApk != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "APK Verified & Ready",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF34D399),
                                fontSize = 15.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        MetaRow(label = "File Name", value = selectedApk.fileName)
                        MetaRow(label = "File Size", value = selectedApk.fileSizeFormatted)
                        MetaRow(label = "App Name", value = selectedApk.appName ?: "Unknown")
                        MetaRow(label = "Package Name", value = selectedApk.packageName ?: "Unknown")
                        MetaRow(label = "Version", value = "${selectedApk.versionName ?: "N/A"} (${selectedApk.versionCode ?: 0})")

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action Buttons: Install APK and Cancel
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = onCancel,
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444))
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Cancel", fontWeight = FontWeight.SemiBold)
                            }

                            Button(
                                onClick = onInstall,
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, tint = Color.Black)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Install APK", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Status Card
        if (installerStatus != "idle") {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "STATUS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = installerStatus,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (installerStatus) {
                                "Installation completed" -> Color(0xFF10B981)
                                "Installation failed" -> Color(0xFFEF4444)
                                "Installation cancelled" -> Color(0xFFF59E0B)
                                else -> Color(0xFF06B6D4)
                            }
                        )
                        if (statusMessage.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = statusMessage,
                                fontSize = 13.sp,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetaRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 13.sp, color = Color(0xFF94A3B8))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun AlisaVoiceScreen(onOpenInstaller: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Glowing Voice Orb
        Box(
            modifier = Modifier
                .size(160.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF06B6D4), Color(0xFFA855F7), Color(0xFF0B0F19))
                    )
                )
                .border(2.dp, Color(0xFF06B6D4), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Mic,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(56.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Alisa Live Voice",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Bengali & English Bilingual AI Assistant",
            fontSize = 14.sp,
            color = Color(0xFF94A3B8)
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = onOpenInstaller,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF06B6D4))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Open Native APK Installer", color = Color.White)
        }
    }
}

@Composable
fun AuditLogsScreen(logs: List<AuditLogEntry>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "APK Installation & Security Audit Log",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "Tamper-evident log of all system package installation actions",
                fontSize = 12.sp,
                color = Color(0xFF64748B)
            )
            Spacer(modifier = Modifier.height(6.dp))
        }

        if (logs.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No installation events recorded yet. Select an APK to begin.",
                            color = Color(0xFF64748B),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        } else {
            items(logs, key = { it.id }) { log ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = log.status,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = when (log.status) {
                                    "Installation completed" -> Color(0xFF10B981)
                                    "Installation failed" -> Color(0xFFEF4444)
                                    "Installation cancelled" -> Color(0xFFF59E0B)
                                    else -> Color(0xFF06B6D4)
                                }
                            )
                            Text(
                                text = log.timestamp,
                                fontSize = 11.sp,
                                color = Color(0xFF64748B),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "File: ${log.fileName}",
                            fontSize = 12.sp,
                            color = Color(0xFFE2E8F0)
                        )
                        if (!log.packageName.isNullOrEmpty()) {
                            Text(
                                text = "Package: ${log.packageName}",
                                fontSize = 11.sp,
                                color = Color(0xFF94A3B8),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = log.details,
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Safely extracts metadata from selected APK using Android's PackageManager.
 */
private fun extractApkInfo(context: Context, uri: Uri): SelectedApkInfo? {
    try {
        var displayName = "selected_app.apk"
        var sizeBytes = 0L

        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) displayName = cursor.getString(nameIndex) ?: displayName
                if (sizeIndex != -1) sizeBytes = cursor.getLong(sizeIndex)
            }
        }

        // Copy content stream to cache directory for safe PackageArchive parsing & installation
        val apkDir = File(context.cacheDir, "apks").apply { mkdirs() }
        val localApk = File(apkDir, displayName)

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(localApk).use { output ->
                input.copyTo(output)
            }
        }

        if (sizeBytes == 0L) {
            sizeBytes = localApk.length()
        }

        val sizeFormatted = formatFileSize(sizeBytes)

        // Read package archive info
        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            PackageManager.PackageInfoFlags.of(0)
        } else {
            0
        }

        val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getPackageArchiveInfo(localApk.absolutePath, flags as PackageManager.PackageInfoFlags)
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageArchiveInfo(localApk.absolutePath, 0)
        }

        val packageName = pkgInfo?.packageName
        val versionName = pkgInfo?.versionName
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pkgInfo?.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            pkgInfo?.versionCode?.toLong()
        }

        var appLabel: String? = null
        if (pkgInfo != null) {
            pkgInfo.applicationInfo?.let { appInfo ->
                appInfo.sourceDir = localApk.absolutePath
                appInfo.publicSourceDir = localApk.absolutePath
                appLabel = pm.getApplicationLabel(appInfo).toString()
            }
        }

        return SelectedApkInfo(
            uri = uri,
            localFile = localApk,
            fileName = displayName,
            fileSizeFormatted = sizeFormatted,
            packageName = packageName,
            appName = appLabel ?: packageName,
            versionName = versionName,
            versionCode = versionCode
        )
    } catch (e: Exception) {
        e.printStackTrace()
        return null
    }
}

private fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    val value = bytes / Math.pow(1024.0, digitGroups.toDouble())
    return String.format(Locale.US, "%.1f %s", value, units[digitGroups])
}
