package com.theaivisionary.alisa.installer

import android.content.Context
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import java.io.File
import java.io.FileOutputStream

/**
 * JavaScript interface bridge connecting Alisa Web UI with Android 15 PackageInstaller.
 * Injected into WebView via `webView.addJavascriptInterface(bridge, "AndroidInstallerBridge")`.
 */
class AndroidInstallerBridge(
    private val context: Context,
    private val webView: WebView
) {

    init {
        InstallResultReceiver.listener = { status, detail ->
            postStatusToWeb(status, detail)
        }
    }

    @JavascriptInterface
    fun canRequestPackageInstalls(): Boolean {
        return PackageInstallerHelper.canRequestPackageInstalls(context)
    }

    @JavascriptInterface
    fun openUnknownSourcesSettings() {
        PackageInstallerHelper.openUnknownSourcesSettings(context)
    }

    @JavascriptInterface
    fun installApk(fileName: String, base64Data: String) {
        val apkDir = File(context.cacheDir, "apks").apply { mkdirs() }
        val apkFile = File(apkDir, fileName)

        if (base64Data.isNotEmpty()) {
            val bytes = Base64.decode(base64Data, Base64.DEFAULT)
            FileOutputStream(apkFile).use { it.write(bytes) }
        }

        if (!apkFile.exists() || apkFile.length() == 0L) {
            postStatusToWeb("Installation failed", "APK file could not be prepared.")
            return
        }

        postStatusToWeb("Preparing installer...", "Invoking Android 15 PackageInstaller session...")

        val result = PackageInstallerHelper.launchPackageInstallerIntent(context, apkFile)
        result.onSuccess {
            postStatusToWeb("Waiting for Android confirmation...", "System PackageInstaller opened.")
        }.onFailure { err ->
            postStatusToWeb("Installation failed", err.message ?: "Failed to open package installer.")
        }
    }

    private fun postStatusToWeb(status: String, detail: String) {
        webView.post {
            val escapedStatus = status.replace("'", "\\'")
            val escapedDetail = detail.replace("'", "\\'")
            webView.evaluateJavascript(
                "window.onApkInstallStatusChanged && window.onApkInstallStatusChanged('$escapedStatus', '$escapedDetail');",
                null
            )
        }
    }
}
