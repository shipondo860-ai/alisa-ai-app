package com.theaivisionary.alisa.installer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.util.Log

/**
 * Handles PackageInstaller Session callback events on Android 15.
 * Never performs silent installs - handles the system confirmation dialog handoff.
 */
class InstallResultReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "AlisaApkInstaller"
        var listener: ((status: String, message: String) -> Unit)? = null
    }

    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)
        val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "No details"

        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                // Android OS requires explicit user confirmation.
                // Launch the system installer confirmation screen.
                Log.d(TAG, "Android OS requested user confirmation for package install.")
                val confirmationIntent = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirmationIntent != null) {
                    confirmationIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(confirmationIntent)
                    listener?.invoke("Waiting for Android confirmation...", "Android system installer dialog launched.")
                }
            }

            PackageInstaller.STATUS_SUCCESS -> {
                Log.i(TAG, "Package installed successfully via PackageInstaller.")
                listener?.invoke("Installation completed", "Package successfully installed.")
            }

            PackageInstaller.STATUS_FAILURE_ABORTED -> {
                Log.w(TAG, "Installation cancelled by user or system.")
                listener?.invoke("Installation cancelled", "User cancelled installation in the Android system dialog.")
            }

            PackageInstaller.STATUS_FAILURE_BLOCKED -> {
                Log.e(TAG, "Installation blocked by device policy or parental controls.")
                listener?.invoke("Installation failed", "Installation blocked by Android system policy.")
            }

            PackageInstaller.STATUS_FAILURE_INVALID -> {
                Log.e(TAG, "Invalid package archive or corrupt manifest.")
                listener?.invoke("Installation failed", "Invalid or corrupt APK file.")
            }

            PackageInstaller.STATUS_FAILURE_CONFLICT -> {
                Log.e(TAG, "Signature conflict with existing installed version.")
                listener?.invoke("Installation failed", "Signature mismatch with existing installed app.")
            }

            PackageInstaller.STATUS_FAILURE_STORAGE -> {
                Log.e(TAG, "Insufficient device storage.")
                listener?.invoke("Installation failed", "Insufficient storage space.")
            }

            else -> {
                Log.e(TAG, "Installation failed with status code $status: $message")
                listener?.invoke("Installation failed", "Installation failed: $message")
            }
        }
    }
}
