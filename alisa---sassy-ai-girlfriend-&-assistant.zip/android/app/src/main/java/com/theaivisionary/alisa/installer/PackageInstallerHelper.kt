package com.theaivisionary.alisa.installer

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * Official Android 15 PackageInstaller implementation for Alisa Assistant.
 * Strictly enforces:
 *  1. No silent installation.
 *  2. No security or signature verification bypass.
 *  3. Explicit user confirmation via official Android system package installer.
 *  4. Proper handling of unknown app sources permission (REQUEST_INSTALL_PACKAGES).
 */
object PackageInstallerHelper {

    const val ACTION_INSTALL_COMMIT = "com.theaivisionary.alisa.ACTION_INSTALL_COMMIT"

    /**
     * Checks if Alisa has permission to request package installs on Android 8.0+ / Android 15.
     */
    fun canRequestPackageInstalls(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.packageManager.canRequestPackageInstalls()
        } else {
            true
        }
    }

    /**
     * Directs the user to Android Settings to enable "Install unknown apps" for Alisa.
     */
    fun openUnknownSourcesSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    /**
     * Launch official PackageInstaller using FileProvider Content URI & Intent.ACTION_VIEW.
     * Supported on all Android versions up to Android 15.
     */
    fun launchPackageInstallerIntent(context: Context, apkFile: File): Result<Unit> {
        if (!canRequestPackageInstalls(context)) {
            openUnknownSourcesSettings(context)
            return Result.failure(
                SecurityException("android.permission.REQUEST_INSTALL_PACKAGES is not granted. Prompted settings.")
            )
        }

        return try {
            val authority = "${context.packageName}.fileprovider"
            val contentUri: Uri = FileProvider.getUriForFile(context, authority, apkFile)

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(intent)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Advanced Android 14/15 PackageInstaller.Session API implementation.
     * Streams the APK into a system installation session and requests user confirmation.
     */
    fun installViaPackageInstallerSession(context: Context, apkFile: File): Result<Int> {
        if (!canRequestPackageInstalls(context)) {
            openUnknownSourcesSettings(context)
            return Result.failure(
                SecurityException("Install unknown apps permission is disabled.")
            )
        }

        val packageInstaller = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL).apply {
            // Android 14+ (API 34) and Android 15 (API 35) Package Source configuration
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                setPackageSource(PackageInstaller.PACKAGE_SOURCE_OTHER)
            }
        }

        var sessionId = -1
        try {
            sessionId = packageInstaller.createSession(params)
            val session = packageInstaller.openSession(sessionId)

            val inputStream: InputStream = FileInputStream(apkFile)
            val outputStream: OutputStream = session.openWrite("alisa_apk_install", 0, apkFile.length())

            inputStream.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                    session.fsync(output)
                }
            }

            // Prepare IntentSender for broadcast callback.
            // Android system will display the system confirmation UI (EXTRA_INTENT) to the user.
            val intent = Intent(context, InstallResultReceiver::class.java).apply {
                action = ACTION_INSTALL_COMMIT
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                sessionId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )

            // Commit session - Android system takes over and verifies signatures & user consent
            session.commit(pendingIntent.intentSender)
            session.close()

            return Result.success(sessionId)
        } catch (e: Exception) {
            if (sessionId != -1) {
                try {
                    packageInstaller.abandonSession(sessionId)
                } catch (_: Exception) {}
            }
            return Result.failure(e)
        }
    }
}
