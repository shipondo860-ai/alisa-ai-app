#!/bin/bash
set -e

IDLE_IMG="src/assets/images/myraa_character_idle_1790433024627.jpg"
THINK_IMG="src/assets/images/myraa_character_thinking_1790433046377.jpg"
TALK_IMG="src/assets/images/myraa_character_talking_1790433067445.jpg"

mkdir -p public public/videos

echo "Generating JUST WAITNG.mp4..."
ffmpeg -y -loop 1 -i "$IDLE_IMG" -t 4 \
  -filter_complex "[0:v]scale=640:640,zoompan=z='1.0+0.02*sin(2*PI*on/100)':d=100:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=640x640,eq=brightness=0.01*sin(2*PI*t/4):contrast=1.02[v]" \
  -map "[v]" -c:v libx264 -pix_fmt yuv420p -profile:v baseline -level 3.0 -movflags +faststart \
  "public/JUST WAITNG.mp4"

echo "Generating ANIMA GIRL THINKING.mp4..."
ffmpeg -y -loop 1 -i "$THINK_IMG" -t 3 \
  -filter_complex "[0:v]scale=640:640,zoompan=z='1.02+0.02*sin(2*PI*on/75)':d=75:x='iw/2-(iw/zoom/2)+3*sin(2*PI*on/75)':y='ih/2-(ih/zoom/2)':s=640x640,eq=brightness=0.02*sin(2*PI*t/3):gamma=1.03[v]" \
  -map "[v]" -c:v libx264 -pix_fmt yuv420p -profile:v baseline -level 3.0 -movflags +faststart \
  "public/ANIMA GIRL THINKING.mp4"

echo "Generating ANIMA GIRL TAKING.mp4..."
ffmpeg -y -loop 1 -i "$TALK_IMG" -t 2.5 \
  -filter_complex "[0:v]scale=640:640,zoompan=z='1.02+0.03*sin(2*PI*on/60)':d=65:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)+3*sin(2*PI*on/60)':s=640x640,eq=contrast=1.03:saturation=1.05[v]" \
  -map "[v]" -c:v libx264 -pix_fmt yuv420p -profile:v baseline -level 3.0 -movflags +faststart \
  "public/ANIMA GIRL TAKING.mp4"

# Also copy to video directory and alternative naming schemes for robustness
cp "public/JUST WAITNG.mp4" "public/videos/JUST WAITNG.mp4"
cp "public/ANIMA GIRL THINKING.mp4" "public/videos/ANIMA GIRL THINKING.mp4"
cp "public/ANIMA GIRL TAKING.mp4" "public/videos/ANIMA GIRL TAKING.mp4"

cp "public/JUST WAITNG.mp4" "public/JUST_WAITNG.mp4"
cp "public/ANIMA GIRL THINKING.mp4" "public/ANIMA_GIRL_THINKING.mp4"
cp "public/ANIMA GIRL TAKING.mp4" "public/ANIMA_GIRL_TAKING.mp4"

echo "ALL VIDEOS GENERATED SUCCESSFULLY!"
ls -lh public/*.mp4
