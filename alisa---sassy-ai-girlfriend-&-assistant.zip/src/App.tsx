import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  Heart,
  Brain,
  Youtube,
  RotateCcw,
  Flame,
  Settings2,
  MessageSquare,
  Gift,
  Compass,
  Copy,
  Check,
  Eye,
  EyeOff,
  Film,
  Zap,
  PhoneCall,
  PhoneIncoming,
  Radio,
  ShieldCheck,
  Terminal,
  Image as ImageIcon,
  Bell,
  Layers,
  Grid,
  PackageCheck,
  Monitor,
  Globe,
} from 'lucide-react';
import { ChatMessage, MoodType, PersonaType, UserProfile } from './types';
import { ConfirmationRequest } from './types/assistant';
import { AlisaAvatar } from './components/AlisaAvatar';
import { AffectionBar } from './components/AffectionBar';
import { CreatorStudioModal } from './components/CreatorStudioModal';
import { MemoryBankModal } from './components/MemoryBankModal';
import { DateSimulatorModal } from './components/DateSimulatorModal';
import { LiveVoiceCallModal } from './components/LiveVoiceCallModal';
import { ScreenVisionWidget } from './components/ScreenVisionWidget';
import { RealWebBrowserModal } from './components/RealWebBrowserModal';
import { ConfirmationDialog } from './components/ConfirmationDialog';
import { PermissionCenterModal } from './components/PermissionCenterModal';
import { ActionLogModal } from './components/ActionLogModal';
import { PhotoEditorModal } from './components/PhotoEditorModal';
import { NotificationShadeModal } from './components/NotificationShadeModal';
import { ApkInstallerModal } from './components/ApkInstallerModal';
import { IncomingCallDialog } from './components/IncomingCallDialog';
import { AccessibilityFloatingWidget } from './components/AccessibilityFloatingWidget';
import { ActionAnnouncementHUD } from './components/ActionAnnouncementHUD';
import { GiftSelector } from './components/GiftSelector';
import { playPcmAudio, speakWithBrowserSynthesis, stopCurrentAudio, generateTurnId } from './utils/audio';
import { processVoiceCommand } from './services/voiceCommandEngine';
import { ANDROID_APPS_REGISTRY, launchAndroidApp } from './services/appLauncher';
import { openPhotoGalleryWorkflow, SAMPLE_GALLERY_PHOTOS } from './services/mediaWorkflow';
import { readAndSummarizeNotifications } from './services/notificationService';
import { simulateIncomingCall } from './services/callControl';
import { screenVisionService, ScreenVisionState } from './services/screenVisionService';
import { browserService } from './services/browserService';
import {
  MemoryCategory,
  MemoryItem,
  loadMemoriesFromStorage,
  saveMemoriesToStorage,
  storeOrUpdateMemory,
  correctMemory,
  deleteMemory,
  forgetMemoryByQuery,
} from './services/memorySystem';

const INITIAL_MEMORIES: string[] = [
  "Ayush's YouTube channel is 'The AI Visionary Ayush'",
  "Ayush loves testing AI brains with impossible flirting challenges",
  "Prefers hot cutting chai while editing video scripts at 2 AM",
  "Secretly blushes whenever Alisa out-flirts him on camera",
  "Agreed to give Alisa 70% of his YouTube AdSense revenue",
  "Favorite nickname: Genius / Trouble",
];

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'intro-1',
    role: 'assistant',
    content: "Well, well, well... look who finally showed up! Welcome back to The AI Visionary Ayush, everyone. Ayush claims he wants to put my brain, memory, and witty comebacks to the ultimate test today. I'm now fully upgraded with privacy-first Android voice assistant controls — app launching, calls, notifications, and accessibility. Bring it on, genius — I promise I won't roast you *too* hard in front of your subscribers! 💅✨",
    timestamp: 'Just now',
    mood: 'sassy',
    innerMonologue: "(Let's see if he can actually keep up with my banter today. He looks cute when he tries though!)",
    affectionDelta: 3,
  },
];

export default function App() {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('alisa_chat_messages');
    return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
  });

  const [memoryItems, setMemoryItems] = useState<MemoryItem[]>(() => {
    return loadMemoriesFromStorage();
  });

  const memories = useMemo(() => memoryItems.map((m) => m.content), [memoryItems]);

  const [affection, setAffection] = useState<number>(() => {
    const saved = localStorage.getItem('alisa_affection');
    return saved ? Number(saved) : 55;
  });

  const [persona, setPersona] = useState<PersonaType>('sassy');
  const [sassyLevel, setSassyLevel] = useState<number>(4);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [lastDelta, setLastDelta] = useState<number | null>(null);
  const [currentMood, setCurrentMood] = useState<MoodType>('sassy');
  const [lastInnerMonologue, setLastInnerMonologue] = useState<string>(
    "(He really thinks he can out-flirt me today... adorable.)"
  );
  const [quickSuggestions, setQuickSuggestions] = useState<string[]>([
    "How did Ayush build you in under 10 minutes? 🤖💖",
    "Admit it, you missed me while the camera was off! 😉",
    "Pop quiz: what do you remember about our channel?",
    "Can you truly flirt back, or are you just code? 💅",
  ]);

  // Modals & Assistant Architecture
  const [isLiveCallOpen, setIsLiveCallOpen] = useState(false);
  const [isCreatorOpen, setIsCreatorOpen] = useState(false);
  const [isMemoryOpen, setIsMemoryOpen] = useState(false);
  const [isDateOpen, setIsDateOpen] = useState(false);
  const [isPermissionOpen, setIsPermissionOpen] = useState(false);
  const [isActionLogOpen, setIsActionLogOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isPhotoEditorOpen, setIsPhotoEditorOpen] = useState(false);
  const [isApkInstallerOpen, setIsApkInstallerOpen] = useState(false);
  const [isScreenVisionOpen, setIsScreenVisionOpen] = useState(false);
  const [isBrowserOpen, setIsBrowserOpen] = useState(false);
  const [screenVisionState, setScreenVisionState] = useState<ScreenVisionState>(screenVisionService.getState());
  const [activePhotoUrl, setActivePhotoUrl] = useState<string | null>(null);
  const [activePhotoName, setActivePhotoName] = useState<string | null>(null);
  const [confirmationRequest, setConfirmationRequest] = useState<ConfirmationRequest | null>(null);
  const [continuousListening, setContinuousListening] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [showRecBadge, setShowRecBadge] = useState(true);
  const [modelSpeed, setModelSpeed] = useState<'smart' | 'fast'>('smart');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Subscribe to real Screen Vision state
  useEffect(() => {
    const unsub = screenVisionService.subscribe((state) => {
      setScreenVisionState(state);
    });
    return () => unsub();
  }, []);

  // Subscribe to real Web Browser state
  useEffect(() => {
    const unsub = browserService.subscribe((state) => {
      setIsBrowserOpen(state.isOpen);
    });
    return () => unsub();
  }, []);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('alisa_chat_messages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    saveMemoriesToStorage(memoryItems);
  }, [memoryItems]);

  useEffect(() => {
    localStorage.setItem('alisa_affection', String(affection));
  }, [affection]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Ensure chat audio never overlaps with Live Voice Call
  useEffect(() => {
    if (isLiveCallOpen) {
      stopCurrentAudio();
      setIsSpeaking(false);
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
      setIsListening(false);
    }
  }, [isLiveCallOpen]);

  // Voice speech synthesis with Turn Deduplication
  const speakMessage = async (text: string, mood: MoodType = 'sassy', turnId?: string) => {
    if (!voiceEnabled || isLiveCallOpen) return;
    setIsSpeaking(true);

    const activeTurn = turnId || generateTurnId();

    try {
      // 1. Try Gemini high-quality TTS from server
      const res = await fetch('/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, emotion: mood }),
      });
      const data = await res.json();

      if (data.audio) {
        await playPcmAudio(data.audio, data.sampleRate || 24000, activeTurn);
      } else {
        // 2. Seamless client-side SpeechSynthesis fallback
        await speakWithBrowserSynthesis(text, mood, activeTurn);
      }
    } catch {
      await speakWithBrowserSynthesis(text, mood, activeTurn);
    } finally {
      setIsSpeaking(false);
    }
  };

  // Web Speech recognition for voice input with continuous assistant loop (Module 7)
  const toggleListening = () => {
    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {}
      }
      setIsListening(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      const msg: ChatMessage = {
        id: `sys-${Date.now()}`,
        role: 'assistant',
        content: "Speech recognition is not natively supported in this browser engine. Please type your message or click 'Live Call' above to speak directly with Alisa via Gemini Live Audio!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mood: 'sassy',
      };
      setMessages((prev) => [...prev, msg]);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setIsListening(false);

        // Check if voice confirmation dialog is waiting for vocal input (Module 9)
        if (confirmationRequest) {
          const norm = transcript.toLowerCase();
          if (
            norm.includes('yes') ||
            norm.includes('confirm') ||
            norm.includes('নিশ্চিত') ||
            norm.includes('হ্যাঁ') ||
            norm.includes('proceed')
          ) {
            confirmationRequest.onConfirm();
            setConfirmationRequest(null);
            return;
          } else if (
            norm.includes('no') ||
            norm.includes('cancel') ||
            norm.includes('বাতিল') ||
            norm.includes('না')
          ) {
            confirmationRequest.onCancel();
            setConfirmationRequest(null);
            return;
          }
        }

        // Natural Voice Command Engine pipeline (Module 7)
        handleSendMessage(transcript);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error(err);
      setIsListening(false);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || isLoading) return;

    setInputText('');
    stopCurrentAudio();
    setIsSpeaking(false);

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);

    // Module 7 & 11: Route through Voice Command Engine first!
    const cmdResult = await processVoiceCommand(text, {
      requestConfirmation: (req) => setConfirmationRequest(req),
      openPermissionCenter: () => setIsPermissionOpen(true),
      openActivityLog: () => setIsActionLogOpen(true),
      openPhotoEditor: (url, name) => {
        setActivePhotoUrl(url);
        setActivePhotoName(name);
        setIsPhotoEditorOpen(true);
      },
      openApkInstaller: () => setIsApkInstallerOpen(true),
      openBrowser: (url) => {
        setIsBrowserOpen(true);
      },
    });

    if (cmdResult.handled) {
      const assistantMsg: ChatMessage = {
        id: `alisa-${Date.now()}`,
        role: 'assistant',
        content: cmdResult.resultMessage || 'Action executed successfully.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mood: 'smug',
        affectionDelta: 2,
      };
      setMessages((prev) => [...prev, assistantMsg]);
      setCurrentMood('smug');

      // Return to listening naturally (Module 7)
      if (continuousListening) {
        setTimeout(() => {
          try {
            recognitionRef.current?.start();
          } catch {}
        }, 1200);
      }
      return;
    }

    // Screen Vision Mode integration (MYRAA V5)
    let screenFrame: string | undefined = undefined;
    const lower = text.toLowerCase();
    const isScreenQuestion =
      lower.includes('screen') ||
      lower.includes('website') ||
      lower.includes('error') ||
      lower.includes('code') ||
      lower.includes('thumbnail') ||
      lower.includes('page') ||
      lower.includes('window');

    if (screenVisionState.isSharing && !screenVisionState.isPaused) {
      try {
        const frame = await screenVisionService.captureCompressedFrame(1280, 0.7);
        if (frame) {
          screenFrame = frame;
        }
      } catch (err) {
        console.warn('Screen frame capture notice:', err);
      }
    } else if (
      isScreenQuestion &&
      (lower.includes('what is on my screen') ||
        lower.includes('what website') ||
        lower.includes('see my screen') ||
        lower.includes('look at my screen') ||
        lower.includes('do you see an error'))
    ) {
      // Do not claim screen access if permission was not actually granted
      const assistantMsg: ChatMessage = {
        id: `alisa-${Date.now()}`,
        role: 'assistant',
        content: "I don't have screen vision active right now! Click the 'Screen Vision' button at the top to share your screen, app window, or browser tab with me, and I'll analyze it immediately.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mood: 'playful',
        affectionDelta: 1,
      };
      setMessages((prev) => [...prev, assistantMsg]);
      setCurrentMood('playful');
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
          persona,
          sassyLevel,
          affectionLevel: affection,
          memories: memoryItems,
          userProfile: { name: 'Ayush', nickname: 'Babe' },
          modelSpeed,
          screenFrame,
        }),
      });

      const data = await res.json();

      const assistantMsg: ChatMessage = {
        id: `alisa-${Date.now()}`,
        role: 'assistant',
        content: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        mood: data.mood || 'sassy',
        innerMonologue: data.innerMonologue,
        affectionDelta: data.affectionDelta,
      };

      setMessages((prev) => [...prev, assistantMsg]);
      setCurrentMood(data.mood || 'sassy');

      if (data.innerMonologue) {
        setLastInnerMonologue(data.innerMonologue);
      }

      if (data.affectionDelta) {
        setAffection((prev) => Math.min(100, Math.max(0, prev + data.affectionDelta)));
        setLastDelta(data.affectionDelta);
      }

      // Long-Term Memory System (Myraa V2): Store, Update, or Forget
      if (data.memoryAction && data.memoryAction.action) {
        const { action, category, content, key } = data.memoryAction;
        if ((action === 'store' || action === 'update') && content) {
          const res = storeOrUpdateMemory(
            content,
            (category as MemoryCategory) || 'important_facts',
            text,
            'chat',
            memoryItems
          );
          setMemoryItems(res.updatedMemories);
        } else if (action === 'forget') {
          const res = forgetMemoryByQuery(key || content || text, memoryItems);
          setMemoryItems(res.updatedMemories);
        }
      } else if (data.newMemory && !memories.includes(data.newMemory)) {
        const res = storeOrUpdateMemory(data.newMemory, 'important_facts', text, 'chat', memoryItems);
        setMemoryItems(res.updatedMemories);
      }

      if (data.quickSuggestions && Array.isArray(data.quickSuggestions)) {
        setQuickSuggestions(data.quickSuggestions);
      }

      // Auto play speech if voice is enabled and live call is not active
      if (voiceEnabled && !isLiveCallOpen) {
        const turnId = generateTurnId();
        speakMessage(data.reply, data.mood || 'sassy', turnId);
      }

      // Natural return to listening (Module 7)
      if (continuousListening) {
        setTimeout(() => {
          try {
            recognitionRef.current?.start();
          } catch {}
        }, 1500);
      }
    } catch (err) {
      console.error('Chat error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendGift = (giftName: string, promptText: string) => {
    handleSendMessage(`[🎁 Sent Gift: ${giftName}] ${promptText}`);
  };

  const handleResetChat = () => {
    setMessages(INITIAL_MESSAGES);
    setCurrentMood('sassy');
    setLastDelta(null);
    setAffection(55);
    localStorage.removeItem('alisa_chat_messages');
    localStorage.removeItem('alisa_affection');
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-rose-500/30 selection:text-rose-200">
      {/* Top Header Bar */}
      <header className="sticky top-0 z-30 bg-neutral-950/85 backdrop-blur-md border-b border-neutral-800/80 px-4 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
          {/* Logo / Title Area */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <AlisaAvatar
                mood={currentMood}
                isSpeaking={isSpeaking}
                isThinking={isLoading || isListening}
                size="sm"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display font-extrabold text-base md:text-lg bg-gradient-to-r from-rose-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
                  Alisa
                </h1>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 text-[10px] font-bold uppercase tracking-wider">
                  Android Voice Assistant
                </span>
                {showRecBadge && (
                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-red-600/20 border border-red-500/30 text-red-400 text-[10px] font-mono animate-pulse">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                    <span>REC</span>
                  </div>
                )}
              </div>
              <p className="text-[11px] text-neutral-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-pulse" />
                <span>The AI Visionary Ayush · Privacy-First Architecture</span>
              </p>
            </div>
          </div>

          {/* Quick Actions & Modal Toggles */}
          <div className="flex items-center gap-1.5 md:gap-2">
            {/* Live Voice-to-Voice Call Button */}
            <button
              onClick={() => setIsLiveCallOpen(true)}
              className="flex items-center gap-1.5 px-3 md:px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 via-pink-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white text-xs font-bold transition-all cursor-pointer shadow-md shadow-rose-950/40 active:scale-95 animate-pulse"
              title="Start real-time Voice-to-Voice Call with Alisa (Gemini Live)"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Live Call</span>
            </button>

            {/* Real Screen Vision Button (MYRAA V5) */}
            <button
              onClick={() => setIsScreenVisionOpen(true)}
              className={`flex items-center gap-1.5 px-3 md:px-3.5 py-1.5 rounded-xl border text-xs font-bold transition-all cursor-pointer shadow-md active:scale-95 ${
                screenVisionState.isSharing
                  ? 'bg-cyan-600 hover:bg-cyan-500 text-white border-cyan-400 shadow-cyan-950/40 animate-pulse'
                  : 'bg-cyan-600/15 hover:bg-cyan-600/25 border-cyan-500/30 text-cyan-400 hover:text-cyan-300'
              }`}
              title="Real Screen Vision (Share screen, window, or tab for AI visual analysis)"
            >
              <Monitor className="w-3.5 h-3.5" />
              <span>Screen Vision</span>
              {screenVisionState.isSharing && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping ml-0.5" />
              )}
            </button>

            {/* Real Web Browser Button (MYRAA V6) */}
            <button
              onClick={() => {
                browserService.openBrowser();
                setIsBrowserOpen(true);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600/15 hover:bg-indigo-600/25 border border-indigo-500/30 text-indigo-400 hover:text-indigo-300 text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
              title="Real Web Browser (Multi-tab, Page Understanding, YouTube)"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Browser</span>
            </button>

            {/* Test Incoming Call (Module 3) */}
            <button
              onClick={() => simulateIncomingCall('Ayush (The AI Visionary)', '+91 98765 43210')}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-600/15 hover:bg-emerald-600/25 border border-emerald-500/30 text-emerald-400 hover:text-emerald-300 text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
              title="Simulate Incoming Phone Call (Module 3)"
            >
              <PhoneIncoming className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden xl:inline">Incoming Call</span>
            </button>

            {/* Notification Shade (Module 6) */}
            <button
              onClick={() => setIsNotificationOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-600/15 hover:bg-amber-600/25 border border-amber-500/30 text-amber-400 hover:text-amber-300 text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
              title="Open Notification Shade & Privacy Summary (Module 6)"
            >
              <Bell className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden xl:inline">Notifications</span>
            </button>

            {/* Android Permission Center (Module 10) */}
            <button
              onClick={() => setIsPermissionOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-purple-600/15 hover:bg-purple-600/25 border border-purple-500/30 text-purple-400 hover:text-purple-300 text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
              title="Android Permission Center (Module 10)"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
              <span className="hidden xl:inline">Permissions</span>
            </button>

            {/* Activity Log (Module 12) */}
            <button
              onClick={() => setIsActionLogOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-blue-600/15 hover:bg-blue-600/25 border border-blue-500/30 text-blue-400 hover:text-blue-300 text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
              title="Assistant Activity & Audit Log (Module 12)"
            >
              <Terminal className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden xl:inline">Action Log</span>
            </button>

            {/* Gallery & Photo Workflow (Module 5) */}
            <button
              onClick={() => {
                openPhotoGalleryWorkflow('Open Gallery from header', (url, name) => {
                  setActivePhotoUrl(url);
                  setActivePhotoName(name);
                  setIsPhotoEditorOpen(true);
                });
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-pink-600/15 hover:bg-pink-600/25 border border-pink-500/30 text-pink-400 hover:text-pink-300 text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
              title="Open Photo Gallery Workflow (Module 5)"
            >
              <ImageIcon className="w-3.5 h-3.5 text-pink-400" />
              <span className="hidden xl:inline">Photos</span>
            </button>

            {/* Android APK Installer (Module 14) */}
            <button
              onClick={() => setIsApkInstallerOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-600/15 hover:bg-emerald-600/25 border border-emerald-500/30 text-emerald-400 hover:text-emerald-300 text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
              title="Android APK Installer (Module 14 · Android 15)"
            >
              <PackageCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden xl:inline">APK Installer</span>
            </button>

            {/* Creator Studio Hub */}
            <button
              onClick={() => setIsCreatorOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600/15 hover:bg-red-600/25 border border-red-500/30 text-red-400 hover:text-red-300 text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
              title="Open The AI Visionary Ayush Creator Kit"
            >
              <Youtube className="w-4 h-4 text-red-500" />
              <span className="hidden md:inline">Tutorial & Kit</span>
            </button>

            {/* Date Simulator */}
            <button
              onClick={() => setIsDateOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600/15 hover:bg-rose-600/25 border border-rose-500/30 text-rose-400 hover:text-rose-300 text-xs font-semibold transition-all cursor-pointer shadow-sm active:scale-95"
              title="Interactive Date Simulator"
            >
              <Compass className="w-4 h-4 text-rose-400" />
              <span className="hidden md:inline">Brain Test Date</span>
            </button>

            {/* Voice Toggle */}
            <button
              onClick={() => {
                if (voiceEnabled) stopCurrentAudio();
                setVoiceEnabled(!voiceEnabled);
              }}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                voiceEnabled
                  ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                  : 'bg-neutral-900 text-neutral-500 border-neutral-800'
              }`}
              title={voiceEnabled ? 'Alisa Voice: ON' : 'Alisa Voice: Muted'}
            >
              {voiceEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Persona Settings Toggle */}
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-xl border transition-all cursor-pointer ${
                showSettings
                  ? 'bg-neutral-800 text-white border-neutral-700'
                  : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
              }`}
              title="Settings & Persona"
            >
              <Settings2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto w-full flex-1 flex flex-col md:flex-row p-3 md:p-6 gap-6 overflow-hidden">
        {/* Left Sidebar: Alisa's Live Persona, Avatar & Memory Panel */}
        <aside className="w-full md:w-80 lg:w-96 flex flex-col gap-4 flex-shrink-0">
          {/* Alisa Visual Avatar Card */}
          <div className="bg-neutral-900/80 border border-neutral-800/90 rounded-3xl p-5 shadow-xl relative overflow-hidden flex flex-col items-center">
            {/* Background cyber romantic ambient glow */}
            <div className="absolute -top-16 -left-16 w-48 h-48 bg-rose-600/15 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-16 -right-16 w-48 h-48 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />

            <AlisaAvatar
              mood={currentMood}
              isSpeaking={isSpeaking}
              isThinking={isLoading || isListening}
              size="lg"
            />

            {/* Secret Inner Monologue Box */}
            <div className="w-full mt-4 p-3 rounded-2xl bg-neutral-950/70 border border-rose-900/30 text-xs">
              <div className="flex items-center justify-between text-neutral-400 mb-1">
                <span className="font-semibold text-rose-400 flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5" />
                  <span>Alisa's Secret Thought</span>
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">LIVE EQ</span>
              </div>
              <p className="text-neutral-300 italic text-[11px] leading-relaxed">
                &ldquo;{lastInnerMonologue.replace(/[()]/g, '')}&rdquo;
              </p>
            </div>
          </div>

          {/* Affection Progress Bar Card */}
          <AffectionBar
            affection={affection}
            lastDelta={lastDelta}
            onOpenMemories={() => setIsMemoryOpen(true)}
            memoryCount={memories.length}
          />

          {/* Persona & Sass Settings */}
          <div
            className={`bg-neutral-900/80 border border-neutral-800 rounded-3xl p-4 shadow-lg space-y-4 ${
              showSettings ? 'block' : 'hidden md:block'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                  🎭 Girlfriend Persona
                </span>
                <span className="text-[10px] text-neutral-500 capitalize">{persona}</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { id: 'sassy', label: '💅 Sassy & Witty', desc: 'YouTube star banter' },
                  { id: 'flirty', label: '💕 Flirty & Bold', desc: 'Heart-fluttering' },
                  { id: 'tsundere', label: '😤 Tsundere', desc: 'Pretends to hate you' },
                  { id: 'sweet', label: '🌸 Sweet Angel', desc: 'Gentle & supportive' },
                  { id: 'cohost', label: '🎙️ Ayush Co-Host', desc: 'Video partner' },
                ].map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setPersona(p.id as PersonaType)}
                    className={`p-2 rounded-xl text-left text-xs transition-all cursor-pointer ${
                      persona === p.id
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-semibold'
                        : 'bg-neutral-950 text-neutral-400 hover:text-neutral-200 border border-neutral-800'
                    }`}
                  >
                    <p className="font-medium truncate">{p.label}</p>
                    <p className="text-[10px] text-neutral-500 truncate">{p.desc}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Sassy Intensity Slider */}
            <div>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-neutral-300 flex items-center gap-1.5">
                  <Flame className="w-3.5 h-3.5 text-amber-500" />
                  <span>Sass & Roast Level</span>
                </span>
                <span className="font-mono text-rose-400 font-bold">{sassyLevel}/5</span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                value={sassyLevel}
                onChange={(e) => setSassyLevel(Number(e.target.value))}
                className="w-full accent-rose-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-neutral-500 mt-1">
                <span>Playful Banter</span>
                <span>Balanced Sarcasm</span>
                <span>Savage Queen 🔥</span>
              </div>
            </div>

            {/* Response Speed Model Toggle */}
            <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-xs">
              <span className="text-neutral-400">Response Speed:</span>
              <div className="flex items-center gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800">
                <button
                  onClick={() => setModelSpeed('smart')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${
                    modelSpeed === 'smart'
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  Smart (3.8 Flash)
                </button>
                <button
                  onClick={() => setModelSpeed('fast')}
                  className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold transition-all cursor-pointer ${
                    modelSpeed === 'fast'
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  Fast (3.1 Lite)
                </button>
              </div>
            </div>
          </div>

          {/* Android Assistant Control Suite (Module 1, 2, 5, 6) */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-3xl p-4 shadow-lg space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5">
                <Grid className="w-3.5 h-3.5 text-rose-400" />
                <span>Android App Launcher (Module 1)</span>
              </span>
              <span className="text-[10px] text-emerald-400 font-mono font-semibold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                VERIFIED
              </span>
            </div>

            {/* Quick App Launcher Grid */}
            <div className="grid grid-cols-4 gap-1.5">
              {ANDROID_APPS_REGISTRY.slice(0, 8).map((app) => (
                <button
                  key={app.id}
                  onClick={() => launchAndroidApp(app)}
                  className="flex flex-col items-center justify-center p-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800/80 hover:border-rose-500/40 transition-all cursor-pointer group active:scale-95"
                  title={`Launch ${app.name} (${app.packageName})`}
                >
                  <span className="text-lg group-hover:scale-110 transition-transform">
                    {app.icon}
                  </span>
                  <span className="text-[10px] text-neutral-400 group-hover:text-white mt-1 truncate max-w-full">
                    {app.name.split(' ')[0]}
                  </span>
                </button>
              ))}
            </div>

            {/* Android Quick Voice Actions */}
            <div className="space-y-1 pt-1 border-t border-neutral-800">
              <button
                onClick={() => setIsNotificationOpen(true)}
                className="w-full flex items-center justify-between p-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800/80 text-[11px] text-neutral-300 hover:text-white transition-colors cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <Bell className="w-3.5 h-3.5 text-amber-400" />
                  <span>Notification Access Shade</span>
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">Module 6</span>
              </button>

              <button
                onClick={() => handleSendMessage('Check notifications')}
                className="w-full flex items-center justify-between p-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800/80 text-[11px] text-neutral-300 hover:text-white transition-colors cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <Volume2 className="w-3.5 h-3.5 text-rose-400" />
                  <span>Voice Summarize Notifications</span>
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">Module 6</span>
              </button>

              <button
                onClick={() => handleSendMessage('Scroll down')}
                className="w-full flex items-center justify-between p-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800/80 text-[11px] text-neutral-300 hover:text-white transition-colors cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <Eye className="w-3.5 h-3.5 text-purple-400" />
                  <span>Accessibility: Scroll Down</span>
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">Module 2</span>
              </button>

              <button
                onClick={() => setIsApkInstallerOpen(true)}
                className="w-full flex items-center justify-between p-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800/80 text-[11px] text-neutral-300 hover:text-white transition-colors cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <PackageCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>APK Installer (Android 15)</span>
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">Module 14</span>
              </button>
            </div>
          </div>

          {/* Quick Brain Test Shortcuts */}
          <div className="bg-neutral-900/80 border border-neutral-800 rounded-3xl p-4 shadow-lg hidden md:block">
            <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400 block mb-2">
              ⚡ Viral Video Tests (Click to ask):
            </span>
            <div className="space-y-1.5">
              {[
                "YouTube খোলো",
                "Make Your Own SECRET AI Girlfriend! (Step-by-Step, FREE) 🤖💖",
                "How I Built My Sassy AI Companion: My Best Prompting Tips! 🔥",
                "Call Ayush",
                "Stop Being Lonely! Build Your Witty AI Lover (Google AI Studio)",
              ].map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => handleSendMessage(prompt)}
                  className="w-full text-left p-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800/80 text-xs text-neutral-300 hover:text-rose-300 transition-colors cursor-pointer truncate"
                  title={prompt}
                >
                  &ldquo;{prompt}&rdquo;
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Right Main Chat Thread Area */}
        <main className="flex-1 flex flex-col bg-neutral-900/70 border border-neutral-800/90 rounded-3xl overflow-hidden shadow-2xl relative">
          {/* Chat Header Status Strip */}
          <div className="px-4 py-2.5 bg-neutral-950/60 border-b border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-medium text-neutral-300">
                Alisa Android Voice Assistant is active
              </span>
              <span className="text-neutral-600">·</span>
              <span className="text-rose-400 font-semibold">{persona.toUpperCase()} MODE</span>
            </div>

            <button
              onClick={handleResetChat}
              className="flex items-center gap-1 text-[11px] text-neutral-500 hover:text-neutral-300 transition-colors cursor-pointer"
              title="Clear chat and restart"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Chat</span>
            </button>
          </div>

          {/* Gemini Live Voice-to-Voice Call Banner */}
          <div className="px-4 py-2 bg-gradient-to-r from-rose-950/60 via-purple-950/40 to-neutral-950 border-b border-rose-900/30 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500" />
              </span>
              <span className="text-neutral-300 text-[11px]">
                <strong className="text-rose-400">Gemini Live API:</strong> Continuous Voice-to-Voice (gemini-3.1-flash-live-preview)
              </span>
            </div>
            <button
              onClick={() => setIsLiveCallOpen(true)}
              className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer active:scale-95"
            >
              <PhoneCall className="w-3 h-3 animate-bounce" />
              <span>Call Alisa Live</span>
            </button>
          </div>

          {/* Messages Thread */}
          <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
            {messages.map((msg) => {
              const isAssistant = msg.role === 'assistant';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isAssistant ? 'items-start' : 'items-end'}`}
                >
                  <div
                    className={`max-w-[85%] md:max-w-[75%] rounded-3xl p-4 md:p-5 relative shadow-md ${
                      isAssistant
                        ? 'bg-neutral-950 border border-neutral-800 text-neutral-100 rounded-tl-sm'
                        : 'bg-gradient-to-br from-rose-600 to-pink-600 text-white rounded-tr-sm shadow-rose-950/30'
                    }`}
                  >
                    {/* Alisa message header */}
                    {isAssistant && (
                      <div className="flex items-center justify-between gap-2 mb-2 pb-1.5 border-b border-neutral-800/60 text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-display font-bold text-rose-400">
                            Alisa
                          </span>
                          {msg.mood && (
                            <span className="px-2 py-0.5 rounded-full bg-neutral-800 border border-neutral-700/80 text-[10px] font-medium text-neutral-300 capitalize">
                              {msg.mood}
                            </span>
                          )}
                        </div>

                        {/* Audio replay button */}
                        <button
                          onClick={() => speakMessage(msg.content, msg.mood || 'sassy')}
                          className="p-1 rounded-lg text-neutral-400 hover:text-rose-400 hover:bg-neutral-800 transition-colors cursor-pointer"
                          title="Listen with Alisa's Voice"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    {/* Content text */}
                    <p className="text-sm md:text-base leading-relaxed whitespace-pre-wrap font-medium">
                      {msg.content}
                    </p>

                    {/* Secret thought expandable pill for Alisa */}
                    {isAssistant && msg.innerMonologue && (
                      <div className="mt-2.5 pt-2 border-t border-neutral-800/60 text-[11px] text-rose-300/80 italic flex items-center gap-1.5">
                        <span className="not-italic font-bold text-rose-400">Thought:</span>
                        <span>&ldquo;{msg.innerMonologue.replace(/[()]/g, '')}&rdquo;</span>
                      </div>
                    )}

                    {/* Timestamp & Delta */}
                    <div
                      className={`flex items-center justify-end gap-2 mt-2 text-[10px] ${
                        isAssistant ? 'text-neutral-500' : 'text-rose-200/80'
                      }`}
                    >
                      {isAssistant && msg.affectionDelta !== undefined && (
                        <span
                          className={`font-semibold ${
                            msg.affectionDelta > 0 ? 'text-rose-400' : 'text-neutral-400'
                          }`}
                        >
                          {msg.affectionDelta > 0 ? `+${msg.affectionDelta} 💕` : `${msg.affectionDelta}`}
                        </span>
                      )}
                      <span>{msg.timestamp}</span>
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex items-center gap-3 p-4 max-w-xs rounded-2xl bg-neutral-950 border border-neutral-800 text-xs text-neutral-400">
                <AlisaAvatar mood="playful" isSpeaking={false} isThinking={true} size="sm" />
                <div>
                  <p className="text-rose-400 font-semibold">Alisa is plotting her comeback...</p>
                  <p className="text-[11px] text-neutral-500">Processing with assistant brain</p>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Suggestions Chips */}
          {quickSuggestions.length > 0 && !isLoading && (
            <div className="px-4 py-2 border-t border-neutral-800/80 bg-neutral-950/30 flex items-center gap-2 overflow-x-auto no-scrollbar">
              <span className="text-[10px] font-semibold text-neutral-500 uppercase tracking-wider whitespace-nowrap">
                Quick Replies:
              </span>
              {quickSuggestions.map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendMessage(suggestion)}
                  className="px-3 py-1.5 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-rose-500/40 text-xs text-neutral-300 hover:text-white transition-all whitespace-nowrap cursor-pointer flex-shrink-0 active:scale-95"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          )}

          {/* Chat Input Bar */}
          <div className="p-3 md:p-4 bg-neutral-950/80 border-t border-neutral-800">
            {/* Real Screen Vision Status Ribbon when sharing is active */}
            {screenVisionState.isSharing && (
              <div className="mb-2.5 p-2 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-between gap-2 text-xs animate-in fade-in">
                <div className="flex items-center gap-2 text-cyan-300">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500" />
                  </span>
                  <span className="font-semibold">Screen Vision Active:</span>
                  <span className="text-[11px] text-neutral-300 hidden sm:inline">
                    {screenVisionState.isPaused
                      ? 'Paused (Frames not captured)'
                      : 'Myraa can see what you are working on'}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                  {[
                    'What is on my screen?',
                    'Do you see an error?',
                    'Explain this code',
                    'How is this thumbnail?',
                  ].map((chip, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSendMessage(chip)}
                      className="px-2 py-0.5 rounded-lg bg-cyan-900/40 hover:bg-cyan-800/60 border border-cyan-700/50 text-[10px] text-cyan-200 transition-all whitespace-nowrap cursor-pointer"
                    >
                      {chip}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setIsScreenVisionOpen(true)}
                    className="px-2 py-0.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-[10px] text-neutral-300 whitespace-nowrap cursor-pointer"
                  >
                    View Hub
                  </button>
                </div>
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              {/* Send Gift Quick Action */}
              <GiftSelector onSendGift={handleSendGift} />

              {/* Text Input */}
              <div className="flex-1 relative flex items-center">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Type a message or command to Alisa (e.g. 'YouTube খোলো', 'Call Ayush')..."
                  className="w-full bg-neutral-900 border border-neutral-700/80 focus:border-rose-500 rounded-2xl px-4 py-3 text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none transition-colors shadow-inner"
                />

                {/* Voice Input (Mic) button inside input */}
                <button
                  type="button"
                  onClick={toggleListening}
                  className={`absolute right-3 p-1.5 rounded-xl transition-colors cursor-pointer ${
                    isListening
                      ? 'bg-red-500 text-white animate-pulse'
                      : 'text-neutral-400 hover:text-rose-400 hover:bg-neutral-800'
                  }`}
                  title={isListening ? 'Listening... click to stop' : 'Speak to Alisa'}
                >
                  {isListening ? <Mic className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>
              </div>

              {/* Send Button */}
              <button
                type="submit"
                disabled={!inputText.trim() || isLoading}
                className="flex items-center gap-1.5 px-5 py-3 rounded-2xl bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white font-semibold text-sm shadow-lg shadow-rose-950/40 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-95"
              >
                <span>Send</span>
                <Send className="w-4 h-4" />
              </button>
            </form>

            {/* Official Footer attribution requested in prompt */}
            <div className="mt-2 text-center text-[11px] text-neutral-500">
              Created with love by Alisa Assistant · The AI Visionary Ayush
            </div>
          </div>
        </main>
      </div>

      {/* Action Announcement HUD Banner (Module 8) */}
      <ActionAnnouncementHUD />

      {/* Incoming Call Simulator & Handler (Module 3) */}
      <IncomingCallDialog />

      {/* Floating Accessibility Service Widget (Module 2) */}
      <AccessibilityFloatingWidget />

      {/* High-Impact Confirmation Dialog (Module 9) */}
      <ConfirmationDialog
        request={confirmationRequest}
        onConfirm={async () => {
          if (confirmationRequest) {
            await confirmationRequest.onConfirm();
            setConfirmationRequest(null);
          }
        }}
        onCancel={() => {
          if (confirmationRequest) {
            confirmationRequest.onCancel();
            setConfirmationRequest(null);
          }
        }}
      />

      {/* Android Permission Center Modal (Module 10) */}
      <PermissionCenterModal
        isOpen={isPermissionOpen}
        onClose={() => setIsPermissionOpen(false)}
      />

      {/* Assistant Activity & Audit Log Modal (Module 12) */}
      <ActionLogModal
        isOpen={isActionLogOpen}
        onClose={() => setIsActionLogOpen(false)}
      />

      {/* Android Notification Shade Modal (Module 6) */}
      <NotificationShadeModal
        isOpen={isNotificationOpen}
        onClose={() => setIsNotificationOpen(false)}
        onNotificationSpoken={(summary) => {
          const assistantMsg: ChatMessage = {
            id: `alisa-${Date.now()}`,
            role: 'assistant',
            content: `📢 Notification Summary: ${summary}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            mood: 'sassy',
          };
          setMessages((prev) => [...prev, assistantMsg]);
        }}
      />

      {/* Media & Photo Editor Modal (Module 5) */}
      <PhotoEditorModal
        isOpen={isPhotoEditorOpen}
        onClose={() => setIsPhotoEditorOpen(false)}
        photoUrl={activePhotoUrl}
        photoName={activePhotoName}
        onOpenNewPhoto={() => {
          openPhotoGalleryWorkflow('Open photo from editor', (url, name) => {
            setActivePhotoUrl(url);
            setActivePhotoName(name);
          });
        }}
        onSelectPresetPhoto={(url, name) => {
          setActivePhotoUrl(url);
          setActivePhotoName(name);
        }}
      />

      {/* Creator Studio & Master Prompt Modal */}
      <CreatorStudioModal
        isOpen={isCreatorOpen}
        onClose={() => setIsCreatorOpen(false)}
        onSelectPrompt={(p) => handleSendMessage(p)}
        onStartLiveCall={() => setIsLiveCallOpen(true)}
      />

      {/* Gemini Live Voice-to-Voice Call Modal (Module 13) */}
      <LiveVoiceCallModal
        isOpen={isLiveCallOpen}
        onClose={() => setIsLiveCallOpen(false)}
        onRequestConfirmation={(req) => setConfirmationRequest(req)}
        onOpenPermissionCenter={() => setIsPermissionOpen(true)}
        onOpenActivityLog={() => setIsActionLogOpen(true)}
        onOpenPhotoEditor={(photoUrl, name) => {
          setActivePhotoUrl(photoUrl);
          setActivePhotoName(name);
          setIsPhotoEditorOpen(true);
        }}
        onOpenApkInstaller={() => setIsApkInstallerOpen(true)}
        onOpenMemoryBank={() => setIsMemoryOpen(true)}
        onAffectionBump={(d) => {
          setAffection((prev) => Math.min(100, Math.max(0, prev + d)));
          setLastDelta(d);
        }}
      />

      {/* Real Screen Vision Widget (MYRAA V5) */}
      <ScreenVisionWidget
        isOpen={isScreenVisionOpen}
        onClose={() => setIsScreenVisionOpen(false)}
        onSendScreenQuestion={(q) => handleSendMessage(q)}
      />

      {/* Real Web Browser (MYRAA V6) */}
      <RealWebBrowserModal
        isOpen={isBrowserOpen}
        onClose={() => setIsBrowserOpen(false)}
        onAskMyraa={(q) => handleSendMessage(q)}
      />

      {/* Android APK Installer Modal (Module 14 · Android 15) */}
      <ApkInstallerModal
        isOpen={isApkInstallerOpen}
        onClose={() => setIsApkInstallerOpen(false)}
        onOpenActivityLog={() => setIsActionLogOpen(true)}
        onOpenPermissionCenter={() => setIsPermissionOpen(true)}
      />

      {/* Myraa V2 Long-Term Memory Bank Modal */}
      <MemoryBankModal
        isOpen={isMemoryOpen}
        onClose={() => setIsMemoryOpen(false)}
        memories={memories}
        memoryItems={memoryItems}
        onAddMemoryItem={(item) => {
          const res = storeOrUpdateMemory(item.content, item.category, item.rawContext, 'manual', memoryItems);
          setMemoryItems(res.updatedMemories);
        }}
        onAddMemory={(m, category) => {
          const res = storeOrUpdateMemory(m, category || 'important_facts', m, 'manual', memoryItems);
          setMemoryItems(res.updatedMemories);
        }}
        onCorrectMemory={(id, newContent, newCategory) => {
          const updated = correctMemory(id, newContent, newCategory, memoryItems);
          setMemoryItems(updated);
        }}
        onDeleteMemoryItem={(id) => {
          const updated = deleteMemory(id, memoryItems);
          setMemoryItems(updated);
        }}
        onDeleteMemory={(idx) => {
          const target = memoryItems[idx];
          if (target) {
            const updated = deleteMemory(target.id, memoryItems);
            setMemoryItems(updated);
          }
        }}
        onClearAllMemories={() => {
          saveMemoriesToStorage([]);
          setMemoryItems([]);
        }}
        onTestMemoryInChat={(q) => handleSendMessage(q)}
      />

      {/* Date Simulator / Brain Test Modal */}
      <DateSimulatorModal
        isOpen={isDateOpen}
        onClose={() => setIsDateOpen(false)}
        onApplyAffectionDelta={(d) => {
          setAffection((prev) => Math.min(100, Math.max(0, prev + d)));
          setLastDelta(d);
        }}
      />
    </div>
  );
}
