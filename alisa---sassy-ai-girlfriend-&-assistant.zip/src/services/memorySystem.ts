/**
 * MYRAA V2 — LONG-TERM MEMORY ARCHITECTURE
 * 
 * Persistent, categorized, privacy-safe memory system.
 * Capabilities:
 * - STORE: Durable facts and preferences
 * - UNDERSTAND: Category assignment, relevance scoring, sensitive data exclusion
 * - RETRIEVE: Context-aware retrieval (Rule 3: only relevant memories)
 * - UPDATE: Key-based upsert avoiding duplicate records (Rule 4)
 * - FORGET: Explicit & automated memory removal (Rule 7)
 * - USE NATURALLY: Seamless integration without mechanical citations (Rules 8, 9, 10)
 */

export type MemoryCategory =
  | 'user_name'
  | 'preferences'
  | 'hobbies'
  | 'favorite_games'
  | 'favorite_movies'
  | 'favorite_creators'
  | 'projects'
  | 'goals'
  | 'conversation_preferences'
  | 'important_facts'
  | 'long_term_preferences';

export interface MemoryItem {
  id: string;
  key: string; // Stable slug for deduplication & update (e.g. 'favorite_game', 'drink_preference')
  category: MemoryCategory;
  content: string; // Plain English factual memory
  rawContext?: string; // Original statement by user
  confidence: number; // 0.0 - 1.0
  createdAt: number;
  updatedAt: number;
  source: 'voice' | 'chat' | 'manual';
  tags: string[];
}

export const MEMORY_CATEGORY_LABELS: Record<MemoryCategory, { label: string; icon: string; desc: string }> = {
  user_name: { label: 'User & Identity', icon: '👤', desc: 'Name, nicknames, and identity details' },
  favorite_games: { label: 'Favorite Games', icon: '🎮', desc: 'Games you play and love' },
  favorite_movies: { label: 'Favorite Movies & Shows', icon: '🎬', desc: 'Films, anime, and series you watch' },
  favorite_creators: { label: 'Favorite Creators', icon: '🎙️', desc: 'YouTube creators, streamers, and influencers' },
  preferences: { label: 'Personal Preferences', icon: '⭐', desc: 'Specific likes, dislikes, and tastes' },
  hobbies: { label: 'Hobbies & Leisure', icon: '🎨', desc: 'Activities, sports, and creative pursuits' },
  projects: { label: 'Projects & Work', icon: '🚀', desc: 'Apps, YouTube channel builds, code, and creations' },
  goals: { label: 'Aspirations & Goals', icon: '🎯', desc: 'Short-term and long-term milestones' },
  conversation_preferences: { label: 'Banter & Style', icon: '💬', desc: 'Preferred conversation tone, banter, and languages' },
  important_facts: { label: 'Important Facts', icon: '📌', desc: 'Core biographical facts and milestones' },
  long_term_preferences: { label: 'Long-term Habits', icon: '☕', desc: 'Dietary, routine, and daily habits' },
};

// Initial verified memory seeds
export const DEFAULT_INITIAL_MEMORIES: MemoryItem[] = [
  {
    id: 'mem_init_1',
    key: 'youtube_channel',
    category: 'projects',
    content: "Ayush's YouTube channel is 'The AI Visionary Ayush'",
    rawContext: "I run The AI Visionary Ayush channel on YouTube.",
    confidence: 1.0,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
    source: 'manual',
    tags: ['youtube', 'channel', 'ai visionary ayush', 'creator'],
  },
  {
    id: 'mem_init_2',
    key: 'flirting_challenge',
    category: 'conversation_preferences',
    content: "Loves testing AI with impossible flirting challenges and witty banter",
    rawContext: "I want to see if you can out-flirt me on camera.",
    confidence: 1.0,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
    source: 'manual',
    tags: ['flirting', 'banter', 'camera', 'personality'],
  },
  {
    id: 'mem_init_3',
    key: 'drink_preference',
    category: 'long_term_preferences',
    content: "Prefers hot cutting chai while editing video scripts at 2 AM",
    rawContext: "I always drink hot cutting chai while editing late at night.",
    confidence: 1.0,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
    source: 'manual',
    tags: ['chai', 'drink', 'editing', 'night'],
  },
  {
    id: 'mem_init_4',
    key: 'blush_reaction',
    category: 'conversation_preferences',
    content: "Secretly blushes whenever out-flirted on camera",
    rawContext: "I don't blush easily!",
    confidence: 0.95,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
    source: 'manual',
    tags: ['blushing', 'flirting', 'banter'],
  },
  {
    id: 'mem_init_5',
    key: 'adsense_deal',
    category: 'important_facts',
    content: "Agreed to give Myraa 70% of his YouTube AdSense revenue",
    rawContext: "We have an ongoing joke deal about sharing AdSense.",
    confidence: 1.0,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
    source: 'manual',
    tags: ['adsense', 'revenue', 'deal', 'youtube'],
  },
  {
    id: 'mem_init_6',
    key: 'user_nicknames',
    category: 'user_name',
    content: "Preferred playful nicknames: Genius or Trouble",
    rawContext: "Call me Genius or Trouble.",
    confidence: 1.0,
    createdAt: 1710000000000,
    updatedAt: 1710000000000,
    source: 'manual',
    tags: ['name', 'nickname', 'genius', 'trouble'],
  },
];

// Memory Rule 2: Strict Sensitive Information Filter
// Never store passwords, credit cards, bank details, API keys, PINs, or SSNs.
export function isSensitiveInformation(text: string): { isSensitive: boolean; reason?: string } {
  const lower = text.toLowerCase();

  // Credit card detection (13-19 digit patterns)
  if (/\b(?:\d[ -]*?){13,19}\b/.test(text)) {
    return { isSensitive: true, reason: 'Credit card / payment account number detected' };
  }

  // Password / credential detection
  if (
    /\b(password|passwd|pin code|cvv|cvc|api[_-]?key|secret[_-]?key|auth[_-]?token|bearer\s+[a-z0-9_-]+)\b/i.test(
      lower
    )
  ) {
    return { isSensitive: true, reason: 'Sensitive security credential or password detected' };
  }

  // Social Security / National ID
  if (/\b\d{3}-\d{2}-\d{4}\b/.test(text) || /\baadhaar\b/i.test(lower)) {
    return { isSensitive: true, reason: 'Government identification number detected' };
  }

  return { isSensitive: false };
}

/**
 * Normalizes a key for update/upsert (e.g. "favorite game" -> "favorite_game")
 */
export function generateMemoryKey(text: string, category: MemoryCategory): string {
  const cleaned = text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, '')
    .trim();

  // Common anchor keys
  if (category === 'favorite_games' || cleaned.includes('game') || cleaned.includes('free fire') || cleaned.includes('valorant') || cleaned.includes('minecraft') || cleaned.includes('pubg') || cleaned.includes('bgmi')) {
    return 'favorite_game';
  }
  if (category === 'favorite_movies' || cleaned.includes('movie') || cleaned.includes('film') || cleaned.includes('anime') || cleaned.includes('show')) {
    return 'favorite_movie';
  }
  if (category === 'favorite_creators' || cleaned.includes('creator') || cleaned.includes('streamer') || cleaned.includes('youtuber')) {
    return 'favorite_creator';
  }
  if (category === 'user_name' || cleaned.includes('my name is') || cleaned.includes('call me')) {
    return 'user_name';
  }
  if (cleaned.includes('chai') || cleaned.includes('coffee') || cleaned.includes('tea') || cleaned.includes('drink')) {
    return 'drink_preference';
  }
  if (cleaned.includes('sleep') || cleaned.includes('wake') || cleaned.includes('routine')) {
    return 'daily_routine';
  }
  if (cleaned.includes('youtube') || cleaned.includes('channel')) {
    return 'youtube_channel';
  }

  // Fallback slug from first 3 words
  const slug = cleaned.split(/\s+/).slice(0, 3).join('_');
  return `${category}_${slug}`;
}

const STORAGE_KEY = 'myraa_long_term_memories_v2';
const LEGACY_STORAGE_KEY = 'alisa_memories';

/**
 * Load memories with fallback to migration from legacy string array
 */
export function loadMemoriesFromStorage(): MemoryItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0] === 'object' && parsed[0].id) {
        return parsed as MemoryItem[];
      }
    }

    // Attempt migration from legacy string array
    const legacyRaw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacyRaw) {
      const legacyStrings: string[] = JSON.parse(legacyRaw);
      if (Array.isArray(legacyStrings) && legacyStrings.length > 0) {
        const migrated: MemoryItem[] = legacyStrings.map((str, idx) => ({
          id: `mem_migrated_${idx}_${Date.now()}`,
          key: generateMemoryKey(str, 'important_facts'),
          category: categorizeText(str),
          content: str,
          confidence: 1.0,
          createdAt: Date.now() - 86400000,
          updatedAt: Date.now() - 86400000,
          source: 'manual',
          tags: extractKeywords(str),
        }));
        saveMemoriesToStorage(migrated);
        return migrated;
      }
    }
  } catch (err) {
    console.warn('Notice loading memories from storage:', err);
  }

  // Save and return initial seeds
  saveMemoriesToStorage(DEFAULT_INITIAL_MEMORIES);
  return DEFAULT_INITIAL_MEMORIES;
}

/**
 * Persist memories to localStorage and sync to server file storage
 */
export function saveMemoriesToStorage(memories: MemoryItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(memories));
    // Keep legacy array in sync for backward compatibility
    localStorage.setItem(LEGACY_STORAGE_KEY, JSON.stringify(memories.map((m) => m.content)));

    // Asynchronously sync to backend endpoint for cross-platform/restart persistence
    fetch('/api/memories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ memories }),
    }).catch(() => {
      // Offline or server not ready; localStorage remains authoritative
    });
  } catch (err) {
    console.warn('Notice saving memories to storage:', err);
  }
}

/**
 * Rule 4: UPDATE existing memory instead of creating duplicates
 */
export function storeOrUpdateMemory(
  newContent: string,
  category: MemoryCategory = 'important_facts',
  rawContext?: string,
  source: 'voice' | 'chat' | 'manual' = 'chat',
  currentMemories?: MemoryItem[]
): { updatedMemories: MemoryItem[]; memoryItem: MemoryItem; action: 'created' | 'updated'; rejectedReason?: string } {
  // Rule 2: Check sensitive information
  const sensitiveCheck = isSensitiveInformation(newContent);
  if (sensitiveCheck.isSensitive) {
    const list = currentMemories || loadMemoriesFromStorage();
    return {
      updatedMemories: list,
      memoryItem: {
        id: '',
        key: '',
        category,
        content: '',
        confidence: 0,
        createdAt: 0,
        updatedAt: 0,
        source,
        tags: [],
      },
      action: 'created',
      rejectedReason: sensitiveCheck.reason,
    };
  }

  const list = [...(currentMemories || loadMemoriesFromStorage())];
  const targetKey = generateMemoryKey(newContent, category);
  const now = Date.now();
  const tags = extractKeywords(newContent);

  // Check if an existing memory shares the same key or near identical content
  const existingIndex = list.findIndex(
    (m) =>
      m.key === targetKey ||
      (m.category === category && isSemanticKeyMatch(m.content, newContent))
  );

  let resultItem: MemoryItem;
  let action: 'created' | 'updated';

  if (existingIndex >= 0) {
    // UPDATE existing memory
    const existing = list[existingIndex];
    resultItem = {
      ...existing,
      content: newContent.trim(),
      rawContext: rawContext || existing.rawContext,
      updatedAt: now,
      tags: Array.from(new Set([...existing.tags, ...tags])),
    };
    list[existingIndex] = resultItem;
    action = 'updated';
  } else {
    // CREATE new memory
    resultItem = {
      id: `mem_${now}_${Math.random().toString(36).substring(2, 6)}`,
      key: targetKey,
      category,
      content: newContent.trim(),
      rawContext: rawContext || newContent,
      confidence: 1.0,
      createdAt: now,
      updatedAt: now,
      source,
      tags,
    };
    list.unshift(resultItem);
    action = 'created';
  }

  saveMemoriesToStorage(list);
  return { updatedMemories: list, memoryItem: resultItem, action };
}

/**
 * Rule 6: User corrects a memory
 */
export function correctMemory(
  id: string,
  correctedContent: string,
  correctedCategory?: MemoryCategory,
  currentMemories?: MemoryItem[]
): MemoryItem[] {
  const list = currentMemories || loadMemoriesFromStorage();
  const updated = list.map((item) => {
    if (item.id === id) {
      return {
        ...item,
        content: correctedContent.trim(),
        category: correctedCategory || item.category,
        updatedAt: Date.now(),
        tags: extractKeywords(correctedContent),
      };
    }
    return item;
  });
  saveMemoriesToStorage(updated);
  return updated;
}

/**
 * Rule 7: User deletes a memory
 */
export function deleteMemory(id: string, currentMemories?: MemoryItem[]): MemoryItem[] {
  const list = currentMemories || loadMemoriesFromStorage();
  const filtered = list.filter((m) => m.id !== id);
  saveMemoriesToStorage(filtered);
  return filtered;
}

/**
 * Rule 7: Explicit forget by topic/query (e.g. "Forget my favorite game")
 */
export function forgetMemoryByQuery(
  query: string,
  currentMemories?: MemoryItem[]
): { updatedMemories: MemoryItem[]; forgottenItems: MemoryItem[] } {
  const list = currentMemories || loadMemoriesFromStorage();
  const lowerQuery = query.toLowerCase();

  const toKeep: MemoryItem[] = [];
  const forgotten: MemoryItem[] = [];

  for (const item of list) {
    const itemMatch =
      lowerQuery.includes(item.key) ||
      item.tags.some((t) => lowerQuery.includes(t)) ||
      lowerQuery.includes(item.content.toLowerCase());

    if (itemMatch) {
      forgotten.push(item);
    } else {
      toKeep.push(item);
    }
  }

  if (forgotten.length > 0) {
    saveMemoriesToStorage(toKeep);
  }

  return { updatedMemories: toKeep, forgottenItems: forgotten };
}

/**
 * Rule 3: Context-Aware Memory Retrieval
 * "Before responding, retrieve only memories relevant to the current conversation."
 */
export function retrieveRelevantMemories(
  currentQuery: string,
  allMemories: MemoryItem[],
  maxCount: number = 3
): MemoryItem[] {
  if (!currentQuery || !currentQuery.trim() || allMemories.length === 0) {
    return [];
  }

  const queryLower = currentQuery.toLowerCase();
  const queryTokens = extractKeywords(currentQuery);

  const scored = allMemories.map((mem) => {
    let score = 0;
    const contentLower = mem.content.toLowerCase();
    const keyLower = mem.key.toLowerCase();

    // 1. Direct key match (e.g. query mentions "game" and key is "favorite_game")
    if (queryLower.includes(keyLower.replace(/_/g, ' '))) {
      score += 5;
    }

    // 2. Specific game/show/creator keyword triggers
    if (
      (queryLower.includes('game') || queryLower.includes('play') || queryLower.includes('free fire') || queryLower.includes('valorant') || queryLower.includes('bgmi')) &&
      mem.category === 'favorite_games'
    ) {
      score += 4;
    }
    if (
      (queryLower.includes('movie') || queryLower.includes('film') || queryLower.includes('watch') || queryLower.includes('anime')) &&
      mem.category === 'favorite_movies'
    ) {
      score += 4;
    }
    if (
      (queryLower.includes('chai') || queryLower.includes('tea') || queryLower.includes('coffee') || queryLower.includes('drink')) &&
      (mem.key.includes('drink') || mem.content.toLowerCase().includes('chai') || mem.content.toLowerCase().includes('coffee'))
    ) {
      score += 4;
    }
    if (
      (queryLower.includes('youtube') || queryLower.includes('channel') || queryLower.includes('video') || queryLower.includes('subscriber') || queryLower.includes('adsense')) &&
      (mem.key.includes('youtube') || mem.key.includes('adsense') || mem.category === 'projects')
    ) {
      score += 4;
    }

    // 3. Keyword / tag overlap
    for (const token of queryTokens) {
      if (token.length > 2) {
        if (contentLower.includes(token)) score += 2;
        if (mem.tags.includes(token)) score += 2.5;
      }
    }

    // 4. Memory query triggers ("do you remember", "what is my favorite", "tell me what you know about me")
    if (
      queryLower.includes('remember') ||
      queryLower.includes('know about me') ||
      queryLower.includes('pop quiz') ||
      queryLower.includes('recall')
    ) {
      score += 2; // general recall bonus
    }

    // 5. Recency weighting
    const ageDays = (Date.now() - mem.updatedAt) / (1000 * 60 * 60 * 24);
    if (ageDays < 1) score += 0.5;

    return { mem, score };
  });

  // Filter to memories with genuine relevance threshold (score >= 2.0)
  const filtered = scored.filter((item) => item.score >= 2.0);
  filtered.sort((a, b) => b.score - a.score);

  return filtered.slice(0, maxCount).map((item) => item.mem);
}

/**
 * Format retrieved memories for natural injection into Gemini instructions
 * Enforces Rules 8, 9, 10
 */
export function formatMemoriesForPrompt(memories: MemoryItem[]): string {
  if (memories.length === 0) {
    return 'NO RELEVANT PRIOR MEMORIES FOR THIS TURN.';
  }

  const list = memories
    .map((m) => `- [${m.category.toUpperCase()}]: ${m.content}`)
    .join('\n');

  return `RELEVANT LONG-TERM MEMORIES (RETRIEVED FOR CURRENT CONTEXT):
${list}

CRITICAL RULES ON MEMORY USAGE (MYRAA V2):
1. USE NATURALLY: Weave these memories naturally into banter or questions without being robotic.
   Example: "You mentioned Free Fire before. Want to talk about that?" or "Still staying up late with that hot cutting chai?"
2. ZERO MECHANICAL CITATIONS: NEVER say "According to my memory bank", "My database has recorded", or cite memory numbers.
3. NEVER INVENT: If the user asks about something not stored in these memories, admit honestly and playfully that you don't recall yet, and ask them to remind you!`;
}

// Helpers
function categorizeText(text: string): MemoryCategory {
  const lower = text.toLowerCase();
  if (lower.includes('game') || lower.includes('play') || lower.includes('free fire') || lower.includes('valorant')) return 'favorite_games';
  if (lower.includes('movie') || lower.includes('film') || lower.includes('series') || lower.includes('anime')) return 'favorite_movies';
  if (lower.includes('creator') || lower.includes('streamer') || lower.includes('youtuber')) return 'favorite_creators';
  if (lower.includes('project') || lower.includes('app') || lower.includes('code') || lower.includes('channel')) return 'projects';
  if (lower.includes('goal') || lower.includes('dream') || lower.includes('plan')) return 'goals';
  if (lower.includes('chai') || lower.includes('coffee') || lower.includes('drink') || lower.includes('routine')) return 'long_term_preferences';
  if (lower.includes('call me') || lower.includes('name is') || lower.includes('nickname')) return 'user_name';
  if (lower.includes('banter') || lower.includes('flirt') || lower.includes('roast')) return 'conversation_preferences';
  return 'important_facts';
}

function extractKeywords(text: string): string[] {
  const stopWords = new Set([
    'the', 'is', 'at', 'which', 'on', 'and', 'a', 'an', 'in', 'to', 'for', 'of',
    'with', 'my', 'your', 'his', 'her', 'i', 'you', 'he', 'she', 'it', 'we', 'they',
    'am', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do',
    'does', 'did', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'about',
  ]);

  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 2 && !stopWords.has(w));
}

function isSemanticKeyMatch(a: string, b: string): boolean {
  const tokensA = new Set(extractKeywords(a));
  const tokensB = new Set(extractKeywords(b));
  let overlap = 0;
  for (const t of tokensA) {
    if (tokensB.has(t)) overlap++;
  }
  const minSize = Math.min(tokensA.size, tokensB.size);
  return minSize > 0 && overlap / minSize >= 0.6;
}
