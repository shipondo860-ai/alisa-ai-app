/**
 * MYRAA V6 — REAL WEB BROWSER SERVICE
 * 
 * Manages real multi-tab browsing state, history, URL navigation,
 * cross-origin security compliance, and accessible content extraction.
 */

export interface BrowserTab {
  id: string;
  title: string;
  url: string;
  displayUrl: string;
  favicon?: string;
  isLoading: boolean;
  canEmbed: boolean;
  isYouTube: boolean;
  youtubeEmbedUrl?: string | null;
  extractedTitle?: string;
  extractedDescription?: string;
  extractedText?: string | null;
  isReaderMode: boolean;
  history: string[];
  historyIndex: number;
  lastLoadedAt: number;
}

export interface BrowserHistoryItem {
  id: string;
  url: string;
  title: string;
  timestamp: number;
  favicon?: string;
}

export interface BrowserState {
  isOpen: boolean;
  activeTabId: string;
  tabs: BrowserTab[];
  history: BrowserHistoryItem[];
  isHistoryDrawerOpen: boolean;
}

type BrowserListener = (state: BrowserState) => void;

const DEFAULT_HOME_URL = 'about:home';

class BrowserManager {
  private isOpen = false;
  private tabs: BrowserTab[] = [];
  private activeTabId = '';
  private history: BrowserHistoryItem[] = [];
  private isHistoryDrawerOpen = false;
  private listeners: Set<BrowserListener> = new Set();

  constructor() {
    this.loadHistoryFromStorage();
    const initialTab = this.createNewTabRecord(DEFAULT_HOME_URL, 'Myraa Portal');
    this.tabs = [initialTab];
    this.activeTabId = initialTab.id;
  }

  private loadHistoryFromStorage() {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('myraa_browser_history');
        if (saved) {
          this.history = JSON.parse(saved);
        }
      } catch {}
    }
  }

  private saveHistoryToStorage() {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('myraa_browser_history', JSON.stringify(this.history.slice(0, 100)));
      } catch {}
    }
  }

  private createNewTabRecord(url = DEFAULT_HOME_URL, title = 'New Tab'): BrowserTab {
    const id = `tab_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    return {
      id,
      title,
      url,
      displayUrl: url === DEFAULT_HOME_URL ? '' : url,
      isLoading: false,
      canEmbed: true,
      isYouTube: url.includes('youtube.com') || url.includes('youtu.be'),
      isReaderMode: false,
      history: [url],
      historyIndex: 0,
      lastLoadedAt: Date.now(),
    };
  }

  public getState(): BrowserState {
    return {
      isOpen: this.isOpen,
      activeTabId: this.activeTabId,
      tabs: this.tabs,
      history: this.history,
      isHistoryDrawerOpen: this.isHistoryDrawerOpen,
    };
  }

  public subscribe(listener: BrowserListener): () => void {
    this.listeners.add(listener);
    listener(this.getState());
    return () => this.listeners.delete(listener);
  }

  private notify() {
    const state = this.getState();
    this.listeners.forEach((listener) => {
      try {
        listener(state);
      } catch (err) {
        console.warn('Browser state listener error:', err);
      }
    });
  }

  public openBrowser(targetUrl?: string) {
    this.isOpen = true;
    if (targetUrl) {
      this.navigateActiveTab(targetUrl);
    }
    this.notify();
  }

  public closeBrowser() {
    this.isOpen = false;
    this.notify();
  }

  public toggleBrowser() {
    this.isOpen = !this.isOpen;
    this.notify();
  }

  public createTab(url = DEFAULT_HOME_URL) {
    const newTab = this.createNewTabRecord(url, url === DEFAULT_HOME_URL ? 'New Tab' : 'Loading...');
    this.tabs.push(newTab);
    this.activeTabId = newTab.id;
    this.notify();

    if (url !== DEFAULT_HOME_URL) {
      this.fetchPageData(newTab.id, url);
    }
  }

  public closeTab(tabId: string) {
    if (this.tabs.length <= 1) {
      // Don't close last tab; reset it to home
      const tab = this.tabs[0];
      tab.url = DEFAULT_HOME_URL;
      tab.title = 'Myraa Portal';
      tab.displayUrl = '';
      tab.history = [DEFAULT_HOME_URL];
      tab.historyIndex = 0;
      tab.extractedText = null;
      this.notify();
      return;
    }

    const index = this.tabs.findIndex((t) => t.id === tabId);
    this.tabs = this.tabs.filter((t) => t.id !== tabId);

    if (this.activeTabId === tabId) {
      const nextIndex = Math.max(0, index - 1);
      this.activeTabId = this.tabs[nextIndex].id;
    }
    this.notify();
  }

  public switchTab(tabId: string) {
    const exists = this.tabs.some((t) => t.id === tabId);
    if (exists) {
      this.activeTabId = tabId;
      this.notify();
    }
  }

  public getActiveTab(): BrowserTab | null {
    return this.tabs.find((t) => t.id === this.activeTabId) || this.tabs[0] || null;
  }

  /**
   * Resolves raw user input (URL or Search Query)
   */
  public resolveUrl(input: string): string {
    const trimmed = input.trim();
    if (!trimmed || trimmed === DEFAULT_HOME_URL) return DEFAULT_HOME_URL;

    // Check if valid URL or domain
    const hasProtocol = /^https?:\/\//i.test(trimmed);
    const isDomain = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/.*)?$/i.test(trimmed);

    if (hasProtocol) {
      return trimmed;
    }
    if (isDomain) {
      return `https://${trimmed}`;
    }

    // Default: Search via DuckDuckGo
    return `https://duckduckgo.com/?q=${encodeURIComponent(trimmed)}`;
  }

  /**
   * Navigates the current active tab to a URL or search query
   */
  public async navigateActiveTab(input: string) {
    const targetUrl = this.resolveUrl(input);
    const activeTab = this.getActiveTab();
    if (!activeTab) return;

    if (targetUrl === DEFAULT_HOME_URL) {
      activeTab.url = DEFAULT_HOME_URL;
      activeTab.displayUrl = '';
      activeTab.title = 'Myraa Portal';
      activeTab.canEmbed = true;
      activeTab.isLoading = false;
      activeTab.extractedText = null;
      activeTab.history.push(DEFAULT_HOME_URL);
      activeTab.historyIndex = activeTab.history.length - 1;
      this.notify();
      return;
    }

    // Update tab status
    activeTab.isLoading = true;
    activeTab.displayUrl = targetUrl;
    activeTab.url = targetUrl;

    // Push history stack
    if (activeTab.history[activeTab.historyIndex] !== targetUrl) {
      activeTab.history = activeTab.history.slice(0, activeTab.historyIndex + 1);
      activeTab.history.push(targetUrl);
      activeTab.historyIndex = activeTab.history.length - 1;
    }

    this.notify();
    await this.fetchPageData(activeTab.id, targetUrl);
  }

  /**
   * Fetches real web page metadata and content via server proxy
   */
  public async fetchPageData(tabId: string, url: string) {
    const tab = this.tabs.find((t) => t.id === tabId);
    if (!tab) return;

    tab.isLoading = true;
    this.notify();

    try {
      const res = await fetch('/api/browser/fetch-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
      });

      if (!res.ok) {
        throw new Error(`Failed to load: ${res.status}`);
      }

      const data = await res.json();
      tab.isLoading = false;
      tab.url = data.url || url;
      tab.displayUrl = data.url || url;
      tab.title = data.title || data.hostname || 'Web Page';
      tab.favicon = data.favicon;
      tab.canEmbed = !!data.canEmbed;
      tab.isYouTube = !!data.isYouTube;
      tab.youtubeEmbedUrl = data.youtubeEmbedUrl;
      tab.extractedTitle = data.title;
      tab.extractedDescription = data.description;
      tab.extractedText = data.readableText;
      tab.lastLoadedAt = Date.now();

      // Record in browser history
      this.recordHistory(data.url || url, data.title || data.hostname, data.favicon);
    } catch (err: any) {
      console.warn('Browser fetch notice:', err);
      tab.isLoading = false;
      tab.title = 'Navigation Notice';
      tab.canEmbed = false;
    }

    this.notify();
  }

  private recordHistory(url: string, title: string, favicon?: string) {
    if (url === DEFAULT_HOME_URL) return;

    const item: BrowserHistoryItem = {
      id: `hist_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      url,
      title: title || url,
      timestamp: Date.now(),
      favicon,
    };

    // Filter duplicates at the top
    this.history = [item, ...this.history.filter((h) => h.url !== url)].slice(0, 100);
    this.saveHistoryToStorage();
  }

  public goBack() {
    const tab = this.getActiveTab();
    if (!tab || tab.historyIndex <= 0) return;

    tab.historyIndex -= 1;
    const prevUrl = tab.history[tab.historyIndex];
    tab.url = prevUrl;
    tab.displayUrl = prevUrl === DEFAULT_HOME_URL ? '' : prevUrl;
    this.notify();

    if (prevUrl !== DEFAULT_HOME_URL) {
      this.fetchPageData(tab.id, prevUrl);
    }
  }

  public goForward() {
    const tab = this.getActiveTab();
    if (!tab || tab.historyIndex >= tab.history.length - 1) return;

    tab.historyIndex += 1;
    const nextUrl = tab.history[tab.historyIndex];
    tab.url = nextUrl;
    tab.displayUrl = nextUrl === DEFAULT_HOME_URL ? '' : nextUrl;
    this.notify();

    if (nextUrl !== DEFAULT_HOME_URL) {
      this.fetchPageData(tab.id, nextUrl);
    }
  }

  public refresh() {
    const tab = this.getActiveTab();
    if (!tab) return;
    if (tab.url !== DEFAULT_HOME_URL) {
      this.fetchPageData(tab.id, tab.url);
    }
  }

  public goHome() {
    this.navigateActiveTab(DEFAULT_HOME_URL);
  }

  public toggleReaderMode() {
    const tab = this.getActiveTab();
    if (tab) {
      tab.isReaderMode = !tab.isReaderMode;
      this.notify();
    }
  }

  public toggleHistoryDrawer() {
    this.isHistoryDrawerOpen = !this.isHistoryDrawerOpen;
    this.notify();
  }

  public clearHistory() {
    this.history = [];
    this.saveHistoryToStorage();
    this.notify();
  }

  /**
   * Returns accessible page content of the active tab for Myraa
   */
  public getActivePageContent(): { url: string; title: string; content: string | null; isAccessible: boolean } {
    const tab = this.getActiveTab();
    if (!tab || tab.url === DEFAULT_HOME_URL) {
      return {
        url: 'about:home',
        title: 'Home Portal',
        content: 'Home Portal showing quick bookmarks: YouTube, AI News, Wikipedia, GitHub, and ChatGPT.',
        isAccessible: true,
      };
    }

    return {
      url: tab.url,
      title: tab.extractedTitle || tab.title,
      content: tab.extractedText || tab.extractedDescription || null,
      isAccessible: !!(tab.extractedText || tab.extractedDescription || tab.canEmbed),
    };
  }
}

export const browserService = new BrowserManager();
