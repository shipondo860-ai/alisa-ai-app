import { AssistantActivityLog } from '../types/assistant';

const STORAGE_KEY = 'alisa_android_activity_log';

let listeners: Array<(logs: AssistantActivityLog[]) => void> = [];

export function getActivityLogs(): AssistantActivityLog[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return getDefaultInitialLogs();
    return JSON.parse(raw);
  } catch {
    return getDefaultInitialLogs();
  }
}

function getDefaultInitialLogs(): AssistantActivityLog[] {
  const now = new Date();
  const timeFormatted = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  return [
    {
      id: 'init-1',
      timestamp: now.toISOString(),
      timeFormatted: timeFormatted,
      userSpeech: 'YouTube খোলো',
      actionSummary: 'App Launcher: YouTube',
      resultStatus: 'success',
      resultMessage: 'YouTube opened successfully.',
    },
    {
      id: 'init-2',
      timestamp: new Date(now.getTime() - 60000).toISOString(),
      timeFormatted: new Date(now.getTime() - 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }),
      userSpeech: 'Check microphone permissions',
      actionSummary: 'Permission Center Check',
      resultStatus: 'success',
      resultMessage: 'Microphone permission granted & active.',
    },
  ];
}

export function addActivityLog(
  userSpeech: string,
  actionSummary: string,
  resultStatus: 'success' | 'failed' | 'cancelled' | 'pending_confirmation',
  resultMessage: string,
  details?: string
): AssistantActivityLog {
  const now = new Date();
  const timeFormatted = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  const newLog: AssistantActivityLog = {
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    timestamp: now.toISOString(),
    timeFormatted,
    userSpeech,
    actionSummary,
    resultStatus,
    resultMessage,
    details,
  };

  const logs = [newLog, ...getActivityLogs()].slice(0, 150); // retain last 150
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(logs));
  } catch {}

  notifyListeners(logs);
  return newLog;
}

export function clearActivityLogs(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {}
  notifyListeners([]);
}

export function subscribeToLogs(cb: (logs: AssistantActivityLog[]) => void): () => void {
  listeners.push(cb);
  cb(getActivityLogs());
  return () => {
    listeners = listeners.filter((l) => l !== cb);
  };
}

function notifyListeners(logs: AssistantActivityLog[]): void {
  listeners.forEach((l) => {
    try {
      l(logs);
    } catch {}
  });
}
