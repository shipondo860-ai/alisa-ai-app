/**
 * MYRAA V5 — REAL SCREEN VISION SERVICE
 * 
 * Uses the browser's native Screen Capture API (navigator.mediaDevices.getDisplayMedia)
 * Allows selection of Entire Screen, Application Window, or Browser Tab.
 * 
 * Features:
 * - Start Sharing
 * - Pause / Resume
 * - Stop Sharing
 * - Active sharing state tracking
 * - Low-bandwidth responsible frame capture with canvas JPEG compression
 * - Safe permission and termination handling
 * - Visual context persistence
 */

export interface ScreenVisionState {
  isSupported: boolean;
  isSharing: boolean;
  isPaused: boolean;
  stream: MediaStream | null;
  videoTrack: MediaStreamTrack | null;
  displaySurface: string | null; // 'monitor' | 'window' | 'browser'
  lastCaptureTime: number | null;
  lastVisualContext: string | null;
  error: string | null;
}

type StateListener = (state: ScreenVisionState) => void;

class ScreenVisionManager {
  private stream: MediaStream | null = null;
  private videoElement: HTMLVideoElement | null = null;
  private isPaused = false;
  private lastVisualContext: string | null = null;
  private lastCaptureTime: number | null = null;
  private error: string | null = null;
  private listeners: Set<StateListener> = new Set();

  constructor() {
    // Create an offscreen video element for extracting frames
    if (typeof window !== 'undefined') {
      this.videoElement = document.createElement('video');
      this.videoElement.autoplay = true;
      this.videoElement.muted = true;
      this.videoElement.playsInline = true;
      this.videoElement.style.display = 'none';
      document.body.appendChild(this.videoElement);
    }
  }

  public isSupported(): boolean {
    return (
      typeof window !== 'undefined' &&
      typeof navigator !== 'undefined' &&
      !!navigator.mediaDevices &&
      typeof navigator.mediaDevices.getDisplayMedia === 'function'
    );
  }

  public getState(): ScreenVisionState {
    const videoTrack = this.stream?.getVideoTracks()[0] || null;
    const settings = videoTrack?.getSettings();

    return {
      isSupported: this.isSupported(),
      isSharing: !!this.stream && this.stream.active,
      isPaused: this.isPaused,
      stream: this.stream,
      videoTrack,
      displaySurface: (settings as any)?.displaySurface || null,
      lastCaptureTime: this.lastCaptureTime,
      lastVisualContext: this.lastVisualContext,
      error: this.error,
    };
  }

  public subscribe(listener: StateListener): () => void {
    this.listeners.add(listener);
    listener(this.getState());
    return () => this.listeners.delete(listener);
  }

  private notify() {
    const state = this.getState();
    this.listeners.forEach((listener) => {
      try {
        listener(state);
      } catch (err) {
        console.warn('ScreenVision state listener error:', err);
      }
    });
  }

  /**
   * Prompts the browser's native Screen Selection dialog
   * User can select: Entire Screen, Application Window, or Browser Tab
   */
  public async startSharing(): Promise<MediaStream> {
    this.error = null;

    if (!this.isSupported()) {
      const msg = 'Screen Capture API is not supported in this browser environment.';
      this.error = msg;
      this.notify();
      throw new Error(msg);
    }

    try {
      // Clean up any existing stream before starting a new one
      if (this.stream) {
        this.stopSharing();
      }

      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: 'monitor',
          cursor: 'always',
        } as MediaTrackConstraints,
        audio: false,
      });

      this.stream = stream;
      this.isPaused = false;

      if (this.videoElement) {
        this.videoElement.srcObject = stream;
        await this.videoElement.play().catch(() => {});
      }

      const track = stream.getVideoTracks()[0];
      if (track) {
        // Handle user stopping share from browser chrome bar (e.g. "Stop sharing" ribbon)
        track.addEventListener('ended', () => {
          this.handleTrackEnded();
        });
      }

      this.notify();
      return stream;
    } catch (err: any) {
      if (err.name === 'NotAllowedError') {
        this.error = 'Screen sharing was cancelled or permission was denied.';
      } else {
        this.error = err.message || 'Failed to start screen capture.';
      }
      this.notify();
      throw err;
    }
  }

  /**
   * Pauses screen capture without terminating the stream
   */
  public pauseSharing(): void {
    if (!this.stream) return;
    const track = this.stream.getVideoTracks()[0];
    if (track) {
      track.enabled = false;
      this.isPaused = true;
      this.notify();
    }
  }

  /**
   * Resumes paused screen capture
   */
  public resumeSharing(): void {
    if (!this.stream) return;
    const track = this.stream.getVideoTracks()[0];
    if (track) {
      track.enabled = true;
      this.isPaused = false;
      this.notify();
    }
  }

  /**
   * Stops screen capture cleanly
   */
  public stopSharing(): void {
    if (this.stream) {
      this.stream.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {}
      });
      this.stream = null;
    }

    if (this.videoElement) {
      this.videoElement.srcObject = null;
    }

    this.isPaused = false;
    this.notify();
  }

  private handleTrackEnded() {
    this.stopSharing();
  }

  /**
   * Responsibly captures a single compressed JPEG frame from the active video stream.
   * Compresses image using canvas to minimize payload (~60KB to 100KB)
   */
  public async captureCompressedFrame(maxWidth = 1280, quality = 0.7): Promise<string | null> {
    if (!this.stream || !this.stream.active || this.isPaused || !this.videoElement) {
      return null;
    }

    // Wait until video has valid dimensions
    if (this.videoElement.videoWidth === 0 || this.videoElement.videoHeight === 0) {
      await new Promise<void>((resolve) => {
        const handler = () => {
          this.videoElement?.removeEventListener('loadedmetadata', handler);
          resolve();
        };
        this.videoElement?.addEventListener('loadedmetadata', handler);
        setTimeout(resolve, 250);
      });
    }

    const vw = this.videoElement.videoWidth || 1280;
    const vh = this.videoElement.videoHeight || 720;

    let targetWidth = vw;
    let targetHeight = vh;

    if (vw > maxWidth) {
      const ratio = maxWidth / vw;
      targetWidth = maxWidth;
      targetHeight = Math.round(vh * ratio);
    }

    const canvas = document.createElement('canvas');
    canvas.width = targetWidth;
    canvas.height = targetHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(this.videoElement, 0, 0, targetWidth, targetHeight);

    // Compress to JPEG
    const dataUrl = canvas.toDataURL('image/jpeg', quality);
    this.lastCaptureTime = Date.now();
    this.notify();

    // Strip prefix for direct Gemini inlineData
    const base64Data = dataUrl.replace(/^data:image\/jpeg;base64,/, '');
    return base64Data;
  }

  public setVisualContext(summary: string) {
    this.lastVisualContext = summary;
    this.notify();
  }

  public clearVisualContext() {
    this.lastVisualContext = null;
    this.notify();
  }
}

export const screenVisionService = new ScreenVisionManager();
