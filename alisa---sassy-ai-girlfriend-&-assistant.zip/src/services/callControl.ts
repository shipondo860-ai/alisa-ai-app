import { ConfirmationRequest } from '../types/assistant';
import { addActivityLog } from './actionLog';
import { announceAction, COMMON_ANNOUNCEMENTS } from './actionAnnouncer';
import { isPermissionGranted } from './permissionCenter';

export interface CallTarget {
  name: string;
  phoneNumber: string;
}

export interface ActiveIncomingCall {
  id: string;
  callerName: string;
  phoneNumber: string;
  timestamp: string;
}

export const KNOWN_CONTACTS: CallTarget[] = [
  { name: 'Ayush (The AI Visionary)', phoneNumber: '+919876543210' },
  { name: 'Mom / মা', phoneNumber: '+919811122233' },
  { name: 'Dad / বাবা', phoneNumber: '+919822233344' },
  { name: 'Studio Manager', phoneNumber: '+18005550199' },
  { name: 'YouTube Support', phoneNumber: '+18002738255' },
];

let activeIncomingCall: ActiveIncomingCall | null = null;
let incomingCallListeners: Array<(call: ActiveIncomingCall | null) => void> = [];

export function subscribeToIncomingCalls(cb: (call: ActiveIncomingCall | null) => void): () => void {
  incomingCallListeners.push(cb);
  cb(activeIncomingCall);
  return () => {
    incomingCallListeners = incomingCallListeners.filter((l) => l !== cb);
  };
}

function notifyIncomingCallListeners(call: ActiveIncomingCall | null) {
  activeIncomingCall = call;
  incomingCallListeners.forEach((l) => {
    try {
      l(call);
    } catch {}
  });
}

export function resolveContact(query: string): CallTarget {
  const norm = query.toLowerCase().trim();
  const matched = KNOWN_CONTACTS.find(
    (c) => c.name.toLowerCase().includes(norm) || norm.includes(c.name.toLowerCase())
  );
  if (matched) return matched;

  const digits = query.replace(/[^0-9+]/g, '');
  if (digits.length >= 3) {
    return { name: `Number (${digits})`, phoneNumber: digits };
  }

  return { name: query, phoneNumber: '+919876543210' };
}

export async function simulateIncomingCall(
  callerName: string = 'Ayush (The AI Visionary)',
  phoneNumber: string = '+91 98765 43210'
): Promise<ActiveIncomingCall> {
  const call: ActiveIncomingCall = {
    id: `inc-${Date.now()}`,
    callerName,
    phoneNumber,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  };

  notifyIncomingCallListeners(call);
  await announceAction(COMMON_ANNOUNCEMENTS.INCOMING_CALL);
  return call;
}

export async function answerIncomingCall(
  callId: string,
  userSpeech: string = 'Answer call'
): Promise<{ success: boolean; message: string }> {
  // Check Android Phone permission
  const hasPermission = await isPermissionGranted('phone');
  if (!hasPermission) {
    const errorMsg = 'Android security restriction: Telecom/Phone permission is not granted. Cannot answer call.';
    addActivityLog(userSpeech, 'Incoming Call: Answer', 'failed', errorMsg);
    await announceAction(COMMON_ANNOUNCEMENTS.PERMISSION_REQUIRED);
    return { success: false, message: errorMsg };
  }

  const caller = activeIncomingCall?.callerName || 'Caller';
  notifyIncomingCallListeners(null);

  const successMsg = `Incoming call from ${caller} connected via Android Telecom Manager.`;
  addActivityLog(userSpeech, `Incoming Call: ${caller}`, 'success', successMsg);
  await announceAction(COMMON_ANNOUNCEMENTS.CALL_ANSWERED);

  return { success: true, message: successMsg };
}

export async function rejectIncomingCall(
  callId: string,
  userSpeech: string = 'Reject call'
): Promise<{ success: boolean; message: string }> {
  const hasPermission = await isPermissionGranted('phone');
  if (!hasPermission) {
    const errorMsg = 'Android security restriction: Telecom/Phone permission is not granted.';
    addActivityLog(userSpeech, 'Incoming Call: Reject', 'failed', errorMsg);
    await announceAction(COMMON_ANNOUNCEMENTS.PERMISSION_REQUIRED);
    return { success: false, message: errorMsg };
  }

  const caller = activeIncomingCall?.callerName || 'Caller';
  notifyIncomingCallListeners(null);

  const msg = `Incoming call from ${caller} rejected and dismissed.`;
  addActivityLog(userSpeech, `Incoming Call: Reject (${caller})`, 'cancelled', msg);
  await announceAction(COMMON_ANNOUNCEMENTS.CALL_REJECTED);

  return { success: true, message: msg };
}

export async function prepareOutgoingCall(
  targetQuery: string,
  userSpeech: string,
  requestConfirmation: (req: ConfirmationRequest) => void
): Promise<{ pendingConfirmation: boolean; message: string }> {
  // 1. Check Phone permission
  const hasPhonePermission = await isPermissionGranted('phone');
  if (!hasPhonePermission) {
    const deniedMsg = 'Android restriction: CALL_PHONE permission is not granted. Please enable Phone permission in Permission Center.';
    addActivityLog(userSpeech, 'Call Control', 'failed', deniedMsg);
    await announceAction({
      id: 'phone-perm-needed',
      bn: 'কল করার জন্য ফোন অনুমতি প্রয়োজন।',
      en: 'Phone permission is required to make calls.',
      category: 'call',
      timestamp: '',
    });
    return { pendingConfirmation: false, message: deniedMsg };
  }

  const target = resolveContact(targetQuery);

  // 2. Announce sensitive preparation: "আমি কল করার প্রস্তুতি নিচ্ছি।" (MYRAA V7)
  await announceAction(COMMON_ANNOUNCEMENTS.PREPARE_CALL);

  // 3. Spoken confirmation inquiry: "শিপন, এই নম্বরে কল করব?"
  await announceAction({
    id: 'outgoing-call-inquiry',
    bn: 'শিপন, এই নম্বরে কল করব?',
    en: `Shipon, should I call this number: ${target.phoneNumber}?`,
    category: 'call',
    timestamp: '',
  });

  // 4. High-impact confirmation requirement
  return new Promise((resolve) => {
    requestConfirmation({
      id: `call-${Date.now()}`,
      title: 'শিপন, এই নম্বরে কল করব?',
      description: `Target: ${target.name} (${target.phoneNumber}). Outgoing call via Android Telephony Manager.`,
      impactLevel: 'high',
      actionType: 'call',
      targetDetails: {
        recipient: target.name,
        phoneNumber: target.phoneNumber,
        additionalInfo: 'Carrier standard rates may apply. Outgoing call via Android Telephony Dialer.',
      },
      onConfirm: async () => {
        try {
          // Launch real Android dialer
          window.location.href = `tel:${encodeURIComponent(target.phoneNumber)}`;
          const successMsg = `Outgoing call to ${target.name} (${target.phoneNumber}) initiated via Android Telephony.`;
          addActivityLog(userSpeech, `Call: ${target.name}`, 'success', successMsg);
          await announceAction(COMMON_ANNOUNCEMENTS.ACTION_COMPLETED);
          resolve({ pendingConfirmation: false, message: successMsg });
        } catch (err: any) {
          const failMsg = `Call failed: ${err?.message || 'Telephony intent blocked'}`;
          addActivityLog(userSpeech, `Call: ${target.name}`, 'failed', failMsg);
          resolve({ pendingConfirmation: false, message: failMsg });
        }
      },
      onCancel: async () => {
        const cancelMsg = `Call to ${target.name} was cancelled by user.`;
        addActivityLog(userSpeech, `Call: ${target.name}`, 'cancelled', cancelMsg);
        await announceAction(COMMON_ANNOUNCEMENTS.ACTION_CANCELLED);
        resolve({ pendingConfirmation: false, message: cancelMsg });
      },
    });
  });
}
