import { AccessibilityActionRequest } from '../types/assistant';
import { addActivityLog } from './actionLog';
import { announceAction, COMMON_ANNOUNCEMENTS } from './actionAnnouncer';
import { isPermissionGranted } from './permissionCenter';

export async function executeAccessibilityAction(
  request: AccessibilityActionRequest,
  userSpeech: string = 'Accessibility Action'
): Promise<{ success: boolean; message: string }> {
  // 1. Verify user authorized accessibility service
  const authorized = await isPermissionGranted('accessibility');
  if (!authorized) {
    const errorMsg = 'Android security restriction: Accessibility Service interaction is not authorized. Enable in Permission Center.';
    addActivityLog(userSpeech, `Accessibility: ${request.type}`, 'failed', errorMsg);
    await announceAction(COMMON_ANNOUNCEMENTS.PERMISSION_REQUIRED);
    return { success: false, message: errorMsg };
  }

  try {
    switch (request.type) {
      case 'scroll_down': {
        window.scrollBy({ top: 400, behavior: 'smooth' });
        const msg = 'Screen scrolled down successfully via Accessibility Service.';
        addActivityLog(userSpeech, 'Accessibility: Scroll Down', 'success', msg);
        await announceAction(COMMON_ANNOUNCEMENTS.ACTION_COMPLETED);
        return { success: true, message: msg };
      }

      case 'scroll_up': {
        window.scrollBy({ top: -400, behavior: 'smooth' });
        const msg = 'Screen scrolled up successfully via Accessibility Service.';
        addActivityLog(userSpeech, 'Accessibility: Scroll Up', 'success', msg);
        await announceAction(COMMON_ANNOUNCEMENTS.ACTION_COMPLETED);
        return { success: true, message: msg };
      }

      case 'back': {
        // Close any open modals first, or trigger browser history back
        const closeButtons = document.querySelectorAll('button[aria-label="Close"], button:has(svg.lucide-x)');
        if (closeButtons.length > 0) {
          (closeButtons[closeButtons.length - 1] as HTMLElement).click();
          const msg = 'Navigated back (active modal dismissed) via Accessibility Service.';
          addActivityLog(userSpeech, 'Accessibility: Back', 'success', msg);
          return { success: true, message: msg };
        } else {
          window.history.back();
          const msg = 'Triggered Android Back navigation via Accessibility Service.';
          addActivityLog(userSpeech, 'Accessibility: Back', 'success', msg);
          return { success: true, message: msg };
        }
      }

      case 'tap': {
        if (!request.target) {
          return { success: false, message: 'Accessibility tap failed: Target element not specified.' };
        }
        // Find visible interactive elements matching target
        const elements = Array.from(
          document.querySelectorAll('button, a, input, [role="button"]')
        ) as HTMLElement[];

        const targetNorm = request.target.toLowerCase();
        const matched = elements.find((el) => {
          const text = (el.innerText || el.getAttribute('aria-label') || el.getAttribute('title') || '').toLowerCase();
          return text.includes(targetNorm);
        });

        if (matched) {
          // Verify security: do not tap protected sensitive fields
          if (matched.tagName === 'INPUT' && (matched as HTMLInputElement).type === 'password') {
            const blockedMsg = 'Android security restriction: Cannot tap protected password fields.';
            addActivityLog(userSpeech, 'Accessibility: Tap Blocked', 'failed', blockedMsg);
            return { success: false, message: blockedMsg };
          }

          matched.focus();
          matched.click();
          const successMsg = `Tapped element "${request.target}" via Accessibility Service.`;
          addActivityLog(userSpeech, `Accessibility: Tap "${request.target}"`, 'success', successMsg);
          await announceAction(COMMON_ANNOUNCEMENTS.ACTION_COMPLETED);
          return { success: true, message: successMsg };
        } else {
          const notFoundMsg = `Accessibility tap failed: Visible element "${request.target}" not found on screen.`;
          addActivityLog(userSpeech, `Accessibility: Tap "${request.target}"`, 'failed', notFoundMsg);
          return { success: false, message: notFoundMsg };
        }
      }

      case 'type_text': {
        const textToType = request.value || '';
        const activeInput = (document.activeElement as HTMLInputElement | HTMLTextAreaElement) ||
          (document.querySelector('input[type="text"], textarea') as HTMLInputElement);

        if (activeInput && (activeInput.tagName === 'INPUT' || activeInput.tagName === 'TEXTAREA')) {
          // Check for password protection
          if (activeInput.type === 'password') {
            const blockedMsg = 'Android security restriction: Cannot type into password-protected field.';
            addActivityLog(userSpeech, 'Accessibility: Type Blocked', 'failed', blockedMsg);
            return { success: false, message: blockedMsg };
          }

          activeInput.focus();
          activeInput.value = textToType;
          activeInput.dispatchEvent(new Event('input', { bubbles: true }));
          activeInput.dispatchEvent(new Event('change', { bubbles: true }));

          const successMsg = `Typed text "${textToType}" into focused field via Accessibility Service.`;
          addActivityLog(userSpeech, 'Accessibility: Type Text', 'success', successMsg);
          await announceAction(COMMON_ANNOUNCEMENTS.ACTION_COMPLETED);
          return { success: true, message: successMsg };
        } else {
          const noFieldMsg = 'Accessibility typing failed: No allowed text input field currently focused.';
          addActivityLog(userSpeech, 'Accessibility: Type Text', 'failed', noFieldMsg);
          return { success: false, message: noFieldMsg };
        }
      }

      default:
        return { success: false, message: `Unsupported accessibility action: ${request.type}` };
    }
  } catch (err: any) {
    const errorMsg = `Accessibility action failed: ${err?.message || 'Execution error'}`;
    addActivityLog(userSpeech, `Accessibility: ${request.type}`, 'failed', errorMsg);
    return { success: false, message: errorMsg };
  }
}
