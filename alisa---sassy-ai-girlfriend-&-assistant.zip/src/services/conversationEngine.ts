/**
 * MYRAA V4 — NATURAL VOICE AND LIVE AUDIO ENGINE
 * 
 * Orchestrates natural conversational AI companion interactions.
 * - Continuous active multi-turn conversation without wake words.
 * - Speech start & speech end detection with natural pause tolerance.
 * - Filters out ambient clicks, noise, and short coughs.
 * - Employs short natural acknowledgements ("Hmm...", "Yeah...", "I see...").
 * - Live Session States: IDLE, CONNECTING, CONNECTED, LISTENING, USER_SPEAKING, PROCESSING, SPEAKING, RECONNECTING, ERROR.
 * - Required Loop: CONNECTED -> LISTENING -> USER_SPEAKING -> USER_SPEECH_ENDED -> PROCESSING -> SPEAKING -> AUDIO_ENDED -> LISTENING.
 */

export type LiveSessionState =
  | 'IDLE'
  | 'CONNECTING'
  | 'CONNECTED'
  | 'LISTENING'
  | 'USER_SPEAKING'
  | 'PROCESSING'
  | 'SPEAKING'
  | 'RECONNECTING'
  | 'ERROR';

// Backward compatibility alias
export type VoiceLoopPhase =
  | LiveSessionState
  | 'SPEECH_ENDED'
  | 'THINKING'
  | 'PLAYBACK_FINISHED'
  | 'MIC_DENIED'
  | 'connecting'
  | 'reconnecting'
  | 'error'
  | 'mic_denied';

export type LiveDebugEvent =
  | 'SESSION_CONNECTED'
  | 'MIC_STARTED'
  | 'USER_SPEECH_STARTED'
  | 'USER_SPEECH_ENDED'
  | 'RESPONSE_STARTED'
  | 'AUDIO_PLAYBACK_STARTED'
  | 'AUDIO_PLAYBACK_ENDED'
  | 'SESSION_CLOSED'
  | 'SESSION_ERROR'
  | 'RECONNECT_STARTED'
  | 'RECONNECT_SUCCESS';

export interface DebugEventLogItem {
  id: string;
  event: LiveDebugEvent;
  timestamp: number;
  timeString: string;
  details?: string;
}

export interface ConversationTurn {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
  emotionalContext?: string;
  acknowledgement?: string;
  followUpQuestion?: string;
}

export interface ConversationSession {
  sessionId: string;
  startTime: number;
  turns: ConversationTurn[];
  detectedEmotion: 'neutral' | 'happy' | 'stressed' | 'excited' | 'tired' | 'curious' | 'playful';
  userInterests: string[];
  activeTopic: string | null;
}

// Phrases strictly forbidden from Myraa's natural dialogue to avoid robotic/corporate delivery
export const ROBOTIC_PHRASES_BLACKLIST = [
  'how may i assist you',
  'how can i assist you',
  'is there anything else i can help with',
  'is there anything else i can help you with',
  'your request has been completed',
  'as an ai language model',
  'as an artificial intelligence',
  'i am programmed to',
  'how may i help you today',
  'how can i help you today',
];

// Natural conversational filler/acknowledgements
export const NATURAL_ACKNOWLEDGEMENTS = [
  'Hmm...',
  'Yeah...',
  'I see...',
  'Interesting...',
  'Oh, totally...',
  'Wait, really?',
  'Mhm...',
  'Right...',
];

/**
 * Creates a fresh conversation session with initial context
 */
export function createConversationSession(): ConversationSession {
  return {
    sessionId: `session_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    startTime: Date.now(),
    turns: [],
    detectedEmotion: 'playful',
    userInterests: [],
    activeTopic: null,
  };
}

/**
 * Detects user emotional cues from raw speech
 */
export function detectUserEmotion(text: string): ConversationSession['detectedEmotion'] {
  const lower = text.toLowerCase();
  if (lower.includes('tired') || lower.includes('exhausted') || lower.includes('sleepy') || lower.includes('rough day')) {
    return 'tired';
  }
  if (lower.includes('stressed') || lower.includes('anxious') || lower.includes('overwhelmed') || lower.includes('deadline')) {
    return 'stressed';
  }
  if (lower.includes('awesome') || lower.includes('great news') || lower.includes('yay') || lower.includes('excited') || lower.includes('won')) {
    return 'excited';
  }
  if (lower.includes('haha') || lower.includes('lol') || lower.includes('joke') || lower.includes('flirt') || lower.includes('roast')) {
    return 'playful';
  }
  if (lower.includes('why') || lower.includes('how') || lower.includes('what if') || lower.includes('wondering')) {
    return 'curious';
  }
  if (lower.includes('happy') || lower.includes('good') || lower.includes('love') || lower.includes('nice')) {
    return 'happy';
  }
  return 'neutral';
}

/**
 * Sanitizes model responses to ensure zero robotic cliches
 */
export function sanitizeConversationalResponse(text: string): string {
  let cleaned = text.trim();
  for (const phrase of ROBOTIC_PHRASES_BLACKLIST) {
    const regex = new RegExp(phrase, 'gi');
    cleaned = cleaned.replace(regex, '');
  }
  cleaned = cleaned.replace(/\s{2,}/g, ' ').trim();
  return cleaned;
}

/**
 * High-performance Voice Activity Detector (VAD) state tracker
 * - Filters transient clicks/taps (< 160ms)
 * - Sustained speech marks USER_SPEAKING
 * - Generous silence allowance (1100ms) ensuring the user is never cut off mid-thought
 */
export class VoiceActivityDetector {
  private speechStartTimestamp: number | null = null;
  private silenceStartTimestamp: number | null = null;
  private isUserSpeaking = false;
  private ambientNoiseFloor = 0.015;

  // Thresholds
  private readonly SPEECH_ENERGY_MULTIPLIER = 2.4;
  private readonly MIN_SPEECH_DURATION_MS = 160; // filter short clicks/coughs
  private readonly PAUSE_SILENCE_DURATION_MS = 1100; // allow natural pauses/breaths without cut-off

  public onSpeechStart?: () => void;
  public onSpeechEnd?: () => void;
  public onAudioLevel?: (level: number) => void;

  public processAudioFrame(channelData: Float32Array): {
    rms: number;
    isSpeech: boolean;
    stateChange?: 'started' | 'ended';
  } {
    // 1. Calculate RMS energy
    let sum = 0;
    const len = channelData.length;
    for (let i = 0; i < len; i++) {
      sum += channelData[i] * channelData[i];
    }
    const rms = Math.sqrt(sum / len);

    // Update running ambient floor
    this.ambientNoiseFloor = this.ambientNoiseFloor * 0.98 + Math.min(rms, 0.05) * 0.02;
    const speechThreshold = Math.max(0.035, this.ambientNoiseFloor * this.SPEECH_ENERGY_MULTIPLIER);

    const now = performance.now();
    const isInstantEnergyAbove = rms > speechThreshold;

    this.onAudioLevel?.(Math.min(1, rms * 6));

    let stateChange: 'started' | 'ended' | undefined = undefined;

    if (isInstantEnergyAbove) {
      this.silenceStartTimestamp = null;
      if (!this.isUserSpeaking) {
        if (!this.speechStartTimestamp) {
          this.speechStartTimestamp = now;
        } else if (now - this.speechStartTimestamp >= this.MIN_SPEECH_DURATION_MS) {
          // Sustained speech detected -> USER_SPEAKING
          this.isUserSpeaking = true;
          stateChange = 'started';
          this.onSpeechStart?.();
        }
      }
    } else {
      // Below threshold (silence or quiet breath)
      this.speechStartTimestamp = null;
      if (this.isUserSpeaking) {
        if (!this.silenceStartTimestamp) {
          this.silenceStartTimestamp = now;
        } else if (now - this.silenceStartTimestamp >= this.PAUSE_SILENCE_DURATION_MS) {
          // Sustained silence after speech -> SPEECH_ENDED
          this.isUserSpeaking = false;
          this.silenceStartTimestamp = null;
          stateChange = 'ended';
          this.onSpeechEnd?.();
        }
      }
    }

    return { rms, isSpeech: this.isUserSpeaking, stateChange };
  }

  public reset() {
    this.speechStartTimestamp = null;
    this.silenceStartTimestamp = null;
    this.isUserSpeaking = false;
  }
}
