import { ConfirmationRequest } from '../types/assistant';
import { addActivityLog } from './actionLog';
import { announceAction, COMMON_ANNOUNCEMENTS } from './actionAnnouncer';
import { resolveContact } from './callControl';
import { isPermissionGranted } from './permissionCenter';

export async function prepareOutgoingMessage(
  recipientQuery: string,
  messageBody: string,
  userSpeech: string,
  requestConfirmation: (req: ConfirmationRequest) => void
): Promise<{ pendingConfirmation: boolean; message: string }> {
  // Check permission
  const hasPhonePermission = await isPermissionGranted('phone');
  if (!hasPhonePermission) {
    const deniedMsg = 'Android restriction: SMS/Phone permission is not granted. Please enable in Permission Center.';
    addActivityLog(userSpeech, 'Messaging Control', 'failed', deniedMsg);
    await announceAction({
      bn: 'মেসেজ পাঠানোর জন্য অনুমতি প্রয়োজন।',
      en: 'Permission is required to send messages.',
    });
    return { pendingConfirmation: false, message: deniedMsg };
  }

  const target = resolveContact(recipientQuery);
  const finalBody = messageBody || 'Hey! Sent via Alisa Android Voice Assistant ❤️';

  // Announce preparation
  await announceAction(COMMON_ANNOUNCEMENTS.PREPARE_MESSAGE);

  return new Promise((resolve) => {
    requestConfirmation({
      id: `msg-${Date.now()}`,
      title: 'Confirm Outgoing Message',
      description: `Alisa is preparing to send an SMS/message to ${target.name} (${target.phoneNumber}).`,
      impactLevel: 'high',
      actionType: 'message',
      targetDetails: {
        recipient: target.name,
        phoneNumber: target.phoneNumber,
        messageBody: finalBody,
        additionalInfo: 'Never sent silently. Confirmation is strictly required.',
      },
      onConfirm: async () => {
        try {
          // Launch real Android SMS intent
          const smsUrl = `sms:${encodeURIComponent(target.phoneNumber)}?body=${encodeURIComponent(finalBody)}`;
          window.location.href = smsUrl;

          const successMsg = `Message composed to ${target.name} ("${finalBody}") via Android SMS Intent.`;
          addActivityLog(userSpeech, `Message: ${target.name}`, 'success', successMsg);
          await announceAction(COMMON_ANNOUNCEMENTS.ACTION_COMPLETED);
          resolve({ pendingConfirmation: false, message: successMsg });
        } catch (err: any) {
          const failMsg = `Message failed: ${err?.message || 'SMS intent blocked'}`;
          addActivityLog(userSpeech, `Message: ${target.name}`, 'failed', failMsg);
          resolve({ pendingConfirmation: false, message: failMsg });
        }
      },
      onCancel: async () => {
        const cancelMsg = `Message to ${target.name} was cancelled by user.`;
        addActivityLog(userSpeech, `Message: ${target.name}`, 'cancelled', cancelMsg);
        await announceAction(COMMON_ANNOUNCEMENTS.ACTION_CANCELLED);
        resolve({ pendingConfirmation: false, message: cancelMsg });
      },
    });
  });
}
