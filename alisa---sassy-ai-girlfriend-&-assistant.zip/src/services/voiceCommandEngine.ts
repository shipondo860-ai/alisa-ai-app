import { ConfirmationRequest, VoiceCommandParseResult } from '../types/assistant';
import { findAppByQuery, launchAndroidApp } from './appLauncher';
import { prepareOutgoingCall } from './callControl';
import { prepareOutgoingMessage } from './messagingService';
import { executeAccessibilityAction } from './accessibilityService';
import { readAndSummarizeNotifications } from './notificationService';
import { openPhotoGalleryWorkflow } from './mediaWorkflow';
import { browserService } from './browserService';

export interface CommandExecutionCallbacks {
  requestConfirmation: (req: ConfirmationRequest) => void;
  openPermissionCenter?: () => void;
  openActivityLog?: () => void;
  openPhotoEditor?: (photoUrl: string, name: string) => void;
  openApkInstaller?: () => void;
  openBrowser?: (url?: string) => void;
}

export async function processVoiceCommand(
  speech: string,
  callbacks: CommandExecutionCallbacks
): Promise<{ handled: boolean; resultMessage?: string }> {
  const norm = speech.toLowerCase().trim();

  // 0. MYRAA V6 Web Browser & YouTube Voice Commands
  if (norm.includes('search youtube for') || norm.includes('search youtube')) {
    const q = norm.replace(/search youtube for|search youtube|please/gi, '').trim() || 'AI agents';
    const target = `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`;
    browserService.openBrowser(target);
    callbacks.openBrowser?.(target);
    return { handled: true, resultMessage: `Searching YouTube for "${q}".` };
  }

  if (norm === 'open youtube' || norm === 'open youtube.' || norm === 'youtube খোলো' || norm === 'launch youtube') {
    const target = 'https://www.youtube.com';
    browserService.openBrowser(target);
    callbacks.openBrowser?.(target);
    return { handled: true, resultMessage: 'Opening YouTube.' };
  }

  if (norm === 'open chatgpt' || norm === 'open chatgpt.' || norm === 'launch chatgpt' || norm === 'chatgpt খোলো') {
    const target = 'https://chatgpt.com';
    browserService.openBrowser(target);
    callbacks.openBrowser?.(target);
    return { handled: true, resultMessage: 'Opening ChatGPT.' };
  }

  if (norm === 'open gmail' || norm === 'open gmail.' || norm === 'launch gmail' || norm === 'gmail খোলো') {
    const target = 'https://mail.google.com';
    browserService.openBrowser(target);
    callbacks.openBrowser?.(target);
    return { handled: true, resultMessage: 'Opening Gmail.' };
  }

  if (norm.startsWith('search ') || norm.includes('search ai news')) {
    const q = norm.replace(/^search\s+/i, '').replace(/please/gi, '').trim() || 'AI news';
    const target = `https://duckduckgo.com/?q=${encodeURIComponent(q)}`;
    browserService.openBrowser(target);
    callbacks.openBrowser?.(target);
    return { handled: true, resultMessage: `Searching for "${q}".` };
  }

  if (norm.includes('open browser') || norm.includes('web browser') || norm.includes('ব্রাউজার খোলো')) {
    browserService.openBrowser();
    callbacks.openBrowser?.();
    return { handled: true, resultMessage: 'Web Browser opened.' };
  }

  // Page Understanding Voice Commands
  if (
    norm.includes('summarize this page') ||
    norm.includes('summarize this article') ||
    norm.includes('read this article') ||
    norm.includes('what is on this page') ||
    norm.includes('what website is this')
  ) {
    const activeContent = browserService.getActivePageContent();
    if (!activeContent.content && !activeContent.isAccessible) {
      return {
        handled: true,
        resultMessage:
          "The current website has cross-origin security restrictions that prevent in-frame reading. You can open it in an external tab, or share your screen using Screen Vision!",
      };
    }

    try {
      const res = await fetch('/api/browser/understand-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: activeContent.url,
          title: activeContent.title,
          content: activeContent.content,
          question: speech,
        }),
      });
      const data = await res.json();
      return { handled: true, resultMessage: data.reply };
    } catch {
      return { handled: true, resultMessage: 'Page summary complete: ' + (activeContent.content?.slice(0, 150) || 'Accessible web page') };
    }
  }

  // 1. App Launcher commands (Bengali & English)
  // e.g. "YouTube খোলো", "open youtube", "গ্যালারি খোলো", "open settings"
  if (
    norm.includes('খোলো') ||
    norm.includes('খুলুন') ||
    norm.startsWith('open ') ||
    norm.startsWith('launch ') ||
    norm.startsWith('start ')
  ) {
    // Extract app name
    const cleaned = norm
      .replace(/খোলো|খুলুন|open|launch|start|the|app|please/gi, '')
      .trim();

    const matchedApp = findAppByQuery(cleaned);
    if (matchedApp) {
      if (matchedApp.id === 'gallery' && callbacks.openPhotoEditor) {
        await openPhotoGalleryWorkflow(speech, callbacks.openPhotoEditor);
        return { handled: true, resultMessage: 'Gallery photo workflow launched.' };
      }

      const res = await launchAndroidApp(matchedApp, speech);
      return { handled: true, resultMessage: res.message };
    }
  }

  // Direct app trigger if just "YouTube" or "Gallery"
  const directApp = findAppByQuery(norm);
  if (directApp && (norm === directApp.name.toLowerCase() || directApp.aliases.includes(norm))) {
    const res = await launchAndroidApp(directApp, speech);
    return { handled: true, resultMessage: res.message };
  }

  // 2. Call Control commands
  // e.g. "কল করো", "call ayush", "phone mom", "কল করার প্রস্তুতি নাও"
  if (norm.includes('কল করো') || norm.includes('কল কর') || norm.startsWith('call ') || norm.startsWith('phone ')) {
    const targetName = norm
      .replace(/কল করো|কল কর|call|phone|to|please/gi, '')
      .trim() || 'Ayush';

    await prepareOutgoingCall(targetName, speech, callbacks.requestConfirmation);
    return { handled: true, resultMessage: `Preparing call confirmation for ${targetName}.` };
  }

  // 3. Messaging commands
  // e.g. "মেসেজ পাঠাও", "send message to", "sms"
  if (
    norm.includes('মেসেজ পাঠাও') ||
    norm.includes('মেসেজ করো') ||
    norm.startsWith('send message') ||
    norm.startsWith('send a message') ||
    norm.startsWith('sms ') ||
    norm.startsWith('text ')
  ) {
    const target = norm
      .replace(/মেসেজ পাঠাও|মেসেজ করো|send message to|send a message to|sms|text|please/gi, '')
      .trim() || 'Ayush';

    await prepareOutgoingMessage(target, 'Hey from Alisa Voice Assistant!', speech, callbacks.requestConfirmation);
    return { handled: true, resultMessage: `Preparing message confirmation for ${target}.` };
  }

  // 4. Notifications commands
  // e.g. "নোটিফিকেশন দেখো", "check notifications", "read notifications"
  if (
    norm.includes('নোটিফিকেশন') ||
    norm.includes('notification') ||
    norm.includes('alerts')
  ) {
    const res = await readAndSummarizeNotifications(speech);
    return { handled: true, resultMessage: res.summary };
  }

  // 5. Accessibility commands
  // e.g. "স্ক্রোল করো", "scroll down", "scroll up", "নিচে যাও", "উপরে যাও", "back", "পেছনে যাও"
  if (norm.includes('scroll down') || norm.includes('নিচে যাও') || norm.includes('নিচে স্ক্রোল')) {
    const res = await executeAccessibilityAction({ type: 'scroll_down' }, speech);
    return { handled: true, resultMessage: res.message };
  }

  if (norm.includes('scroll up') || norm.includes('উপরে যাও') || norm.includes('উপরে স্ক্রোল')) {
    const res = await executeAccessibilityAction({ type: 'scroll_up' }, speech);
    return { handled: true, resultMessage: res.message };
  }

  if (norm === 'back' || norm === 'go back' || norm.includes('পেছনে যাও') || norm.includes('ফিরে যাও')) {
    const res = await executeAccessibilityAction({ type: 'back' }, speech);
    return { handled: true, resultMessage: res.message };
  }

  if (norm.startsWith('tap ') || norm.startsWith('click ') || norm.startsWith('ক্লিক করো ')) {
    const target = norm.replace(/tap|click|ক্লিক করো|please/gi, '').trim();
    const res = await executeAccessibilityAction({ type: 'tap', target }, speech);
    return { handled: true, resultMessage: res.message };
  }

  // 6. Permission Center
  if (
    norm.includes('অনুমতি') ||
    norm.includes('permission') ||
    norm.includes('settings page')
  ) {
    if (callbacks.openPermissionCenter) {
      callbacks.openPermissionCenter();
      return { handled: true, resultMessage: 'Permission Center opened.' };
    }
  }

  // 7. Activity Log
  if (
    norm.includes('লগ') ||
    norm.includes('activity log') ||
    norm.includes('action log') ||
    norm.includes('history')
  ) {
    if (callbacks.openActivityLog) {
      callbacks.openActivityLog();
      return { handled: true, resultMessage: 'Activity Log opened.' };
    }
  }

  // 8. Gallery / Photo Workflow
  if (norm.includes('gallery') || norm.includes('গ্যালারি') || norm.includes('photo edit') || norm.includes('ছবি এডিট')) {
    await openPhotoGalleryWorkflow(speech, callbacks.openPhotoEditor);
    return { handled: true, resultMessage: 'Gallery photo workflow opened.' };
  }

  // 9. APK Installer (Module 14)
  if (
    norm.includes('apk') ||
    norm.includes('এপিকে') ||
    norm.includes('install app') ||
    norm.includes('package installer') ||
    norm.includes('install package')
  ) {
    if (callbacks.openApkInstaller) {
      callbacks.openApkInstaller();
      return { handled: true, resultMessage: 'APK Installer module opened.' };
    }
  }

  // Not a system command -> delegate to conversational Alisa personality!
  return { handled: false };
}
