import { addActivityLog } from './actionLog';
import { announceAction, COMMON_ANNOUNCEMENTS } from './actionAnnouncer';
import { isPermissionGranted } from './permissionCenter';

export interface AndroidNotificationItem {
  id: string;
  appName: string;
  appIcon: string;
  sender: string;
  title: string;
  summary: string;
  timestamp: string;
  isSensitive: boolean;
}

export const MOCK_NOTIFICATIONS: AndroidNotificationItem[] = [
  {
    id: 'notif-1',
    appName: 'YouTube',
    appIcon: '▶️',
    sender: 'The AI Visionary Ayush',
    title: 'New Subscriber Milestone!',
    summary: 'Channel reached 100K subscribers on the Sassy AI Girlfriend video.',
    timestamp: '5m ago',
    isSensitive: false,
  },
  {
    id: 'notif-2',
    appName: 'Messages',
    appIcon: '💬',
    sender: 'Team Ayush',
    title: 'New Script Draft',
    summary: 'Script for Android AI Assistant uploaded to Google Drive.',
    timestamp: '15m ago',
    isSensitive: false,
  },
  {
    id: 'notif-3',
    appName: 'Phone',
    appIcon: '📞',
    sender: 'Unknown (+91987...)',
    title: 'Missed Call',
    summary: '1 missed call received 22 minutes ago.',
    timestamp: '22m ago',
    isSensitive: true,
  },
  {
    id: 'notif-4',
    appName: 'Google Calendar',
    appIcon: '📅',
    sender: 'Calendar',
    title: 'Live Stream at 9 PM',
    summary: 'Upcoming YouTube Live testing Alisa Live Voice stream.',
    timestamp: '1h ago',
    isSensitive: false,
  },
];

export async function readAndSummarizeNotifications(
  userSpeech: string = 'Check notifications'
): Promise<{ success: boolean; summary: string; count: number }> {
  // Check permission
  const granted = await isPermissionGranted('notifications');
  if (!granted) {
    const errorMsg = 'Android restriction: Notification Access is not granted. Please enable in Permission Center.';
    addActivityLog(userSpeech, 'Notification Access', 'failed', errorMsg);
    await announceAction(COMMON_ANNOUNCEMENTS.PERMISSION_REQUIRED);
    return { success: false, summary: errorMsg, count: 0 };
  }

  // Privacy-first: Filter and produce concise summary without exposing private contents unnecessarily
  const unreadCount = MOCK_NOTIFICATIONS.length;
  const topApp = MOCK_NOTIFICATIONS[0].appName;

  const privacySummary = `You have ${unreadCount} active notifications. Most recent from ${topApp}: "${MOCK_NOTIFICATIONS[0].title}". Sensitive caller details are protected.`;

  await announceAction({
    bn: `আপনার ${unreadCount}টি নোটিফিকেশন আছে। সর্বশেষটি ${topApp} থেকে।`,
    en: privacySummary,
  });

  addActivityLog(
    userSpeech,
    'Notification Access: Summarize',
    'success',
    `Summarized ${unreadCount} notifications (Privacy-first).`
  );

  return {
    success: true,
    summary: privacySummary,
    count: unreadCount,
  };
}
