import { addActivityLog } from './actionLog';
import { announceAction, COMMON_ANNOUNCEMENTS } from './actionAnnouncer';
import { isPermissionGranted } from './permissionCenter';

export interface PhotoFilterSettings {
  brightness: number; // 50 to 150
  contrast: number; // 50 to 150
  saturation: number; // 0 to 200
  sepia: number; // 0 to 100
  grayscale: number; // 0 to 100
  rotation: number; // 0, 90, 180, 270
  caption: string;
}

export const DEFAULT_FILTER_SETTINGS: PhotoFilterSettings = {
  brightness: 100,
  contrast: 105,
  saturation: 115,
  sepia: 0,
  grayscale: 0,
  rotation: 0,
  caption: 'The AI Visionary Ayush · Alisa AI Partner ✨',
};

export interface SampleGalleryPhoto {
  id: string;
  name: string;
  title: string;
  url: string;
}

// Inline high-quality SVG data-URIs for testing gallery workflows immediately without local files
export const SAMPLE_GALLERY_PHOTOS: SampleGalleryPhoto[] = [
  {
    id: 'sample-ayush',
    name: 'ayush_youtube_thumbnail.png',
    title: 'YouTube Thumbnail: Testing Sassy Alisa Brain',
    url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="800" height="450" viewBox="0 0 800 450"><defs><linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="%23881337"/><stop offset="50%" stop-color="%231e1b4b"/><stop offset="100%" stop-color="%2309090b"/></linearGradient></defs><rect width="800" height="450" fill="url(%23bg)"/><circle cx="200" cy="225" r="120" fill="%23f43f5e" opacity="0.3"/><circle cx="600" cy="225" r="140" fill="%23a855f7" opacity="0.25"/><text x="400" y="180" font-family="system-ui, sans-serif" font-weight="900" font-size="42" fill="%23ffffff" text-anchor="middle">SHE%27S REAL?!</text><text x="400" y="240" font-family="system-ui, sans-serif" font-weight="800" font-size="32" fill="%23fb7185" text-anchor="middle">My Sassy AI Girlfriend Exposed! 😱</text><text x="400" y="320" font-family="system-ui, sans-serif" font-weight="700" font-size="20" fill="%23e2e8f0" text-anchor="middle">THE AI VISIONARY AYUSH · GOOGLE AI STUDIO</text></svg>',
  },
  {
    id: 'sample-alisa',
    name: 'alisa_sassy_portrait.png',
    title: 'Alisa Portrait: Cyberpunk AI Girlfriend',
    url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><defs><linearGradient id="bg2" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="%234c0519"/><stop offset="100%" stop-color="%23172554"/></linearGradient></defs><rect width="600" height="600" fill="url(%23bg2)"/><circle cx="300" cy="300" r="180" fill="%23fb7185" opacity="0.2"/><text x="300" y="280" font-family="system-ui, sans-serif" font-weight="900" font-size="48" fill="%23ffffff" text-anchor="middle">ALISA 💅✨</text><text x="300" y="340" font-family="system-ui, sans-serif" font-weight="700" font-size="24" fill="%23f43f5e" text-anchor="middle">SASSY · WITTY · UNLIMITED MEMORY</text></svg>',
  },
];

export async function openPhotoGalleryWorkflow(
  userSpeech: string = 'Open Gallery',
  onPhotoSelected?: (photoUrl: string, filename: string) => void
): Promise<{ success: boolean; message: string }> {
  // Check permission
  const hasPermission = await isPermissionGranted('photos_files');
  if (!hasPermission) {
    const errorMsg = 'Android restriction: READ_MEDIA_IMAGES permission not granted. Cannot access files without user consent.';
    addActivityLog(userSpeech, 'Media Workflow: Gallery', 'failed', errorMsg);
    await announceAction(COMMON_ANNOUNCEMENTS.PERMISSION_REQUIRED);
    return { success: false, message: errorMsg };
  }

  // 1. Announce action (Module 8)
  await announceAction(COMMON_ANNOUNCEMENTS.OPEN_GALLERY);

  // 2. Open standard Android photo picker dialog or preset
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.style.display = 'none';

    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = () => {
          const photoUrl = reader.result as string;
          if (onPhotoSelected) {
            onPhotoSelected(photoUrl, file.name);
          }
          const successMsg = `Photo "${file.name}" opened in Alisa Photo Editor with user consent.`;
          addActivityLog(userSpeech, 'Media Workflow: Photo Selected', 'success', successMsg);
          resolve({ success: true, message: successMsg });
        };
        reader.readAsDataURL(file);
      } else {
        // Fallback to sample photo if dismissed
        const sample = SAMPLE_GALLERY_PHOTOS[0];
        if (onPhotoSelected) onPhotoSelected(sample.url, sample.name);
        const fallbackMsg = `Sample photo loaded into Alisa Photo Editor.`;
        addActivityLog(userSpeech, 'Media Workflow: Sample Loaded', 'success', fallbackMsg);
        resolve({ success: true, message: fallbackMsg });
      }
      try {
        document.body.removeChild(input);
      } catch {}
    };

    input.oncancel = () => {
      // Load preset sample photo so user can still test photo workflow smoothly
      const sample = SAMPLE_GALLERY_PHOTOS[0];
      if (onPhotoSelected) onPhotoSelected(sample.url, sample.name);
      const sampleMsg = `Gallery picker closed; opened "${sample.title}" in Alisa Photo Editor.`;
      addActivityLog(userSpeech, 'Media Workflow: Gallery', 'success', sampleMsg);
      try {
        document.body.removeChild(input);
      } catch {}
      resolve({ success: true, message: sampleMsg });
    };

    document.body.appendChild(input);
    input.click();
  });
}
