import { speakWithBrowserSynthesis } from '../utils/audio';

export interface ActionAnnouncement {
  id: string;
  bn: string;
  en: string;
  category: 'launcher' | 'call' | 'message' | 'media' | 'accessibility' | 'notification' | 'system';
  timestamp: string;
}

export const COMMON_ANNOUNCEMENTS = {
  OPEN_YOUTUBE: {
    id: 'open-youtube',
    bn: 'আমি YouTube খুলছি।',
    en: 'Opening YouTube for you.',
    category: 'launcher' as const,
    timestamp: '',
  },
  OPEN_GALLERY: {
    id: 'open-gallery',
    bn: 'আমি Gallery খুলছি।',
    en: 'Opening Gallery for you.',
    category: 'media' as const,
    timestamp: '',
  },
  PREPARE_CALL: {
    id: 'prepare-call',
    bn: 'আমি কল করার প্রস্তুতি নিচ্ছি।',
    en: 'Preparing to place the phone call.',
    category: 'call' as const,
    timestamp: '',
  },
  PREPARE_MESSAGE: {
    id: 'prepare-message',
    bn: 'আমি মেসেজ পাঠানোর প্রস্তুতি নিচ্ছি।',
    en: 'Preparing to compose the message.',
    category: 'message' as const,
    timestamp: '',
  },
  ACTION_COMPLETED: {
    id: 'action-completed',
    bn: 'কাজটি সম্পন্ন হয়েছে।',
    en: 'Action completed successfully.',
    category: 'system' as const,
    timestamp: '',
  },
  PERMISSION_REQUIRED: {
    id: 'permission-required',
    bn: 'এই কাজের জন্য প্রয়োজনীয় অনুমতি প্রয়োজন।',
    en: 'This action requires user authorization.',
    category: 'system' as const,
    timestamp: '',
  },
  ACTION_CANCELLED: {
    id: 'action-cancelled',
    bn: 'অনুরোধটি বাতিল করা হয়েছে।',
    en: 'Action has been cancelled.',
    category: 'system' as const,
    timestamp: '',
  },
  NOTIFICATIONS_READING: {
    id: 'notifications-reading',
    bn: 'আমি নোটিফিকেশন সারসংক্ষেপ করছি।',
    en: 'Summarizing active notifications with privacy protection.',
    category: 'notification' as const,
    timestamp: '',
  },
  ACCESSIBILITY_TRIGGERED: {
    id: 'accessibility-triggered',
    bn: 'অ্যাক্সেসিবিলিটি সার্ভিস সক্রিয়।',
    en: 'Accessibility Service executing authorized action.',
    category: 'accessibility' as const,
    timestamp: '',
  },
  INCOMING_CALL: {
    id: 'incoming-call',
    bn: 'ইনকামিং ফোন কল এসেছে।',
    en: 'Incoming phone call detected.',
    category: 'call' as const,
    timestamp: '',
  },
  CALL_ANSWERED: {
    id: 'call-answered',
    bn: 'কল গ্রহণ করা হয়েছে।',
    en: 'Incoming call answered.',
    category: 'call' as const,
    timestamp: '',
  },
  CALL_REJECTED: {
    id: 'call-rejected',
    bn: 'কল বাতিল করা হয়েছে।',
    en: 'Incoming call rejected.',
    category: 'call' as const,
    timestamp: '',
  },
};

type AnnouncementListener = (announcement: ActionAnnouncement | null) => void;
let listeners: AnnouncementListener[] = [];
let currentAnnouncement: ActionAnnouncement | null = null;
let clearTimer: any = null;

export function subscribeToAnnouncements(cb: AnnouncementListener): () => void {
  listeners.push(cb);
  cb(currentAnnouncement);
  return () => {
    listeners = listeners.filter((l) => l !== cb);
  };
}

function broadcast(announcement: ActionAnnouncement | null) {
  currentAnnouncement = announcement;
  listeners.forEach((l) => {
    try {
      l(announcement);
    } catch {}
  });
}

export async function announceAction(
  announcementData: {
    bn: string;
    en: string;
    id?: string;
    category?: 'launcher' | 'call' | 'message' | 'media' | 'accessibility' | 'notification' | 'system';
    timestamp?: string;
  },
  options: { language?: 'bn' | 'en' | 'auto'; mood?: string; skipAudio?: boolean } = {}
): Promise<void> {
  const { language = 'auto', mood = 'sassy', skipAudio = false } = options;
  const id = (announcementData as any).id || `ann-${Date.now()}`;
  const category = (announcementData as any).category || 'system';

  const fullAnnouncement: ActionAnnouncement = {
    id,
    bn: announcementData.bn,
    en: announcementData.en,
    category,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
  };

  // Broadcast to visual HUD
  broadcast(fullAnnouncement);

  if (clearTimer) clearTimeout(clearTimer);
  clearTimer = setTimeout(() => {
    broadcast(null);
  }, 4500);

  // Play voice announcement
  if (!skipAudio) {
    const text = language === 'bn' ? fullAnnouncement.bn : language === 'en' ? fullAnnouncement.en : fullAnnouncement.bn;
    try {
      await speakWithBrowserSynthesis(text, mood);
    } catch (err) {
      console.warn('Speech announcement fallback:', err);
    }
  }
}
