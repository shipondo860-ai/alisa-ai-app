import { AndroidPermissionItem, AndroidPermissionKey, PermissionState } from '../types/assistant';

const STORAGE_KEY = 'alisa_android_permissions_state';

const DEFAULT_PERMISSIONS: AndroidPermissionItem[] = [
  {
    key: 'microphone',
    name: 'Microphone',
    androidPermission: 'android.permission.RECORD_AUDIO',
    description: 'Required for real-time voice conversation and voice command listening.',
    status: 'prompt',
    isRequiredFor: ['Live Voice API', 'Voice Command Engine', 'Speech Recognition'],
  },
  {
    key: 'phone',
    name: 'Phone & Dialer',
    androidPermission: 'android.permission.CALL_PHONE',
    description: 'Allows Alisa to launch dialer and initiate voice calls after user confirmation.',
    status: 'granted',
    isRequiredFor: ['Outgoing Calls', 'Call Control Module'],
  },
  {
    key: 'contacts',
    name: 'Contacts',
    androidPermission: 'android.permission.READ_CONTACTS',
    description: 'Allows Alisa to resolve contact names into phone numbers for calls and SMS.',
    status: 'prompt',
    isRequiredFor: ['Call by Name', 'Message by Name', 'Contact Lookup'],
  },
  {
    key: 'notifications',
    name: 'Notification Access',
    androidPermission: 'android.permission.POST_NOTIFICATIONS',
    description: 'Allows Alisa to read, summarize and deliver notifications securely without exposing private contents.',
    status: 'prompt',
    isRequiredFor: ['Notification Summary', 'Alert Reading', 'Background Alerts'],
  },
  {
    key: 'accessibility',
    name: 'Accessibility Service',
    androidPermission: 'android.permission.BIND_ACCESSIBILITY_SERVICE',
    description: 'Enables user-authorized UI interactions: tap, scroll, back, and navigate allowed fields.',
    status: 'granted',
    isRequiredFor: ['UI Navigation', 'Screen Scroll', 'Assistant Back Button', 'Field Input'],
  },
  {
    key: 'camera',
    name: 'Camera',
    androidPermission: 'android.permission.CAMERA',
    description: 'Allows taking photos and launching camera capture workflows.',
    status: 'prompt',
    isRequiredFor: ['Live Camera Capture', 'Photo Workflow'],
  },
  {
    key: 'photos_files',
    name: 'Photos & Files',
    androidPermission: 'android.permission.READ_MEDIA_IMAGES',
    description: 'Allows Alisa to open Gallery, import selected photos, and apply creative edits with user consent.',
    status: 'granted',
    isRequiredFor: ['Gallery Launcher', 'Photo Editor', 'Media Workflow'],
  },
  {
    key: 'bluetooth',
    name: 'Bluetooth',
    androidPermission: 'android.permission.BLUETOOTH_CONNECT',
    description: 'Connects to wireless earbuds, microphones, and smart wearables.',
    status: 'prompt',
    isRequiredFor: ['Earbuds Audio', 'Smart Headset Controls'],
  },
  {
    key: 'location',
    name: 'Location',
    androidPermission: 'android.permission.ACCESS_FINE_LOCATION',
    description: 'Provides local weather, nearby places, and accurate geographic grounding.',
    status: 'prompt',
    isRequiredFor: ['Nearby Navigation', 'Local Weather', 'Maps Grounding'],
  },
  {
    key: 'install_unknown_apps',
    name: 'Install Unknown Apps',
    androidPermission: 'android.permission.REQUEST_INSTALL_PACKAGES',
    description: 'Special Android 15 security permission required to launch package installer sessions for APKs from non-Store sources.',
    status: 'prompt',
    isRequiredFor: ['APK Installer Module', 'System PackageInstaller Session', 'Android 15 Unknown App Sources'],
  },
];

export async function getAndroidPermissions(): Promise<AndroidPermissionItem[]> {
  let stored: Partial<Record<AndroidPermissionKey, PermissionState>> = {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) stored = JSON.parse(raw);
  } catch {}

  const result = [...DEFAULT_PERMISSIONS];

  // Check real browser/device permissions where available
  for (const item of result) {
    const savedState = stored[item.key];
    if (savedState) {
      item.status = savedState;
    }

    try {
      if (item.key === 'notifications' && 'Notification' in window) {
        if (Notification.permission === 'granted') item.status = 'granted';
        else if (Notification.permission === 'denied') item.status = 'denied';
      } else if (item.key === 'microphone' && navigator.permissions?.query) {
        const query = await navigator.permissions.query({ name: 'microphone' as any });
        if (query.state === 'granted') item.status = 'granted';
        else if (query.state === 'denied') item.status = 'denied';
      } else if (item.key === 'camera' && navigator.permissions?.query) {
        const query = await navigator.permissions.query({ name: 'camera' as any });
        if (query.state === 'granted') item.status = 'granted';
        else if (query.state === 'denied') item.status = 'denied';
      } else if (item.key === 'location' && navigator.permissions?.query) {
        const query = await navigator.permissions.query({ name: 'geolocation' as any });
        if (query.state === 'granted') item.status = 'granted';
        else if (query.state === 'denied') item.status = 'denied';
      }
    } catch {}
  }

  return result;
}

export async function requestAndroidPermission(
  key: AndroidPermissionKey
): Promise<{ success: boolean; state: PermissionState; message: string }> {
  try {
    if (key === 'microphone') {
      if (!navigator.mediaDevices?.getUserMedia) {
        savePermissionState(key, 'denied');
        return {
          success: false,
          state: 'denied',
          message: 'Microphone hardware or getUserMedia API is unavailable in this environment.',
        };
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((t) => t.stop());
        savePermissionState(key, 'granted');
        return { success: true, state: 'granted', message: 'Microphone permission granted (android.permission.RECORD_AUDIO).' };
      } catch (micErr: any) {
        savePermissionState(key, 'denied');
        return {
          success: false,
          state: 'denied',
          message: 'Microphone access denied by browser or system policy (android.permission.RECORD_AUDIO).',
        };
      }
    }

    if (key === 'camera') {
      if (!navigator.mediaDevices?.getUserMedia) {
        savePermissionState(key, 'denied');
        return { success: false, state: 'denied', message: 'Camera hardware is unavailable in this environment.' };
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        stream.getTracks().forEach((t) => t.stop());
        savePermissionState(key, 'granted');
        return { success: true, state: 'granted', message: 'Camera permission granted (android.permission.CAMERA).' };
      } catch (camErr: any) {
        savePermissionState(key, 'denied');
        return { success: false, state: 'denied', message: 'Camera permission denied by browser or system.' };
      }
    }

    if (key === 'notifications') {
      if (!('Notification' in window)) {
        return { success: false, state: 'denied', message: 'Notifications not supported on this browser.' };
      }
      const perm = await Notification.requestPermission();
      const state: PermissionState = perm === 'granted' ? 'granted' : 'denied';
      savePermissionState(key, state);
      return {
        success: perm === 'granted',
        state,
        message: perm === 'granted' ? 'Notifications permission granted.' : 'Notifications permission denied by user.',
      };
    }

    if (key === 'location') {
      return new Promise((resolve) => {
        if (!navigator.geolocation) {
          savePermissionState(key, 'denied');
          resolve({ success: false, state: 'denied', message: 'Geolocation is not supported.' });
          return;
        }
        navigator.geolocation.getCurrentPosition(
          () => {
            savePermissionState(key, 'granted');
            resolve({ success: true, state: 'granted', message: 'Location permission granted.' });
          },
          (err) => {
            savePermissionState(key, 'denied');
            resolve({ success: false, state: 'denied', message: `Location permission denied: ${err.message}` });
          }
        );
      });
    }

    if (key === 'accessibility') {
      // Toggle accessibility authorization
      savePermissionState(key, 'granted');
      return { success: true, state: 'granted', message: 'Accessibility service interactions authorized by user.' };
    }

    if (key === 'contacts') {
      if ('contacts' in navigator && 'ContactsManager' in window) {
        savePermissionState(key, 'granted');
        return { success: true, state: 'granted', message: 'Contacts API supported on this Android device.' };
      }
      savePermissionState(key, 'granted');
      return { success: true, state: 'granted', message: 'Contacts access simulated/granted.' };
    }

    // Default for other Android permissions (photos, phone, bluetooth)
    savePermissionState(key, 'granted');
    return { success: true, state: 'granted', message: `${key} permission enabled.` };
  } catch (err: any) {
    savePermissionState(key, 'denied');
    return {
      success: false,
      state: 'denied',
      message: `Permission denied: ${err?.message || 'User cancelled permission prompt.'}`,
    };
  }
}

export async function toggleAndroidPermission(
  key: AndroidPermissionKey
): Promise<{ success: boolean; state: PermissionState; message: string }> {
  const isGranted = await isPermissionGranted(key);
  if (isGranted) {
    savePermissionState(key, 'denied');
    return { success: true, state: 'denied', message: `${key} permission revoked.` };
  }
  return requestAndroidPermission(key);
}

export function savePermissionState(key: AndroidPermissionKey, state: PermissionState): void {
  try {
    let current: Record<string, PermissionState> = {};
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) current = JSON.parse(raw);
    current[key] = state;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(current));
  } catch {}
}

export async function isPermissionGranted(key: AndroidPermissionKey): Promise<boolean> {
  const perms = await getAndroidPermissions();
  const found = perms.find((p) => p.key === key);
  return found?.status === 'granted';
}
