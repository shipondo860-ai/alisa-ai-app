import { AndroidApp } from '../types/assistant';
import { addActivityLog } from './actionLog';
import { announceAction, COMMON_ANNOUNCEMENTS } from './actionAnnouncer';

export const ANDROID_APPS_REGISTRY: AndroidApp[] = [
  {
    id: 'youtube',
    name: 'YouTube',
    category: 'media',
    packageName: 'com.google.android.youtube',
    intentUrl: 'intent://www.youtube.com/#Intent;package=com.google.android.youtube;scheme=https;end',
    webFallbackUrl: 'https://youtube.com',
    icon: '▶️',
    aliases: ['youtube', 'ইউটিউব', 'yt', 'video', 'ভিডিও'],
  },
  {
    id: 'gallery',
    name: 'Gallery / Photos',
    category: 'media',
    packageName: 'com.google.android.apps.photos',
    intentUrl: 'intent:#Intent;action=android.intent.action.VIEW;type=image/*;end',
    webFallbackUrl: '#gallery',
    icon: '🖼️',
    aliases: ['gallery', 'গ্যালারি', 'photos', 'ছবি', 'photo', 'images', 'পিকচার'],
  },
  {
    id: 'camera',
    name: 'Camera',
    category: 'media',
    packageName: 'com.android.camera',
    intentUrl: 'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end',
    webFallbackUrl: '#camera',
    icon: '📷',
    aliases: ['camera', 'ক্যামেরা', 'cam', 'take photo'],
  },
  {
    id: 'phone',
    name: 'Phone / Dialer',
    category: 'communication',
    packageName: 'com.google.android.dialer',
    intentUrl: 'tel:',
    webFallbackUrl: 'tel:',
    icon: '📞',
    aliases: ['phone', 'ফোন', 'dialer', 'ডায়ালার', 'call', 'কল'],
  },
  {
    id: 'contacts',
    name: 'Contacts',
    category: 'communication',
    packageName: 'com.google.android.contacts',
    intentUrl: 'content://contacts/people',
    webFallbackUrl: '#contacts',
    icon: '👥',
    aliases: ['contacts', 'কন্টাক্টস', 'people', 'যোগাযোগ', 'address book'],
  },
  {
    id: 'browser',
    name: 'Chrome / Web Browser',
    category: 'tools',
    packageName: 'com.android.chrome',
    intentUrl: 'https://',
    webFallbackUrl: '#browser',
    icon: '🌐',
    aliases: ['browser', 'ব্রাউজার', 'chrome', 'ক্রোম', 'web', 'internet'],
  },
  {
    id: 'messages',
    name: 'Messages / SMS',
    category: 'communication',
    packageName: 'com.google.android.apps.messaging',
    intentUrl: 'sms:',
    webFallbackUrl: 'sms:',
    icon: '💬',
    aliases: ['messages', 'মেসেজ', 'sms', 'টেক্সট', 'text'],
  },
  {
    id: 'settings',
    name: 'Settings',
    category: 'system',
    packageName: 'com.android.settings',
    intentUrl: 'intent:#Intent;action=android.settings.SETTINGS;end',
    webFallbackUrl: '#settings',
    icon: '⚙️',
    aliases: ['settings', 'সেটিংস', 'system settings'],
  },
  {
    id: 'maps',
    name: 'Google Maps',
    category: 'tools',
    packageName: 'com.google.android.apps.maps',
    intentUrl: 'geo:0,0?q=',
    webFallbackUrl: 'https://maps.google.com',
    icon: '🗺️',
    aliases: ['maps', 'ম্যাপস', 'map', 'দিকনির্দশন', 'navigation'],
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp',
    category: 'communication',
    packageName: 'com.whatsapp',
    intentUrl: 'whatsapp://send',
    webFallbackUrl: 'https://web.whatsapp.com',
    icon: '🟢',
    aliases: ['whatsapp', 'হোয়াটসঅ্যাপ', 'wa'],
  },
  {
    id: 'calculator',
    name: 'Calculator',
    category: 'tools',
    packageName: 'com.google.android.calculator',
    intentUrl: 'intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.APP_CALCULATOR;end',
    webFallbackUrl: '#calculator',
    icon: '🔢',
    aliases: ['calculator', 'ক্যালকুলেটর', 'calc', 'হিসাব'],
  },
  {
    id: 'clock',
    name: 'Clock & Alarms',
    category: 'tools',
    packageName: 'com.google.android.deskclock',
    intentUrl: 'intent:#Intent;action=android.intent.action.SHOW_ALARMS;end',
    webFallbackUrl: '#clock',
    icon: '⏰',
    aliases: ['clock', 'ঘড়ি', 'alarm', 'অ্যালার্ম', 'timer'],
  },
  {
    id: 'chrome',
    name: 'Chrome Browser',
    category: 'tools',
    packageName: 'com.android.chrome',
    intentUrl: 'intent://google.com#Intent;scheme=https;package=com.android.chrome;end',
    webFallbackUrl: 'https://google.com',
    icon: '🌐',
    aliases: ['chrome', 'ক্রোম', 'browser', 'ইন্টারনেট', 'web'],
  },
];

export function findAppByQuery(query: string): AndroidApp | undefined {
  const normalized = query.toLowerCase().trim();
  return ANDROID_APPS_REGISTRY.find((app) => {
    if (app.name.toLowerCase().includes(normalized)) return true;
    if (app.id.toLowerCase() === normalized) return true;
    return app.aliases.some((alias) => normalized.includes(alias.toLowerCase()));
  });
}

export async function launchAndroidApp(
  app: AndroidApp,
  userSpeechPrompt: string = `Open ${app.name}`
): Promise<{ success: boolean; message: string; method: string }> {
  // 1. Announce action before performing (Module 8)
  if (app.id === 'youtube') {
    await announceAction(COMMON_ANNOUNCEMENTS.OPEN_YOUTUBE);
  } else if (app.id === 'gallery') {
    await announceAction(COMMON_ANNOUNCEMENTS.OPEN_GALLERY);
  } else {
    await announceAction({
      id: `open-${app.id}`,
      bn: `আমি ${app.name} খুলছি।`,
      en: `Opening ${app.name} for you.`,
      category: 'launcher',
      timestamp: '',
    });
  }

  // 2. Perform launch via Android supported mechanism without window.open
  let method = 'Android Intent';

  try {
    const isAndroid = /android/i.test(navigator.userAgent);

    if (app.id === 'phone' || app.intentUrl.startsWith('tel:')) {
      window.location.href = app.intentUrl;
      method = 'Android Telephony Intent (tel:)';
    } else if (app.id === 'messages' || app.intentUrl.startsWith('sms:')) {
      window.location.href = app.intentUrl;
      method = 'Android Messaging Intent (sms:)';
    } else if (isAndroid && app.intentUrl.startsWith('intent:')) {
      // Direct Android package intent dispatch
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = app.intentUrl;
      document.body.appendChild(iframe);
      setTimeout(() => {
        try {
          document.body.removeChild(iframe);
        } catch {}
      }, 2000);
      method = `Android Package Intent (${app.packageName})`;
    } else {
      // Internal state hash or anchor navigation (strictly avoids window.open)
      if (app.webFallbackUrl.startsWith('http')) {
        // Safe navigation or iframe trigger
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        iframe.src = app.intentUrl;
        document.body.appendChild(iframe);
        setTimeout(() => {
          try {
            document.body.removeChild(iframe);
          } catch {}
        }, 1500);
        method = `Android Deep Link Intent (${app.packageName})`;
      } else {
        window.location.hash = app.webFallbackUrl;
        method = 'Android In-App Supported Workflow';
      }
    }
  } catch (err: any) {
    const errorMsg = `Android restriction: Unable to dispatch intent (${err?.message || 'Blocked'}).`;
    addActivityLog(userSpeechPrompt, `App Launcher: ${app.name}`, 'failed', errorMsg);
    return { success: false, message: errorMsg, method: 'None' };
  }

  const successMessage = `${app.name} opened successfully via ${method}.`;
  addActivityLog(userSpeechPrompt, `App Launcher: ${app.name}`, 'success', successMessage);

  return {
    success: true,
    message: successMessage,
    method,
  };
}
