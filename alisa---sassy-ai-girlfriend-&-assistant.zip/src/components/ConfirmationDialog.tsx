import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Phone,
  MessageSquare,
  Trash2,
  Settings,
  ShieldAlert,
  Check,
  X,
  Mic,
} from 'lucide-react';
import { ConfirmationRequest } from '../types/assistant';

interface ConfirmationDialogProps {
  request: ConfirmationRequest | null;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmationDialog: React.FC<ConfirmationDialogProps> = ({
  request,
  onConfirm,
  onCancel,
}) => {
  const [countdown, setCountdown] = useState<number>(15);

  useEffect(() => {
    if (!request) return;
    setCountdown(15);
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          onCancel(); // auto-cancel safety timeout
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [request]);

  if (!request) return null;

  const getActionIcon = () => {
    switch (request.actionType) {
      case 'call':
        return <Phone className="w-6 h-6 text-emerald-400" />;
      case 'message':
        return <MessageSquare className="w-6 h-6 text-cyan-400" />;
      case 'delete':
        return <Trash2 className="w-6 h-6 text-red-400" />;
      case 'setting':
        return <Settings className="w-6 h-6 text-amber-400" />;
      default:
        return <ShieldAlert className="w-6 h-6 text-rose-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl space-y-4">
        {/* Top Warning Banner */}
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex-shrink-0">
            {getActionIcon()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold uppercase tracking-wider">
                {request.impactLevel.toUpperCase()} IMPACT
              </span>
              <span className="text-xs font-mono text-neutral-500">
                Auto-cancel in {countdown}s
              </span>
            </div>
            <h3 className="font-display font-bold text-base text-white mt-1 truncate">
              {request.title}
            </h3>
          </div>
        </div>

        {/* Action Details Box */}
        <div className="p-4 rounded-2xl bg-neutral-950/70 border border-neutral-800 text-xs space-y-2">
          <p className="text-neutral-300 font-medium leading-relaxed">
            {request.description}
          </p>

          {request.targetDetails.recipient && (
            <div className="flex justify-between py-1 border-t border-neutral-800/80">
              <span className="text-neutral-500">Recipient:</span>
              <span className="font-semibold text-neutral-200">
                {request.targetDetails.recipient}
              </span>
            </div>
          )}

          {request.targetDetails.phoneNumber && (
            <div className="flex justify-between py-1 border-t border-neutral-800/80">
              <span className="text-neutral-500">Phone Number:</span>
              <span className="font-mono text-emerald-400">
                {request.targetDetails.phoneNumber}
              </span>
            </div>
          )}

          {request.targetDetails.messageBody && (
            <div className="py-1 border-t border-neutral-800/80">
              <span className="text-neutral-500 block mb-1">Message Preview:</span>
              <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-200 italic font-sans">
                &ldquo;{request.targetDetails.messageBody}&rdquo;
              </div>
            </div>
          )}

          {request.targetDetails.additionalInfo && (
            <p className="text-[11px] text-neutral-500 pt-1 border-t border-neutral-800/80">
              {request.targetDetails.additionalInfo}
            </p>
          )}
        </div>

        {/* Vocal confirmation tip */}
        <div className="flex items-center gap-2 p-2.5 rounded-xl bg-neutral-950/40 border border-neutral-800/60 text-[11px] text-neutral-400">
          <Mic className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
          <span>You can confirm with voice (&ldquo;Yes / নিশ্চিত&rdquo;) or tap below:</span>
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-3 pt-2">
          <button
            onClick={onCancel}
            className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
            <span>Cancel (বাতিল)</span>
          </button>

          <button
            onClick={onConfirm}
            className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/40 transition-all cursor-pointer active:scale-95"
          >
            <Check className="w-4 h-4" />
            <span>Confirm & Proceed</span>
          </button>
        </div>
      </div>
    </div>
  );
};
