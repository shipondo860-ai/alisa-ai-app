import React, { useState, useEffect, useRef } from 'react';
import {
  Globe,
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Home,
  Plus,
  X,
  Search,
  ExternalLink,
  Shield,
  ShieldAlert,
  BookOpen,
  History,
  Sparkles,
  Play,
  Pause,
  Youtube,
  Clock,
  Trash2,
  Lock,
  Maximize2,
  Minimize2,
  Tv,
} from 'lucide-react';
import { browserService, BrowserState, BrowserTab } from '../services/browserService';

interface RealWebBrowserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAskMyraa?: (question: string) => void;
}

export const RealWebBrowserModal: React.FC<RealWebBrowserModalProps> = ({
  isOpen,
  onClose,
  onAskMyraa,
}) => {
  const [browserState, setBrowserState] = useState<BrowserState>(browserService.getState());
  const [addressInput, setAddressInput] = useState('');
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [pageAnalysis, setPageAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const activeTab = browserState.tabs.find((t) => t.id === browserState.activeTabId) || browserState.tabs[0];

  useEffect(() => {
    const unsub = browserService.subscribe((state) => {
      setBrowserState(state);
      const curTab = state.tabs.find((t) => t.id === state.activeTabId);
      if (curTab) {
        setAddressInput(curTab.displayUrl || '');
      }
    });

    return () => unsub();
  }, []);

  useEffect(() => {
    if (activeTab) {
      setAddressInput(activeTab.displayUrl || '');
      setPageAnalysis(null);
    }
  }, [activeTab?.id]);

  if (!isOpen && !browserState.isOpen) return null;

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (addressInput.trim()) {
      browserService.navigateActiveTab(addressInput.trim());
    }
  };

  // YouTube postMessage controls
  const handleYouTubeControl = (action: 'play' | 'pause') => {
    if (!iframeRef.current || !iframeRef.current.contentWindow) return;
    const command = action === 'play' ? 'playVideo' : 'pauseVideo';
    iframeRef.current.contentWindow.postMessage(
      JSON.stringify({ event: 'command', func: command, args: '' }),
      '*'
    );
  };

  // Ask Myraa to analyze or summarize current accessible page
  const handleAskPage = async (question: string) => {
    setIsAnalyzing(true);
    setPageAnalysis(null);

    const pageInfo = browserService.getActivePageContent();

    try {
      const res = await fetch('/api/browser/understand-page', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: pageInfo.url,
          title: pageInfo.title,
          content: pageInfo.content,
          question,
        }),
      });

      if (!res.ok) throw new Error('Analysis failed');
      const data = await res.json();
      setPageAnalysis(data.reply);
    } catch (err: any) {
      setPageAnalysis('Unable to read this page due to cross-origin security restrictions. Try opening it in an external tab!');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 md:p-5 bg-neutral-950/85 backdrop-blur-md animate-in fade-in">
      <div
        className={`relative w-full bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col transition-all duration-200 ${
          isFullScreen ? 'h-[98vh] max-w-full' : 'h-[90vh] max-w-5xl'
        }`}
      >
        {/* 1. Multi-Tab Bar */}
        <div className="px-3 pt-2 bg-neutral-950/90 border-b border-neutral-800/80 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {browserState.tabs.map((tab) => {
            const isActive = tab.id === browserState.activeTabId;
            return (
              <div
                key={tab.id}
                onClick={() => browserService.switchTab(tab.id)}
                className={`group relative flex items-center gap-2 px-3 py-1.5 rounded-t-xl text-xs font-medium cursor-pointer transition-all max-w-[200px] border-t border-x ${
                  isActive
                    ? 'bg-neutral-900 border-neutral-700/80 text-white shadow-sm'
                    : 'bg-neutral-950/60 border-transparent text-neutral-400 hover:bg-neutral-900/60 hover:text-neutral-200'
                }`}
              >
                {tab.isYouTube ? (
                  <Youtube className="w-3.5 h-3.5 text-red-500 shrink-0" />
                ) : tab.favicon ? (
                  <img
                    src={tab.favicon}
                    alt=""
                    className="w-3.5 h-3.5 rounded shrink-0 object-contain"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                ) : (
                  <Globe className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                )}

                <span className="truncate flex-1 text-[11px]">
                  {tab.title || (tab.url === 'about:home' ? 'Home' : 'New Tab')}
                </span>

                {/* Close Tab Button */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    browserService.closeTab(tab.id);
                  }}
                  className="p-0.5 rounded hover:bg-neutral-800 text-neutral-500 hover:text-white transition-all cursor-pointer opacity-70 group-hover:opacity-100"
                  title="Close tab"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}

          {/* New Tab Button */}
          <button
            onClick={() => browserService.createTab('about:home')}
            className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-all cursor-pointer"
            title="Open new tab"
          >
            <Plus className="w-4 h-4" />
          </button>

          <div className="flex-1" />

          {/* Window Action Controls */}
          <div className="flex items-center gap-1 pb-1">
            <button
              onClick={() => setIsFullScreen(!isFullScreen)}
              className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-all cursor-pointer"
              title={isFullScreen ? 'Exit Full Screen' : 'Full Screen'}
            >
              {isFullScreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => {
                browserService.closeBrowser();
                onClose();
              }}
              className="p-1.5 rounded-lg hover:bg-red-600/30 text-neutral-400 hover:text-red-400 transition-all cursor-pointer"
              title="Close Browser"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 2. Browser Navigation & Address Bar */}
        <div className="px-3 py-2 bg-neutral-900 border-b border-neutral-800 flex items-center gap-2">
          {/* Back / Forward / Refresh / Home Buttons */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => browserService.goBack()}
              disabled={!activeTab || activeTab.historyIndex <= 0}
              className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-300 disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer"
              title="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => browserService.goForward()}
              disabled={!activeTab || activeTab.historyIndex >= activeTab.history.length - 1}
              className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-300 disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer"
              title="Forward"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => browserService.refresh()}
              className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-300 transition-all cursor-pointer"
              title="Refresh"
            >
              <RotateCw className={`w-4 h-4 ${activeTab?.isLoading ? 'animate-spin text-cyan-400' : ''}`} />
            </button>
            <button
              onClick={() => browserService.goHome()}
              className="p-1.5 rounded-lg hover:bg-neutral-800 text-neutral-300 transition-all cursor-pointer"
              title="Home Portal"
            >
              <Home className="w-4 h-4" />
            </button>
          </div>

          {/* Address Bar Form */}
          <form onSubmit={handleAddressSubmit} className="flex-1 flex items-center relative">
            <div className="absolute left-3 flex items-center gap-1.5 text-neutral-500 pointer-events-none">
              {activeTab?.url.startsWith('https://') ? (
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Search className="w-3.5 h-3.5" />
              )}
            </div>

            <input
              type="text"
              value={addressInput}
              onChange={(e) => setAddressInput(e.target.value)}
              placeholder="Search web or enter address (e.g. 'AI news', 'youtube.com', 'wikipedia.org')..."
              className="w-full pl-9 pr-24 py-1.5 bg-neutral-950 border border-neutral-700/80 focus:border-cyan-500/80 rounded-xl text-xs text-white placeholder-neutral-500 outline-none transition-all shadow-inner font-mono"
            />

            {/* Launch External Link Button inside address bar */}
            {activeTab?.url && activeTab.url !== 'about:home' && (
              <a
                href={activeTab.url}
                target="_blank"
                rel="noopener noreferrer"
                className="absolute right-2 px-2 py-0.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white text-[10px] font-mono flex items-center gap-1 transition-all"
                title="Launch in external browser tab"
              >
                <span>Open Tab</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </form>

          {/* YouTube Controls if active on YouTube */}
          {activeTab?.isYouTube && (
            <div className="flex items-center gap-1 px-2 py-1 rounded-xl bg-red-950/40 border border-red-500/30">
              <button
                onClick={() => handleYouTubeControl('play')}
                className="p-1 rounded text-red-400 hover:text-white hover:bg-red-600/30 cursor-pointer"
                title="Play video"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
              </button>
              <button
                onClick={() => handleYouTubeControl('pause')}
                className="p-1 rounded text-red-400 hover:text-white hover:bg-red-600/30 cursor-pointer"
                title="Pause video"
              >
                <Pause className="w-3.5 h-3.5 fill-current" />
              </button>
            </div>
          )}

          {/* Reader Mode Toggle */}
          {activeTab?.extractedText && (
            <button
              onClick={() => browserService.toggleReaderMode()}
              className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 transition-all cursor-pointer ${
                activeTab.isReaderMode
                  ? 'bg-purple-950/70 border-purple-500 text-purple-300'
                  : 'bg-neutral-800 hover:bg-neutral-700 border-neutral-700 text-neutral-300'
              }`}
              title="Toggle Reader Mode"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span className="text-[11px] hidden sm:inline">Reader</span>
            </button>
          )}

          {/* History Drawer Toggle */}
          <button
            onClick={() => browserService.toggleHistoryDrawer()}
            className={`p-1.5 rounded-lg border text-xs transition-all cursor-pointer ${
              browserState.isHistoryDrawerOpen
                ? 'bg-cyan-950/70 border-cyan-500 text-cyan-300'
                : 'bg-neutral-800 hover:bg-neutral-700 border-neutral-700 text-neutral-300'
            }`}
            title="Browsing History"
          >
            <History className="w-4 h-4" />
          </button>
        </div>

        {/* 3. Page AI Understanding Bar */}
        <div className="px-4 py-1.5 bg-neutral-950/90 border-b border-neutral-800/80 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
            <span className="text-[10px] font-semibold text-rose-400 flex items-center gap-1 uppercase tracking-wider shrink-0">
              <Sparkles className="w-3 h-3" />
              <span>Ask Myraa:</span>
            </span>

            {[
              'What is on this page?',
              'Summarize this page',
              'What website is this?',
              'Read this article',
            ].map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleAskPage(prompt)}
                disabled={isAnalyzing}
                className="px-2.5 py-0.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-[11px] text-neutral-300 hover:text-white transition-all whitespace-nowrap cursor-pointer disabled:opacity-50"
              >
                {prompt}
              </button>
            ))}
          </div>

          {isAnalyzing && (
            <span className="text-[11px] text-cyan-400 flex items-center gap-1.5 animate-pulse shrink-0 ml-2">
              <RotateCw className="w-3 h-3 animate-spin" />
              <span>Reading accessible content...</span>
            </span>
          )}
        </div>

        {/* AI Analysis Overlay Dropdown if answered */}
        {pageAnalysis && (
          <div className="p-3 bg-neutral-950 border-b border-cyan-500/30 text-xs flex items-start justify-between gap-3 animate-in fade-in">
            <div className="space-y-1">
              <div className="flex items-center gap-1.5 text-cyan-400 font-semibold text-[11px]">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Myraa's Page Analysis:</span>
              </div>
              <p className="text-neutral-200 text-xs leading-relaxed max-h-32 overflow-y-auto whitespace-pre-line pr-2">
                {pageAnalysis}
              </p>
            </div>
            <button
              onClick={() => setPageAnalysis(null)}
              className="text-neutral-500 hover:text-white text-xs cursor-pointer p-1"
            >
              ×
            </button>
          </div>
        )}

        {/* 4. Main Web Content Display Area */}
        <div className="relative flex-1 bg-neutral-950 overflow-hidden flex">
          {/* A. HOME PORTAL (about:home) */}
          {activeTab?.url === 'about:home' ? (
            <div className="w-full h-full p-6 md:p-10 overflow-y-auto flex flex-col items-center justify-center text-center">
              <div className="max-w-xl w-full">
                <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-rose-500 to-purple-600 flex items-center justify-center mx-auto mb-4 shadow-xl shadow-rose-950/40">
                  <Globe className="w-8 h-8 text-white" />
                </div>
                <h2 className="font-display font-bold text-2xl text-white mb-2">
                  Myraa Web Browser
                </h2>
                <p className="text-xs text-neutral-400 mb-6">
                  Fast, real multi-tab browsing with page understanding and YouTube playback controls.
                </p>

                {/* Quick Search */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (addressInput.trim()) {
                      browserService.navigateActiveTab(addressInput.trim());
                    }
                  }}
                  className="mb-8 relative"
                >
                  <Search className="w-4 h-4 text-neutral-500 absolute left-4 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={addressInput}
                    onChange={(e) => setAddressInput(e.target.value)}
                    placeholder="Search AI news, videos, or type any URL..."
                    className="w-full pl-11 pr-24 py-3 bg-neutral-900 border border-neutral-700/80 focus:border-rose-500 rounded-2xl text-sm text-white placeholder-neutral-500 outline-none shadow-xl"
                  />
                  <button
                    type="submit"
                    className="absolute right-2 top-1/2 -translate-y-1/2 px-4 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white font-semibold text-xs cursor-pointer"
                  >
                    Go
                  </button>
                </form>

                {/* Bookmarks Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left">
                  {[
                    {
                      title: 'YouTube AI Search',
                      desc: 'AI Visionary Ayush videos',
                      url: 'https://www.youtube.com/results?search_query=AI+Visionary+Ayush',
                      icon: Youtube,
                      color: 'text-red-400',
                    },
                    {
                      title: 'AI News (DuckDuckGo)',
                      desc: 'Latest AI breakthroughs',
                      url: 'https://duckduckgo.com/?q=latest+artificial+intelligence+news',
                      icon: Globe,
                      color: 'text-cyan-400',
                    },
                    {
                      title: 'Wikipedia',
                      desc: 'Free encyclopedia',
                      url: 'https://en.wikipedia.org/wiki/Artificial_intelligence',
                      icon: BookOpen,
                      color: 'text-emerald-400',
                    },
                    {
                      title: 'ChatGPT',
                      desc: 'OpenAI conversational AI',
                      url: 'https://chatgpt.com',
                      icon: Sparkles,
                      color: 'text-purple-400',
                    },
                  ].map((bookmark, idx) => {
                    const BIcon = bookmark.icon;
                    return (
                      <button
                        key={idx}
                        onClick={() => browserService.navigateActiveTab(bookmark.url)}
                        className="p-3.5 rounded-2xl bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 text-left transition-all cursor-pointer group active:scale-95"
                      >
                        <BIcon className={`w-5 h-5 ${bookmark.color} mb-2`} />
                        <h4 className="text-xs font-semibold text-white group-hover:text-rose-400 transition-colors">
                          {bookmark.title}
                        </h4>
                        <p className="text-[10px] text-neutral-500 line-clamp-1">
                          {bookmark.desc}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : activeTab?.isReaderMode && activeTab?.extractedText ? (
            /* B. CLEAN READER VIEW */
            <div className="w-full h-full overflow-y-auto p-6 md:p-10 bg-neutral-950 text-neutral-200">
              <div className="max-w-2xl mx-auto space-y-4">
                <div className="border-b border-neutral-800 pb-3">
                  <span className="text-[10px] uppercase font-mono text-purple-400">
                    Myraa Reader Mode · Accessible Content
                  </span>
                  <h1 className="font-display font-bold text-xl text-white mt-1">
                    {activeTab.extractedTitle || activeTab.title}
                  </h1>
                  <p className="text-xs text-neutral-400 mt-1">{activeTab.url}</p>
                </div>
                <div className="text-sm leading-relaxed whitespace-pre-line space-y-3 font-serif">
                  {activeTab.extractedText}
                </div>
              </div>
            </div>
          ) : activeTab?.isYouTube && activeTab?.youtubeEmbedUrl ? (
            /* C. YOUTUBE EMBEDDED PLAYER WITH SUPPORTED CONTROLS */
            <div className="w-full h-full flex flex-col items-center justify-center bg-black">
              <iframe
                ref={iframeRef}
                src={activeTab.youtubeEmbedUrl}
                title={activeTab.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
                className="w-full h-full border-0"
              />
            </div>
          ) : activeTab?.canEmbed ? (
            /* D. REAL EMBEDDABLE IFRAME */
            <div className="relative w-full h-full">
              {activeTab.isLoading && (
                <div className="absolute inset-0 bg-neutral-950/80 z-10 flex items-center justify-center">
                  <RotateCw className="w-6 h-6 text-cyan-400 animate-spin" />
                </div>
              )}
              <iframe
                ref={iframeRef}
                src={activeTab.url}
                title={activeTab.title}
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                className="w-full h-full border-0 bg-white"
              />
            </div>
          ) : (
            /* E. CROSS-ORIGIN SECURITY RESTRICTION NOTICE (Never fake results) */
            <div className="w-full h-full p-6 md:p-10 flex flex-col items-center justify-center text-center overflow-y-auto">
              <div className="max-w-md p-6 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3 shadow-2xl">
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-400 w-fit mx-auto">
                  <ShieldAlert className="w-8 h-8" />
                </div>
                <h3 className="font-display font-bold text-white text-base">
                  Cross-Origin Policy Restricted
                </h3>
                <p className="text-xs text-neutral-300 leading-relaxed">
                  <span className="text-rose-300 font-mono">{activeTab?.url}</span> enforces{' '}
                  <code className="bg-neutral-950 px-1 py-0.5 rounded text-amber-300 font-mono text-[11px]">
                    X-Frame-Options: SAMEORIGIN
                  </code>{' '}
                  or Content Security Policy restrictions which prevent iframe embedding.
                </p>
                <p className="text-[11px] text-neutral-400">
                  Per security standards, Myraa does not fake restricted web pages. You can launch the site in an external browser tab or read the extracted text below.
                </p>

                <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
                  <a
                    href={activeTab?.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-lg active:scale-95 transition-all cursor-pointer"
                  >
                    <span>Open in External Tab</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>

                  {activeTab?.extractedText && (
                    <button
                      onClick={() => browserService.toggleReaderMode()}
                      className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <BookOpen className="w-3.5 h-3.5 text-purple-400" />
                      <span>Read Extracted Text</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* F. Slide-out History Drawer */}
          {browserState.isHistoryDrawerOpen && (
            <div className="absolute right-0 top-0 bottom-0 w-72 bg-neutral-900/98 border-l border-neutral-800 p-4 shadow-2xl z-20 flex flex-col animate-in slide-in-from-right duration-200">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-2 mb-3">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-cyan-400" />
                  <span>Browsing History</span>
                </span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => browserService.clearHistory()}
                    className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-red-400 transition-all cursor-pointer"
                    title="Clear history"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => browserService.toggleHistoryDrawer()}
                    className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white transition-all cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto space-y-1 pr-1">
                {browserState.history.length === 0 ? (
                  <p className="text-neutral-500 text-xs italic text-center py-6">
                    No history yet
                  </p>
                ) : (
                  browserState.history.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => {
                        browserService.navigateActiveTab(item.url);
                        browserService.toggleHistoryDrawer();
                      }}
                      className="w-full p-2 rounded-xl hover:bg-neutral-800/80 text-left transition-all cursor-pointer group"
                    >
                      <p className="text-xs font-medium text-neutral-200 group-hover:text-cyan-400 truncate">
                        {item.title}
                      </p>
                      <p className="text-[10px] text-neutral-500 truncate font-mono">
                        {item.url}
                      </p>
                    </button>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
