import React, { useState, useMemo } from 'react';
import {
  X,
  Brain,
  Trash2,
  Plus,
  Sparkles,
  Flame,
  Search,
  Edit3,
  Check,
  RotateCcw,
  ShieldAlert,
  Tag,
  Clock,
  Mic,
  MessageSquare,
  Bookmark,
  Gamepad2,
  Film,
  User,
  Coffee,
  Target,
  Briefcase,
  HelpCircle,
} from 'lucide-react';
import {
  MemoryCategory,
  MemoryItem,
  MEMORY_CATEGORY_LABELS,
  isSensitiveInformation,
  DEFAULT_INITIAL_MEMORIES,
} from '../services/memorySystem';

interface MemoryBankModalProps {
  isOpen: boolean;
  onClose: () => void;
  memories?: string[];
  memoryItems?: MemoryItem[];
  onAddMemory?: (memory: string, category?: MemoryCategory) => void;
  onAddMemoryItem?: (item: MemoryItem) => void;
  onCorrectMemory?: (id: string, newContent: string, newCategory?: MemoryCategory) => void;
  onDeleteMemory?: (index: number) => void;
  onDeleteMemoryItem?: (id: string) => void;
  onClearAllMemories?: () => void;
  onTestMemoryInChat: (query: string) => void;
}

export const MemoryBankModal: React.FC<MemoryBankModalProps> = ({
  isOpen,
  onClose,
  memories = [],
  memoryItems = [],
  onAddMemory,
  onAddMemoryItem,
  onCorrectMemory,
  onDeleteMemory,
  onDeleteMemoryItem,
  onClearAllMemories,
  onTestMemoryInChat,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [newMemoryText, setNewMemoryText] = useState('');
  const [newMemoryCategory, setNewMemoryCategory] = useState<MemoryCategory>('important_facts');
  const [privacyWarning, setPrivacyWarning] = useState<string | null>(null);

  // Editing state for Rule 6: "Allow the user to correct memories"
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContentText, setEditContentText] = useState('');
  const [editCategory, setEditCategory] = useState<MemoryCategory>('important_facts');

  // Normalize displayed memory items
  const normalizedItems: MemoryItem[] = useMemo(() => {
    if (memoryItems && memoryItems.length > 0) {
      return memoryItems;
    }
    // Fallback if only string memories passed
    return memories.map((str, idx) => ({
      id: `legacy_${idx}`,
      key: `key_${idx}`,
      category: 'important_facts' as MemoryCategory,
      content: str,
      confidence: 1.0,
      createdAt: Date.now() - idx * 3600000,
      updatedAt: Date.now() - idx * 3600000,
      source: 'manual',
      tags: [],
    }));
  }, [memoryItems, memories]);

  // Filter memories by search query and category
  const filteredMemories = useMemo(() => {
    return normalizedItems.filter((item) => {
      const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        item.content.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        (item.key && item.key.toLowerCase().includes(q)) ||
        item.tags.some((t) => t.toLowerCase().includes(q));

      return matchesCategory && matchesSearch;
    });
  }, [normalizedItems, selectedCategory, searchQuery]);

  if (!isOpen) return null;

  const handleAdd = () => {
    const trimmed = newMemoryText.trim();
    if (!trimmed) return;

    // Rule 2: Sensitive information filter check
    const sensitiveCheck = isSensitiveInformation(trimmed);
    if (sensitiveCheck.isSensitive) {
      setPrivacyWarning(
        `Privacy Guard: ${sensitiveCheck.reason}. For your security, Myraa will not store passwords, financial data, or sensitive PINs.`
      );
      return;
    }

    setPrivacyWarning(null);

    if (onAddMemoryItem) {
      const newItem: MemoryItem = {
        id: `mem_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        key: `${newMemoryCategory}_${Date.now()}`,
        category: newMemoryCategory,
        content: trimmed,
        rawContext: trimmed,
        confidence: 1.0,
        createdAt: Date.now(),
        updatedAt: Date.now(),
        source: 'manual',
        tags: [newMemoryCategory],
      };
      onAddMemoryItem(newItem);
    } else if (onAddMemory) {
      onAddMemory(trimmed, newMemoryCategory);
    }

    setNewMemoryText('');
  };

  const startEditing = (item: MemoryItem) => {
    setEditingId(item.id);
    setEditContentText(item.content);
    setEditCategory(item.category);
  };

  const saveCorrection = (id: string) => {
    const trimmed = editContentText.trim();
    if (!trimmed) return;

    // Check sensitive info
    const sensitiveCheck = isSensitiveInformation(trimmed);
    if (sensitiveCheck.isSensitive) {
      setPrivacyWarning(`Cannot save correction: ${sensitiveCheck.reason}`);
      return;
    }

    setPrivacyWarning(null);

    if (onCorrectMemory) {
      onCorrectMemory(id, trimmed, editCategory);
    }
    setEditingId(null);
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditContentText('');
  };

  const handleDelete = (id: string, index: number) => {
    if (onDeleteMemoryItem) {
      onDeleteMemoryItem(id);
    } else if (onDeleteMemory) {
      onDeleteMemory(index);
    }
  };

  const formatRelativeTime = (timestamp: number) => {
    const diffHours = Math.floor((Date.now() - timestamp) / (1000 * 60 * 60));
    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  const categoriesList: Array<{ id: string; label: string; icon: string }> = [
    { id: 'all', label: 'All Memories', icon: '🧠' },
    { id: 'favorite_games', label: 'Favorite Games', icon: '🎮' },
    { id: 'favorite_movies', label: 'Movies & Shows', icon: '🎬' },
    { id: 'favorite_creators', label: 'Creators', icon: '🎙️' },
    { id: 'preferences', label: 'Preferences', icon: '⭐' },
    { id: 'hobbies', label: 'Hobbies', icon: '🎨' },
    { id: 'projects', label: 'Projects & Work', icon: '🚀' },
    { id: 'goals', label: 'Goals', icon: '🎯' },
    { id: 'user_name', label: 'User Identity', icon: '👤' },
    { id: 'long_term_preferences', label: 'Habits & Routine', icon: '☕' },
    { id: 'conversation_preferences', label: 'Banter Style', icon: '💬' },
    { id: 'important_facts', label: 'Important Facts', icon: '📌' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-neutral-950/85 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-neutral-800 flex items-center justify-between bg-gradient-to-r from-rose-950/30 via-purple-950/30 to-neutral-900">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-rose-600/20 to-purple-600/20 border border-rose-500/30 text-rose-400">
              <Brain className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-lg text-white">
                  Myraa V2 Long-Term Memory System
                </h3>
                <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-mono font-semibold">
                  {normalizedItems.length} Stored Memories
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Persistent across sessions · Context-aware retrieval · Real-time corrections & forgetting
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 md:p-6 overflow-y-auto space-y-5 text-sm">
          {/* Privacy Alert Banner if triggered */}
          {privacyWarning && (
            <div className="p-3 rounded-2xl bg-amber-950/50 border border-amber-500/40 text-amber-200 text-xs flex items-center justify-between gap-2 animate-in fade-in">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>{privacyWarning}</span>
              </div>
              <button
                onClick={() => setPrivacyWarning(null)}
                className="text-amber-400 hover:text-white text-xs cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* Add / Teach New Memory Card */}
          <div className="p-4 rounded-2xl bg-neutral-950/70 border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-neutral-300">
              <span className="flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-rose-400" />
                <span>Teach Myraa a New Memory / Preference</span>
              </span>
              <span className="text-[11px] text-neutral-500 font-mono">Auto-Categorized</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              {/* Category selector */}
              <select
                value={newMemoryCategory}
                onChange={(e) => setNewMemoryCategory(e.target.value as MemoryCategory)}
                className="bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-neutral-200 focus:outline-none focus:border-rose-500/60 cursor-pointer"
              >
                {Object.entries(MEMORY_CATEGORY_LABELS).map(([catKey, info]) => (
                  <option key={catKey} value={catKey}>
                    {info.icon} {info.label}
                  </option>
                ))}
              </select>

              {/* Memory content input */}
              <input
                type="text"
                value={newMemoryText}
                onChange={(e) => setNewMemoryText(e.target.value)}
                placeholder="e.g., 'My favorite game is Free Fire', 'I work on Next.js', 'Call me Trouble'"
                className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-2 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500/60 transition-colors"
                onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
              />

              <button
                onClick={handleAdd}
                disabled={!newMemoryText.trim()}
                className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white text-xs font-semibold disabled:opacity-40 transition-all cursor-pointer shadow-md shadow-rose-950/30"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Store Memory</span>
              </button>
            </div>
          </div>

          {/* Quick Memory Test Shortcuts (Rules 8, 9, 10) */}
          <div className="p-3.5 rounded-2xl bg-neutral-950/50 border border-neutral-800">
            <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider block mb-2">
              ⚡ Test Natural Memory Recall (Context-Aware):
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                {
                  label: '🎮 "What is my favorite game?"',
                  query: 'What is my favorite game?',
                  desc: 'Tests game preference memory',
                },
                {
                  label: '☕ "Do you remember my drink of choice?"',
                  query: 'Do you remember what my favorite late night drink is?',
                  desc: 'Tests cutting chai habit recall',
                },
                {
                  label: '🎬 "Pop quiz: what do you remember about me?"',
                  query: 'Alisa, pop quiz! Tell me three personal things you remember about me right now.',
                  desc: 'Tests multi-item recall',
                },
                {
                  label: '📺 "Remember our YouTube channel deal?"',
                  query: 'Do you remember what my YouTube channel is, and what deal we made about AdSense?',
                  desc: 'Tests channel & AdSense lore',
                },
              ].map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    onTestMemoryInChat(item.query);
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800/80 text-left text-xs text-neutral-200 transition-all cursor-pointer flex items-center justify-between group active:scale-[0.98]"
                >
                  <div>
                    <p className="font-medium text-rose-300 group-hover:text-rose-200">{item.label}</p>
                    <p className="text-[10px] text-neutral-500">{item.desc}</p>
                  </div>
                  <Sparkles className="w-3.5 h-3.5 text-amber-400 opacity-60 group-hover:opacity-100 flex-shrink-0" />
                </button>
              ))}
            </div>
          </div>

          {/* Search & Category Filter Toolbar */}
          <div className="space-y-2.5">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2.5">
              {/* Search Bar */}
              <div className="relative w-full sm:w-72">
                <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search memories or tags..."
                  className="w-full pl-9 pr-3 py-1.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-rose-500/60 transition-colors"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-white text-xs cursor-pointer"
                  >
                    ×
                  </button>
                )}
              </div>

              {/* Memory Count & Clear All */}
              <div className="flex items-center gap-2 text-xs text-neutral-400 w-full sm:w-auto justify-between sm:justify-end">
                <span>
                  Showing <strong className="text-white">{filteredMemories.length}</strong> of{' '}
                  {normalizedItems.length}
                </span>
                {onClearAllMemories && normalizedItems.length > 0 && (
                  <button
                    onClick={() => {
                      if (window.confirm('Are you sure you want to clear all stored memories?')) {
                        onClearAllMemories();
                      }
                    }}
                    className="text-[11px] text-red-400/80 hover:text-red-400 cursor-pointer underline ml-2"
                  >
                    Clear All
                  </button>
                )}
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full text-xs scrollbar-none">
              {categoriesList.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all cursor-pointer flex items-center gap-1 text-[11px] font-medium ${
                    selectedCategory === cat.id
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-semibold'
                      : 'bg-neutral-950 text-neutral-400 hover:text-neutral-200 border border-neutral-800'
                  }`}
                >
                  <span>{cat.icon}</span>
                  <span>{cat.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Stored Memory Nodes List */}
          <div className="space-y-2">
            {filteredMemories.length === 0 ? (
              <div className="text-center py-10 rounded-2xl bg-neutral-950/40 border border-neutral-800/60">
                <Brain className="w-8 h-8 text-neutral-600 mx-auto mb-2 animate-pulse" />
                <p className="text-neutral-400 text-xs font-medium">No matching memories found</p>
                <p className="text-neutral-500 text-[11px] mt-0.5">
                  Try adjusting your search or category filter, or teach Myraa a new fact above.
                </p>
              </div>
            ) : (
              filteredMemories.map((item, index) => {
                const isEditing = editingId === item.id;
                const catInfo = MEMORY_CATEGORY_LABELS[item.category] || {
                  label: item.category,
                  icon: '📌',
                };

                return (
                  <div
                    key={item.id || index}
                    className={`group rounded-2xl border transition-all duration-200 ${
                      isEditing
                        ? 'p-4 bg-neutral-950 border-rose-500/50 shadow-lg'
                        : 'p-3.5 bg-neutral-950/70 border-neutral-800/80 hover:border-rose-500/30 hover:bg-neutral-950'
                    }`}
                  >
                    {isEditing ? (
                      /* Inline Memory Correction Form (Rule 6) */
                      <div className="space-y-2.5">
                        <div className="flex items-center justify-between text-xs font-semibold text-rose-300">
                          <span className="flex items-center gap-1.5">
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Correcting Memory</span>
                          </span>
                          <span className="text-[10px] text-neutral-500 font-mono">
                            Rule 6: Memory Correction
                          </span>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-2">
                          <select
                            value={editCategory}
                            onChange={(e) => setEditCategory(e.target.value as MemoryCategory)}
                            className="bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-neutral-200 cursor-pointer"
                          >
                            {Object.entries(MEMORY_CATEGORY_LABELS).map(([catKey, info]) => (
                              <option key={catKey} value={catKey}>
                                {info.icon} {info.label}
                              </option>
                            ))}
                          </select>
                          <input
                            type="text"
                            value={editContentText}
                            onChange={(e) => setEditContentText(e.target.value)}
                            className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-rose-500"
                            onKeyDown={(e) => e.key === 'Enter' && saveCorrection(item.id)}
                            autoFocus
                          />
                        </div>

                        <div className="flex items-center justify-end gap-2 pt-1">
                          <button
                            onClick={cancelEditing}
                            className="px-3 py-1 rounded-xl text-xs text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 cursor-pointer transition-colors"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => saveCorrection(item.id)}
                            disabled={!editContentText.trim()}
                            className="px-3 py-1 rounded-xl text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 cursor-pointer transition-all flex items-center gap-1"
                          >
                            <Check className="w-3 h-3" />
                            <span>Save Correction</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      /* Display Row */
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3 flex-1 min-w-0">
                          <span className="p-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-sm mt-0.5">
                            {catInfo.icon}
                          </span>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap mb-1">
                              <span className="px-2 py-0.2 rounded-full bg-neutral-900 text-neutral-300 border border-neutral-800 text-[10px] font-mono">
                                {catInfo.label}
                              </span>
                              {item.source && (
                                <span className="text-[10px] text-neutral-500 flex items-center gap-1 font-mono">
                                  {item.source === 'voice' ? (
                                    <Mic className="w-2.5 h-2.5 text-sky-400" />
                                  ) : item.source === 'chat' ? (
                                    <MessageSquare className="w-2.5 h-2.5 text-rose-400" />
                                  ) : (
                                    <Bookmark className="w-2.5 h-2.5 text-purple-400" />
                                  )}
                                  <span className="capitalize">{item.source}</span>
                                </span>
                              )}
                              <span className="text-[10px] text-neutral-600 font-mono">
                                · {formatRelativeTime(item.updatedAt || item.createdAt)}
                              </span>
                            </div>

                            <p className="text-neutral-200 text-xs font-medium leading-relaxed break-words">
                              {item.content}
                            </p>

                            {/* Tags */}
                            {item.tags && item.tags.length > 0 && (
                              <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                                {item.tags.slice(0, 4).map((tag, tIdx) => (
                                  <span
                                    key={tIdx}
                                    className="text-[9px] px-1.5 py-0.2 rounded bg-neutral-900/60 text-neutral-400 font-mono"
                                  >
                                    #{tag}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Actions (Correct / Forget) */}
                        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity flex-shrink-0">
                          <button
                            onClick={() => startEditing(item)}
                            className="p-1.5 text-neutral-400 hover:text-rose-300 hover:bg-neutral-800 rounded-lg transition-colors cursor-pointer"
                            title="Correct or update this memory (Rule 6)"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDelete(item.id, index)}
                            className="p-1.5 text-neutral-400 hover:text-red-400 hover:bg-neutral-800 rounded-lg transition-colors cursor-pointer"
                            title="Forget / delete this memory (Rule 7)"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Footer info & Rules summary */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950/60 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-400 gap-2">
          <div className="flex items-center gap-2 text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Persistent file & local storage synced · Privacy guard active</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold cursor-pointer transition-colors"
          >
            Close Memory Bank
          </button>
        </div>
      </div>
    </div>
  );
};
