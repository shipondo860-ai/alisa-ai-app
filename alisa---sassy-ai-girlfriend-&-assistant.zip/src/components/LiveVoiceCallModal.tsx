import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  Sparkles,
  Zap,
  Activity,
  Radio,
  ShieldCheck,
  ShieldAlert,
  AlertCircle,
  RefreshCw,
  Terminal,
  Send,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { AlisaAvatar } from './AlisaAvatar';
import { MoodType } from '../types';
import { ConfirmationRequest } from '../types/assistant';
import {
  downsampleTo16kHz,
  floatTo16BitPCM,
  arrayBufferToBase64,
  base64ToFloat32Array,
} from '../utils/liveAudioStream';
import { processVoiceCommand } from '../services/voiceCommandEngine';
import {
  playPcmAudio,
  speakWithBrowserSynthesis,
  stopCurrentAudio,
  getOrCreateAudioContext,
  generateTurnId,
  isTurnAlreadyPlayed,
  claimTurnPlayback,
  releaseTurnPlayback,
} from '../utils/audio';
import { addActivityLog } from '../services/actionLog';
import {
  LiveSessionState,
  LiveDebugEvent,
  DebugEventLogItem,
  createConversationSession,
  detectUserEmotion,
  sanitizeConversationalResponse,
  VoiceActivityDetector,
} from '../services/conversationEngine';
import {
  loadMemoriesFromStorage,
  storeOrUpdateMemory,
  forgetMemoryByQuery,
  MemoryCategory,
} from '../services/memorySystem';
import { screenVisionService } from '../services/screenVisionService';

interface LiveVoiceCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRequestConfirmation: (req: ConfirmationRequest) => void;
  onOpenPermissionCenter: () => void;
  onOpenActivityLog: () => void;
  onOpenPhotoEditor: (photoUrl: string, name: string) => void;
  onOpenApkInstaller?: () => void;
  onOpenMemoryBank?: () => void;
  onAffectionBump?: (delta: number) => void;
}

export const LiveVoiceCallModal: React.FC<LiveVoiceCallModalProps> = ({
  isOpen,
  onClose,
  onRequestConfirmation,
  onOpenPermissionCenter,
  onOpenActivityLog,
  onOpenPhotoEditor,
  onOpenApkInstaller,
  onAffectionBump,
}) => {
  // Required Live Session State Machine:
  // IDLE | CONNECTING | CONNECTED | LISTENING | USER_SPEAKING | PROCESSING | SPEAKING | RECONNECTING | ERROR
  const [sessionState, setSessionState] = useState<LiveSessionState>('IDLE');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [currentMood, setCurrentMood] = useState<MoodType>('flirty');
  const [userAudioLevel, setUserAudioLevel] = useState(0);
  const [myraaAudioLevel, setMyraaAudioLevel] = useState(0);
  const [lastActionText, setLastActionText] = useState<string | null>(null);
  const [currentAcknowledgement, setCurrentAcknowledgement] = useState<string | null>(null);
  const [commandInputText, setInputCommandText] = useState('');
  const [activeTopic, setActiveTopic] = useState<string | null>(null);
  const [showDebugHUD, setShowDebugHUD] = useState(false);
  const [debugEvents, setDebugEvents] = useState<DebugEventLogItem[]>([]);

  // Audio Context & Hardware refs (Guarding against duplicate sessions & streams)
  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const activeSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const nextStartTimeRef = useRef<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const isMutedRef = useRef(false);
  const animationFrameRef = useRef<number | null>(null);
  const isConnectingRef = useRef(false);
  const sessionActiveRef = useRef(false);
  const reconnectAttemptsRef = useRef(0);
  const reconnectTimerRef = useRef<any>(null);
  const maxReconnectAttempts = 4;

  // Active Multi-Turn Conversation Session & VAD
  const sessionRef = useRef(createConversationSession());
  const vadRef = useRef(new VoiceActivityDetector());
  const speechRecognitionRef = useRef<any>(null);
  const pendingSpeechTextRef = useRef<string>('');
  const isTurnExecutingRef = useRef(false);
  const speechEndTimeoutRef = useRef<any>(null);
  const activeTurnIdRef = useRef<string | null>(null);
  const playedTurnIdsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  // Centralized Debug Event Dispatcher
  const emitDebugEvent = useCallback((event: LiveDebugEvent, details?: string) => {
    const now = Date.now();
    const timeString =
      new Date(now).toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }) +
      '.' +
      String(now % 1000).padStart(3, '0');

    const item: DebugEventLogItem = {
      id: `dbg_${now}_${Math.random().toString(36).substring(2, 6)}`,
      event,
      timestamp: now,
      timeString,
      details,
    };

    setDebugEvents((prev) => [item, ...prev].slice(0, 50));
    console.log(`[MYRAA_AUDIO_ENGINE] ${timeString} [${event}]`, details || '');

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('myraa:voice:debug', { detail: item }));
    }
  }, []);

  // Safe AudioContext resumption ensuring mobile/browser auto-play compliance
  const ensureAudioContextRunning = async (ctx: AudioContext | null) => {
    if (!ctx) return;
    if (ctx.state === 'suspended') {
      try {
        await ctx.resume();
      } catch (e) {
        console.warn('AudioContext resume notice:', e);
      }
    }
  };

  // Call duration counter
  useEffect(() => {
    if (
      !isOpen ||
      sessionState === 'IDLE' ||
      sessionState === 'CONNECTING' ||
      sessionState === 'ERROR' ||
      sessionState === 'RECONNECTING'
    )
      return;

    const interval = setInterval(() => {
      setCallDuration((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen, sessionState]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Comprehensive resource cleanup preventing orphaned hardware or listeners
  const cleanup = () => {
    sessionActiveRef.current = false;
    isConnectingRef.current = false;
    isTurnExecutingRef.current = false;

    if (reconnectTimerRef.current) {
      clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }

    if (speechEndTimeoutRef.current) {
      clearTimeout(speechEndTimeoutRef.current);
      speechEndTimeoutRef.current = null;
    }

    // Clean up SpeechRecognition
    if (speechRecognitionRef.current) {
      try {
        speechRecognitionRef.current.onresult = null;
        speechRecognitionRef.current.onerror = null;
        speechRecognitionRef.current.onend = null;
        speechRecognitionRef.current.stop();
      } catch {}
      speechRecognitionRef.current = null;
    }

    // Clean up WebSocket
    if (wsRef.current) {
      try {
        wsRef.current.onopen = null;
        wsRef.current.onmessage = null;
        wsRef.current.onerror = null;
        wsRef.current.onclose = null;
        if (wsRef.current.readyState === WebSocket.OPEN) {
          wsRef.current.close();
        }
      } catch {}
      wsRef.current = null;
    }

    stopAllAudioPlayback();

    // Clean up microphone stream
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {}
      });
      micStreamRef.current = null;
    }

    // Clean up audio nodes
    if (processorRef.current) {
      try {
        processorRef.current.onaudioprocess = null;
        processorRef.current.disconnect();
      } catch {}
      processorRef.current = null;
    }

    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.disconnect();
      } catch {}
      sourceNodeRef.current = null;
    }

    if (inputAudioCtxRef.current) {
      try {
        inputAudioCtxRef.current.close();
      } catch {}
      inputAudioCtxRef.current = null;
    }

    if (outputAudioCtxRef.current) {
      try {
        outputAudioCtxRef.current.close();
      } catch {}
      outputAudioCtxRef.current = null;
    }

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }

    vadRef.current.reset();
    pendingSpeechTextRef.current = '';
    setUserAudioLevel(0);
    setMyraaAudioLevel(0);
  };

  const stopAllAudioPlayback = () => {
    stopCurrentAudio();
    for (const source of activeSourcesRef.current) {
      try {
        source.stop();
        source.disconnect();
      } catch {}
    }
    activeSourcesRef.current = [];
    nextStartTimeRef.current = 0;
    setMyraaAudioLevel(0);
  };

  /**
   * Required Loop Execution:
   * CONNECTED -> LISTENING -> USER_SPEAKING -> USER_SPEECH_ENDED -> PROCESSING -> SPEAKING -> AUDIO_ENDED -> LISTENING
   * Keeps the live session alive during active conversation.
   */
  const executeConversationalTurn = async (userText: string) => {
    const rawSpeech = userText.trim();
    if (!rawSpeech) {
      setSessionState('LISTENING');
      isTurnExecutingRef.current = false;
      return;
    }

    // Guard against duplicate execution
    if (isTurnExecutingRef.current) {
      console.warn('[DEDUPLICATION_GUARD] DUPLICATE_RESPONSE_BLOCKED: A turn is already executing in parallel.');
      return;
    }

    // Generate cryptographically unique turn ID
    const turnId = generateTurnId();
    if (isTurnAlreadyPlayed(turnId) || playedTurnIdsRef.current.has(turnId)) {
      console.warn('[DEDUPLICATION_GUARD] DUPLICATE_RESPONSE_BLOCKED: Turn ID already executed:', turnId);
      return;
    }

    isTurnExecutingRef.current = true;
    activeTurnIdRef.current = turnId;
    playedTurnIdsRef.current.add(turnId);

    try {
      // 1. PROCESSING Phase
      setSessionState('PROCESSING');
      emitDebugEvent('RESPONSE_STARTED', `Turn ID: ${turnId} | input: "${rawSpeech}"`);
      setLastActionText(`"${rawSpeech}"`);

      // Detect emotion and adapt conversational tone
      const emotion = detectUserEmotion(rawSpeech);
      sessionRef.current.detectedEmotion = emotion;

      // Check if this is an Android device command first
      const cmdResult = await processVoiceCommand(rawSpeech, {
        requestConfirmation: onRequestConfirmation,
        openPermissionCenter: onOpenPermissionCenter,
        openActivityLog: onOpenActivityLog,
        openPhotoEditor: onOpenPhotoEditor,
        openApkInstaller: onOpenApkInstaller,
      });

      if (cmdResult.handled) {
        if (cmdResult.resultMessage) {
          setLastActionText(cmdResult.resultMessage);
        }
        // Transition to SPEAKING
        setSessionState('SPEAKING');
        emitDebugEvent('AUDIO_PLAYBACK_STARTED', `Command confirmation spoken [Turn: ${turnId}]`);

        const confirmSpeech = cmdResult.resultMessage || 'Done! I opened that for you.';
        const played = await speakWithBrowserSynthesis(confirmSpeech, 'flirty', turnId);

        if (!played) {
          console.warn('[DEDUPLICATION_GUARD] DUPLICATE_RESPONSE_BLOCKED: Duplicate command confirmation speech blocked.');
          addActivityLog(rawSpeech, 'Voice Command Confirmation', 'cancelled', 'DUPLICATE_RESPONSE_BLOCKED');
        } else {
          // Exactly one response played
          emitDebugEvent('AUDIO_PLAYBACK_ENDED', `Command confirmation finished [Turn: ${turnId}]`);
          addActivityLog(rawSpeech, 'Voice Command Execution', 'success', confirmSpeech);
        }

        // Return to LISTENING (Session stays alive!)
        setSessionState('LISTENING');
        isTurnExecutingRef.current = false;
        activeTurnIdRef.current = null;
        pendingSpeechTextRef.current = '';
        return;
      }

      // Check if Screen Vision is active for live visual multimodal grounding
      let screenFrame: string | null = null;
      if (screenVisionService.getState().isSharing && !screenVisionService.getState().isPaused) {
        try {
          screenFrame = await screenVisionService.captureCompressedFrame(1280, 0.7);
        } catch (e) {
          console.warn('Live screen frame capture notice:', e);
        }
      }

      // Natural AI Companion Dialogue via /api/conversation-turn with Long-Term Memory
      const currentStoredMemories = loadMemoriesFromStorage();
      const response = await fetch('/api/conversation-turn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          turnId,
          userSpeech: rawSpeech,
          history: sessionRef.current.turns,
          detectedEmotion: emotion,
          activeTopic: sessionRef.current.activeTopic,
          userProfile: { name: 'Ayush', nickname: 'Babe' },
          memories: currentStoredMemories,
          screenFrame: screenFrame || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const turnData = await response.json();

      // Verify that this turn is still the active one (prevent race conditions from delayed responses)
      if (activeTurnIdRef.current !== turnId) {
        console.warn('[DEDUPLICATION_GUARD] DUPLICATE_RESPONSE_BLOCKED: Active turn superseded, discarding stale response.');
        return;
      }

      const cleanReply = sanitizeConversationalResponse(
        turnData.reply || "I'm listening, tell me more about what got you thinking about that!"
      );
      const ack = turnData.acknowledgement ? turnData.acknowledgement.trim() : '';
      const mood = (turnData.mood || 'flirty') as MoodType;

      setCurrentMood(mood);
      if (turnData.activeTopic) {
        setActiveTopic(turnData.activeTopic);
        sessionRef.current.activeTopic = turnData.activeTopic;
      }

      // Memory System Integration
      if (turnData.memoryAction && turnData.memoryAction.action) {
        const { action, category, content, key } = turnData.memoryAction;
        if ((action === 'store' || action === 'update') && content) {
          storeOrUpdateMemory(content, (category as MemoryCategory) || 'important_facts', rawSpeech, 'voice');
        } else if (action === 'forget') {
          forgetMemoryByQuery(key || content || rawSpeech);
        }
      }

      // Record turn in active multi-turn session
      sessionRef.current.turns.push({
        id: `turn_${Date.now()}`,
        role: 'user',
        text: rawSpeech,
        timestamp: Date.now(),
        emotionalContext: emotion,
      });

      sessionRef.current.turns.push({
        id: `turn_${Date.now() + 1}`,
        role: 'assistant',
        text: cleanReply,
        timestamp: Date.now(),
        acknowledgement: ack,
        followUpQuestion: turnData.followUpQuestion,
      });

      // 2. SPEAKING Phase (Exactly ONE Audio playback starts)
      setSessionState('SPEAKING');
      emitDebugEvent('AUDIO_PLAYBACK_STARTED', `Spoken delivery [Turn: ${turnId}] (${turnData.audioBase64 ? 'PCM 24kHz' : 'Browser TTS'})`);
      setCurrentAcknowledgement(ack || null);
      setLastActionText(`Myraa: "${cleanReply}"`);

      if (onAffectionBump) {
        onAffectionBump(2);
      }

      // Spoken delivery using gentle natural voice with unique turnId
      let playedSuccessfully = false;
      if (turnData.audioBase64) {
        try {
          playedSuccessfully = await playPcmAudio(turnData.audioBase64, 24000, turnId);
        } catch {
          playedSuccessfully = await speakWithBrowserSynthesis(`${ack ? ack + ' ' : ''}${cleanReply}`, mood, turnId);
        }
      } else {
        playedSuccessfully = await speakWithBrowserSynthesis(`${ack ? ack + ' ' : ''}${cleanReply}`, mood, turnId);
      }

      // 3. AUDIO ENDED -> LISTENING (Return to listening naturally)
      if (!playedSuccessfully) {
        console.warn('[DEDUPLICATION_GUARD] DUPLICATE_RESPONSE_BLOCKED: Duplicate playback was suppressed.');
        emitDebugEvent('SESSION_ERROR', 'DUPLICATE_RESPONSE_BLOCKED: Duplicate playback intercepted.');
        addActivityLog(rawSpeech, 'Voice Turn Delivery', 'cancelled', 'DUPLICATE_RESPONSE_BLOCKED: Duplicate response was blocked.');
      } else {
        // ONLY report success after exactly ONE response has played
        emitDebugEvent('AUDIO_PLAYBACK_ENDED', `Spoken playback finished (exactly 1 response) [Turn: ${turnId}]`);
        addActivityLog(rawSpeech, 'Voice Turn Delivery', 'success', cleanReply);
      }

      setCurrentAcknowledgement(null);
      setSessionState('LISTENING');
      isTurnExecutingRef.current = false;
      activeTurnIdRef.current = null;
      pendingSpeechTextRef.current = '';
    } catch (err: any) {
      console.warn('Voice turn notice:', err);
      emitDebugEvent('SESSION_ERROR', err?.message || 'Voice turn execution issue');

      // Graceful gentle spoken fallback with turnId
      setSessionState('SPEAKING');
      emitDebugEvent('AUDIO_PLAYBACK_STARTED', `Warm fallback prompt [Turn: ${turnId}]`);
      const played = await speakWithBrowserSynthesis("I hear you! I'm right here with you, tell me more.", 'flirty', turnId);
      if (!played) {
        console.warn('[DEDUPLICATION_GUARD] DUPLICATE_RESPONSE_BLOCKED: Fallback audio suppressed.');
        addActivityLog(rawSpeech, 'Voice Turn Fallback', 'cancelled', 'DUPLICATE_RESPONSE_BLOCKED');
      } else {
        addActivityLog(rawSpeech, 'Voice Turn Fallback', 'success', "I hear you! I'm right here with you, tell me more.");
      }
      emitDebugEvent('AUDIO_PLAYBACK_ENDED', 'Warm fallback prompt ended');

      setSessionState('LISTENING');
      isTurnExecutingRef.current = false;
      activeTurnIdRef.current = null;
      pendingSpeechTextRef.current = '';
    }
  };

  // VAD Callback handlers
  useEffect(() => {
    const vad = vadRef.current;

    vad.onSpeechStart = () => {
      if (isTurnExecutingRef.current) return;
      if (sessionState === 'SPEAKING') {
        // Natural interruption / barge-in
        stopAllAudioPlayback();
        emitDebugEvent('USER_SPEECH_STARTED', 'Barge-in speech detected');
      } else {
        emitDebugEvent('USER_SPEECH_STARTED', 'Voice activity detected');
      }

      setSessionState('USER_SPEAKING');
      if (speechEndTimeoutRef.current) {
        clearTimeout(speechEndTimeoutRef.current);
        speechEndTimeoutRef.current = null;
      }
    };

    vad.onSpeechEnd = () => {
      if (isTurnExecutingRef.current) return;
      emitDebugEvent('USER_SPEECH_ENDED', 'Silence threshold met');

      // Natural pause tolerance (300ms buffer to allow final SpeechRecognition tokens to settle)
      if (speechEndTimeoutRef.current) clearTimeout(speechEndTimeoutRef.current);
      speechEndTimeoutRef.current = setTimeout(() => {
        const text = pendingSpeechTextRef.current;
        if (text && text.trim().length > 1) {
          executeConversationalTurn(text);
        } else {
          // Ambient noise / transient click filtered out -> return to LISTENING
          setSessionState('LISTENING');
        }
      }, 300);
    };

    vad.onAudioLevel = (level) => {
      setUserAudioLevel(level);
    };
  }, [sessionState, emitDebugEvent]);

  // Handle incoming live audio chunk from Gemini Live WebSocket
  const handleIncomingAudioChunk = (base64Audio: string) => {
    // If a conversational turn is executing or already playing, DROP duplicate audio from WebSocket!
    if (isTurnExecutingRef.current || activeTurnIdRef.current) {
      console.warn('[DEDUPLICATION_GUARD] DUPLICATE_RESPONSE_BLOCKED: Ignoring WebSocket streaming audio while conversational turn is active.');
      return;
    }

    const outputCtx = outputAudioCtxRef.current;
    if (!outputCtx) return;

    try {
      const float32 = base64ToFloat32Array(base64Audio);
      if (float32.length === 0) return;

      if (sessionState !== 'SPEAKING') {
        setSessionState('SPEAKING');
        emitDebugEvent('AUDIO_PLAYBACK_STARTED', 'Streaming live PCM frame');
      }

      let sum = 0;
      for (let i = 0; i < float32.length; i++) {
        sum += float32[i] * float32[i];
      }
      const rms = Math.sqrt(sum / float32.length);
      setMyraaAudioLevel(Math.min(1, rms * 4));

      const audioBuffer = outputCtx.createBuffer(1, float32.length, 24000);
      audioBuffer.getChannelData(0).set(float32);

      const source = outputCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(outputCtx.destination);

      const now = outputCtx.currentTime;
      const startTime = Math.max(now, nextStartTimeRef.current);
      source.start(startTime);
      nextStartTimeRef.current = startTime + audioBuffer.duration;

      activeSourcesRef.current.push(source);

      source.onended = () => {
        activeSourcesRef.current = activeSourcesRef.current.filter((s) => s !== source);
        if (activeSourcesRef.current.length === 0) {
          emitDebugEvent('AUDIO_PLAYBACK_ENDED', 'Streaming live audio buffer drained');
          setSessionState('LISTENING');
          setMyraaAudioLevel(0);
        }
      };
    } catch (err) {
      console.warn('Audio chunk playback notice:', err);
    }
  };

  // Safe automatic reconnect with exponential backoff & clear recovery
  const handleConnectionFailure = useCallback(
    (reason: string) => {
      isConnectingRef.current = false;
      emitDebugEvent('SESSION_ERROR', reason);

      const isDenial =
        String(reason).toLowerCase().includes('denied') ||
        String(reason).toLowerCase().includes('permission') ||
        String(reason).toLowerCase().includes('not allowed');

      if (isDenial) {
        setSessionState('ERROR');
        setErrorMessage(
          'Microphone permission is required (android.permission.RECORD_AUDIO). You can enable it in permissions or use Interactive Mode.'
        );
        return;
      }

      if (reconnectAttemptsRef.current < maxReconnectAttempts) {
        reconnectAttemptsRef.current += 1;
        setSessionState('RECONNECTING');
        emitDebugEvent('RECONNECT_STARTED', `Attempt ${reconnectAttemptsRef.current}/${maxReconnectAttempts}`);

        setErrorMessage(
          `Connection temporarily interrupted. Reconnecting (Attempt ${reconnectAttemptsRef.current}/${maxReconnectAttempts})...`
        );

        if (reconnectTimerRef.current) clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = setTimeout(() => {
          if (isOpen) startLiveCall(false);
        }, 1200 * reconnectAttemptsRef.current);
      } else {
        setErrorMessage(reason || 'Live audio interrupted. Tap Reconnect to resume.');
        setSessionState('ERROR');
        emitDebugEvent('SESSION_CLOSED', 'Max reconnect attempts reached');
      }
    },
    [isOpen, emitDebugEvent]
  );

  // Initialize the Live Session with protection against duplicate sessions and microphone streams
  const startLiveCall = async (simulatedMic = false) => {
    // 1. Guard against duplicate sessions: completely verify that an active session does not already exist
    if (sessionActiveRef.current) {
      if (
        wsRef.current &&
        (wsRef.current.readyState === WebSocket.OPEN || wsRef.current.readyState === WebSocket.CONNECTING)
      ) {
        console.log('[SESSION_GUARD] Active voice session already exists and is healthy, skipping duplicate session creation.');
        return;
      }
    }
    if (isConnectingRef.current) {
      console.log('[SESSION_GUARD] Session connection already in progress, skipping duplicate call');
      return;
    }

    // Clean up any stale or lingering sessions/listeners before creating a new one
    cleanup();
    isConnectingRef.current = true;
    sessionActiveRef.current = true;

    setSessionState('CONNECTING');
    setErrorMessage(null);

    let stream: MediaStream | null = null;

    // 2. Prevent duplicate microphone streams: reuse if live, else request
    if (!simulatedMic && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        if (
          micStreamRef.current &&
          micStreamRef.current.active &&
          micStreamRef.current.getAudioTracks().some((t) => t.readyState === 'live')
        ) {
          stream = micStreamRef.current;
        } else {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: {
              echoCancellation: true,
              noiseSuppression: true,
              autoGainControl: true,
              sampleRate: 16000,
            },
          });
        }
        emitDebugEvent('MIC_STARTED', 'Microphone stream activated');
      } catch (micErr: any) {
        console.warn('Microphone request error:', micErr);
        handleConnectionFailure(micErr?.message || 'Unable to access microphone input');
        return;
      }
    } else {
      // Simulated mic track for testing in environments without audio hardware
      try {
        const dummyCtx = await getOrCreateAudioContext(16000);
        const osc = dummyCtx.createOscillator();
        const gain = dummyCtx.createGain();
        gain.gain.value = 0;
        osc.connect(gain);
        const dest = dummyCtx.createMediaStreamDestination();
        gain.connect(dest);
        osc.start();
        stream = dest.stream;
        emitDebugEvent('MIC_STARTED', 'Simulated audio input channel ready');
      } catch (e) {
        console.warn('Simulated mic notice:', e);
      }
    }

    try {
      // 3. Input AudioContext & VAD Setup
      if (stream) {
        micStreamRef.current = stream;

        // Disconnect previous nodes if any
        if (processorRef.current) {
          try {
            processorRef.current.disconnect();
          } catch {}
          processorRef.current = null;
        }
        if (sourceNodeRef.current) {
          try {
            sourceNodeRef.current.disconnect();
          } catch {}
          sourceNodeRef.current = null;
        }

        const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        inputAudioCtxRef.current = inputCtx;
        await ensureAudioContextRunning(inputCtx);

        const source = inputCtx.createMediaStreamSource(stream);
        sourceNodeRef.current = source;

        const processor = inputCtx.createScriptProcessor(4096, 1, 1);
        processorRef.current = processor;

        processor.onaudioprocess = (e) => {
          if (isMutedRef.current) return;

          const inputChannelData = e.inputBuffer.getChannelData(0);

          // Process VAD
          vadRef.current.processAudioFrame(inputChannelData);

          // Stream PCM frames to Live WebSocket if open
          if (wsRef.current?.readyState === WebSocket.OPEN) {
            const downsampled = downsampleTo16kHz(inputChannelData, inputCtx.sampleRate);
            const pcm16Buffer = floatTo16BitPCM(downsampled);
            const base64Audio = arrayBufferToBase64(pcm16Buffer);

            wsRef.current.send(
              JSON.stringify({
                type: 'audio',
                audio: base64Audio,
              })
            );
          }
        };

        source.connect(processor);
        processor.connect(inputCtx.destination);
      }

      // 4. Output AudioContext (24kHz Web Audio API)
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 24000,
      });
      outputAudioCtxRef.current = outputCtx;
      await ensureAudioContextRunning(outputCtx);

      // 5. Connect to Live WebSocket Server
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/api/live`;

      // Clean up previous socket if any
      if (wsRef.current) {
        try {
          wsRef.current.close();
        } catch {}
      }

      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        reconnectAttemptsRef.current = 0;
        setSessionState('CONNECTED');
        emitDebugEvent('SESSION_CONNECTED', 'WebSocket transport connected');

        if (reconnectAttemptsRef.current > 0) {
          emitDebugEvent('RECONNECT_SUCCESS', 'Session connection recovered');
        }

        // Transition from CONNECTED -> LISTENING
        setTimeout(() => {
          setSessionState('LISTENING');
          setCurrentMood('flirty');
          isConnectingRef.current = false;
        }, 150);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'status' && msg.status === 'ready') {
            setSessionState('CONNECTED');
            emitDebugEvent('SESSION_CONNECTED', `Model ready: ${msg.model || 'live'}`);
            setTimeout(() => setSessionState('LISTENING'), 100);
          } else if (msg.type === 'audio' && msg.audio) {
            handleIncomingAudioChunk(msg.audio);
          } else if (msg.type === 'interrupted') {
            stopAllAudioPlayback();
            emitDebugEvent('USER_SPEECH_STARTED', 'Model interrupted by user voice');
            setSessionState('LISTENING');
          } else if (msg.type === 'turnComplete') {
            if (activeSourcesRef.current.length === 0) {
              emitDebugEvent('AUDIO_PLAYBACK_ENDED', 'Model turn complete');
              setSessionState('LISTENING');
              setMyraaAudioLevel(0);
            }
          } else if (msg.type === 'error') {
            console.warn('Gemini Live message notice:', msg.message);
            emitDebugEvent('SESSION_ERROR', msg.message);
          }
        } catch (e) {
          console.warn('WebSocket message parse notice:', e);
        }
      };

      ws.onerror = () => {
        handleConnectionFailure('WebSocket network connection error');
      };

      ws.onclose = () => {
        if (!sessionActiveRef.current) return;
        handleConnectionFailure('Live session closed unexpectedly');
      };

      // 6. SpeechRecognition client-side transcribe
      if (stream && !simulatedMic) {
        const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        if (SpeechRec) {
          try {
            if (speechRecognitionRef.current) {
              try {
                speechRecognitionRef.current.stop();
              } catch {}
            }

            const rec = new SpeechRec();
            rec.continuous = true;
            rec.interimResults = true;
            rec.lang = 'en-US';

            rec.onresult = (event: any) => {
              let interimTranscript = '';
              let finalTranscript = '';

              for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                  finalTranscript += event.results[i][0].transcript;
                } else {
                  interimTranscript += event.results[i][0].transcript;
                }
              }

              const currentSpoken = (finalTranscript || interimTranscript).trim();
              if (currentSpoken) {
                pendingSpeechTextRef.current = currentSpoken;
                if (sessionState === 'LISTENING') {
                  setSessionState('USER_SPEAKING');
                  emitDebugEvent('USER_SPEECH_STARTED', `Transcription: "${currentSpoken.slice(0, 30)}..."`);
                }
              }
            };

            rec.onerror = (e: any) => {
              if (e.error !== 'no-speech') {
                console.warn('SpeechRecognition notice:', e.error);
              }
            };

            rec.onend = () => {
              if (isOpen && sessionActiveRef.current) {
                try {
                  rec.start();
                } catch {}
              }
            };

            speechRecognitionRef.current = rec;
            rec.start();
          } catch {}
        }
      }

      // Initial transition to CONNECTED -> LISTENING
      setSessionState('CONNECTED');
      setTimeout(() => {
        setSessionState('LISTENING');
        isConnectingRef.current = false;
      }, 150);
    } catch (err: any) {
      console.warn('Session startup error:', err);
      handleConnectionFailure(err?.message || 'Audio session initialization failure');
    }
  };

  // Canvas waveform visualization
  useEffect(() => {
    if (!isOpen) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let phase = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const width = canvas.width;
      const height = canvas.height;
      const midY = height / 2;

      const isSpeaking = sessionState === 'SPEAKING';
      const amp = isSpeaking
        ? Math.max(0.15, myraaAudioLevel) * (height * 0.42)
        : Math.max(0.05, userAudioLevel) * (height * 0.35);

      const waveColors = isSpeaking
        ? ['rgba(244, 63, 94, 0.75)', 'rgba(236, 72, 153, 0.55)', 'rgba(168, 85, 247, 0.35)']
        : ['rgba(56, 189, 248, 0.75)', 'rgba(129, 140, 248, 0.55)', 'rgba(244, 63, 94, 0.35)'];

      waveColors.forEach((color, idx) => {
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 2.5 - idx * 0.5;

        const currentPhase = phase + idx * 0.8;
        const waveFreq = 0.02 + idx * 0.005;

        for (let x = 0; x < width; x += 2) {
          const y = midY + Math.sin(x * waveFreq + currentPhase) * amp * Math.sin((x / width) * Math.PI);
          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      });

      phase += 0.08;
      animationFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isOpen, sessionState, myraaAudioLevel, userAudioLevel]);

  // Modal open/close lifecycle
  useEffect(() => {
    if (isOpen) {
      startLiveCall();
    } else {
      emitDebugEvent('SESSION_CLOSED', 'Modal closed by user');
      cleanup();
    }
    return () => {
      cleanup();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  // The 7 Required Voice Loop Steps
  const requiredLoopSteps = [
    { id: 'CONNECTED', label: 'Connected' },
    { id: 'LISTENING', label: 'Listening' },
    { id: 'USER_SPEAKING', label: 'User Speaking' },
    { id: 'PROCESSING', label: 'Processing' },
    { id: 'SPEAKING', label: 'Speaking' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-neutral-950/90 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-neutral-900/95 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col items-center max-h-[92vh] overflow-y-auto">
        {/* Top Header */}
        <div className="w-full px-5 py-3.5 border-b border-neutral-800/80 bg-neutral-950/60 flex items-center justify-between sticky top-0 z-20 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-3 w-3">
              <span
                className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  sessionState === 'SPEAKING'
                    ? 'bg-rose-400'
                    : sessionState === 'USER_SPEAKING'
                    ? 'bg-sky-400'
                    : sessionState === 'LISTENING'
                    ? 'bg-emerald-400'
                    : sessionState === 'ERROR'
                    ? 'bg-red-400'
                    : 'bg-amber-400'
                }`}
              />
              <span
                className={`relative inline-flex rounded-full h-3 w-3 ${
                  sessionState === 'SPEAKING'
                    ? 'bg-rose-500'
                    : sessionState === 'USER_SPEAKING'
                    ? 'bg-sky-500'
                    : sessionState === 'LISTENING'
                    ? 'bg-emerald-500'
                    : sessionState === 'ERROR'
                    ? 'bg-red-500'
                    : 'bg-amber-500'
                }`}
              />
            </span>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-display font-bold text-sm text-white">Myraa Natural Voice</span>
                <span className="px-2 py-0.2 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[9px] font-mono font-semibold uppercase">
                  V4 Live Audio Engine
                </span>
              </div>
              <p className="text-[10px] text-neutral-400 font-mono">
                Continuous Multi-Turn · Soft Natural Aoede Voice · Resilient Auto-Recovery
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Debug HUD Toggle */}
            <button
              onClick={() => setShowDebugHUD(!showDebugHUD)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-xl border text-[11px] font-mono transition-all cursor-pointer ${
                showDebugHUD
                  ? 'bg-rose-950/70 border-rose-600 text-rose-300'
                  : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-white'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Debug HUD</span>
              {showDebugHUD ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            {/* Call Timer */}
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-neutral-950 border border-neutral-800 font-mono text-xs text-neutral-300">
              <Radio className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
              <span>{formatDuration(callDuration)}</span>
            </div>
          </div>
        </div>

        {/* Center Calling Area */}
        <div className="w-full p-5 md:p-7 flex flex-col items-center justify-center relative">
          {/* Ambient Glow */}
          <div className="absolute w-72 h-72 bg-gradient-to-tr from-rose-500/10 via-pink-500/15 to-purple-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Animated 3-State Character Avatar */}
          <div className="relative mb-4">
            {sessionState === 'SPEAKING' && (
              <div className="absolute inset-0 -m-4 rounded-full border-2 border-rose-500/40 animate-ping pointer-events-none" />
            )}
            <AlisaAvatar
              mood={currentMood}
              isSpeaking={sessionState === 'SPEAKING'}
              isThinking={
                sessionState === 'PROCESSING' ||
                sessionState === 'CONNECTING' ||
                sessionState === 'RECONNECTING' ||
                sessionState === 'USER_SPEAKING'
              }
              size="lg"
            />
          </div>

          {/* Dynamic Status Display */}
          <div className="text-center mb-3">
            <h2 className="font-display font-extrabold text-xl text-white mb-1">Myraa</h2>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-neutral-950 border border-neutral-800 text-xs font-medium">
              {sessionState === 'CONNECTING' && (
                <>
                  <Zap className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
                  <span className="text-amber-300">Connecting live audio session...</span>
                </>
              )}
              {sessionState === 'CONNECTED' && (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-300">Session connected · Ready</span>
                </>
              )}
              {sessionState === 'RECONNECTING' && (
                <>
                  <RefreshCw className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                  <span className="text-amber-300">Auto-recovering connection...</span>
                </>
              )}
              {sessionState === 'LISTENING' && (
                <>
                  <Mic className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                  <span className="text-emerald-300">Listening naturally... (Speak freely, no wake words)</span>
                </>
              )}
              {sessionState === 'USER_SPEAKING' && (
                <>
                  <Activity className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
                  <span className="text-sky-300 font-medium">User speaking... (Listening carefully)</span>
                </>
              )}
              {sessionState === 'PROCESSING' && (
                <>
                  <RefreshCw className="w-3.5 h-3.5 text-purple-400 animate-spin" />
                  <span className="text-purple-300">Processing spoken thoughts...</span>
                </>
              )}
              {sessionState === 'SPEAKING' && (
                <>
                  <Volume2 className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                  <span className="text-rose-300">
                    {currentAcknowledgement ? `"${currentAcknowledgement}" ` : ''}Myraa speaking softly...
                  </span>
                </>
              )}
              {sessionState === 'ERROR' && (
                <>
                  <AlertCircle className="w-3.5 h-3.5 text-red-400" />
                  <span className="text-red-300">Connection notice</span>
                </>
              )}
            </div>

            {/* Required Voice Loop Breadcrumb Indicator */}
            <div className="mt-2.5 flex items-center justify-center gap-1 overflow-x-auto max-w-full px-2 py-1">
              {requiredLoopSteps.map((step, idx) => {
                const isActive = sessionState === step.id;
                return (
                  <React.Fragment key={step.id}>
                    <span
                      className={`text-[9px] px-2 py-0.5 rounded font-mono transition-all ${
                        isActive
                          ? 'bg-rose-500 text-white font-bold scale-105 shadow-sm shadow-rose-500/50'
                          : 'bg-neutral-950/80 text-neutral-500 border border-neutral-800/80'
                      }`}
                    >
                      {step.label}
                    </span>
                    {idx < requiredLoopSteps.length - 1 && (
                      <span className="text-[8px] text-neutral-600">→</span>
                    )}
                  </React.Fragment>
                );
              })}
            </div>

            {lastActionText && (
              <div className="mt-2 text-xs text-rose-300 bg-rose-950/40 border border-rose-900/50 px-3 py-1 rounded-xl max-w-md animate-in fade-in">
                {lastActionText}
              </div>
            )}

            {errorMessage && (
              <div className="mt-2 text-xs text-red-400 bg-red-950/40 border border-red-900/50 px-3 py-1.5 rounded-xl max-w-md flex items-center justify-between gap-2">
                <span>{errorMessage}</span>
                <button
                  onClick={() => startLiveCall(false)}
                  className="px-2 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-semibold text-[10px] cursor-pointer"
                >
                  Reconnect
                </button>
              </div>
            )}
          </div>

          {/* Real-time Waveform Canvas */}
          <div className="w-full max-w-md h-12 bg-neutral-950/70 border border-neutral-800/80 rounded-2xl overflow-hidden relative shadow-inner mb-3">
            <canvas ref={canvasRef} width={450} height={48} className="w-full h-full block" />
            <div className="absolute bottom-1 right-2 text-[9px] font-mono text-neutral-500">
              {sessionState === 'SPEAKING' ? 'Soft 24kHz Natural Audio' : '16kHz PCM Stream (VAD Active)'}
            </div>
          </div>

          {/* Collapsible Debug HUD Panel */}
          {showDebugHUD && (
            <div className="w-full max-w-lg mb-3 p-3 rounded-2xl bg-neutral-950/95 border border-neutral-800 text-xs font-mono animate-in fade-in">
              <div className="flex items-center justify-between text-neutral-400 mb-2 border-b border-neutral-800 pb-1.5">
                <span className="text-rose-400 font-bold flex items-center gap-1">
                  <Terminal className="w-3.5 h-3.5" />
                  <span>Real-Time Voice Engine Events ({debugEvents.length})</span>
                </span>
                <span className="text-[10px] text-neutral-500">Target Voice: Aoede (Soft/Warm)</span>
              </div>
              <div className="max-h-36 overflow-y-auto space-y-1 pr-1 text-[11px]">
                {debugEvents.length === 0 ? (
                  <p className="text-neutral-600 italic">No events recorded yet</p>
                ) : (
                  debugEvents.map((dbg) => (
                    <div key={dbg.id} className="flex items-start gap-2 py-0.5 border-b border-neutral-900/60">
                      <span className="text-neutral-500 text-[10px]">{dbg.timeString}</span>
                      <span
                        className={`font-semibold px-1 rounded text-[9px] ${
                          dbg.event.includes('ERROR')
                            ? 'bg-red-950 text-red-400'
                            : dbg.event.includes('STARTED') || dbg.event.includes('CONNECTED')
                            ? 'bg-emerald-950 text-emerald-400'
                            : 'bg-neutral-800 text-neutral-300'
                        }`}
                      >
                        {dbg.event}
                      </span>
                      {dbg.details && <span className="text-neutral-300 truncate">{dbg.details}</span>}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Quick Voice Prompts & Conversation Starters */}
          <div className="w-full max-w-lg mb-3">
            <span className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider block mb-1 text-center">
              ⚡ Speak or Tap to Converse:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs">
              {[
                { label: '💬 "Hey, how was your day?"', text: 'Hey, how was your day?' },
                { label: '🎮 "Remember Free Fire"', text: 'My favorite game is Free Fire, remember that!' },
                { label: '🤔 "What do you remember?"', text: 'What is my favorite game?' },
                { label: '☕ "Talk about late night chai"', text: 'Tell me your thoughts on late night chai and coding.' },
                { label: '▶️ YouTube খোলো', text: 'YouTube খোলো' },
                { label: '🖼️ Gallery খোলো', text: 'Gallery খোলো' },
                { label: '📞 Call Ayush', text: 'Call Ayush' },
                { label: '🛡️ Open Permissions', text: 'Open permissions' },
              ].map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => executeConversationalTurn(item.text)}
                  className="p-2 rounded-xl bg-neutral-950/70 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-[11px] font-medium transition-all text-center truncate cursor-pointer active:scale-95"
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Interactive Command & Conversation Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (commandInputText.trim()) {
                executeConversationalTurn(commandInputText.trim());
                setInputCommandText('');
              }
            }}
            className="w-full max-w-lg mb-3 flex items-center gap-2"
          >
            <div className="relative flex-1">
              <input
                type="text"
                value={commandInputText}
                onChange={(e) => setInputCommandText(e.target.value)}
                placeholder="Talk to Myraa (e.g. 'How are you feeling?', 'YouTube খোলো')..."
                className="w-full px-4 py-2.5 bg-neutral-950/80 border border-neutral-800 focus:border-rose-500/60 rounded-2xl text-xs text-white placeholder-neutral-500 outline-none transition-all pr-8"
              />
              {commandInputText && (
                <button
                  type="button"
                  onClick={() => setInputCommandText('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-white text-xs cursor-pointer"
                >
                  ×
                </button>
              )}
            </div>
            <button
              type="submit"
              disabled={!commandInputText.trim() || isTurnExecutingRef.current}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-rose-950/30 active:scale-95"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send</span>
            </button>
          </form>

          {/* Call Controls Bar */}
          <div className="flex items-center gap-3">
            {/* Mute Mic Button */}
            <button
              onClick={() => setIsMuted(!isMuted)}
              className={`p-3 rounded-2xl border transition-all cursor-pointer shadow-lg active:scale-95 ${
                isMuted
                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                  : 'bg-neutral-800 hover:bg-neutral-700 text-white border-neutral-700'
              }`}
              title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
            >
              {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            {/* Interrupt Speech Button */}
            <button
              onClick={stopAllAudioPlayback}
              disabled={sessionState !== 'SPEAKING'}
              className="px-4 py-2.5 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 font-semibold text-xs flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-95"
              title="Interrupt speech and return to listening"
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Interrupt</span>
            </button>

            {/* Reconnect button if error */}
            {sessionState === 'ERROR' && (
              <button
                onClick={() => startLiveCall(false)}
                className="px-4 py-2.5 rounded-2xl bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-lg active:scale-95"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Reconnect</span>
              </button>
            )}

            {/* End Call Button */}
            <button
              onClick={onClose}
              className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm shadow-xl shadow-red-950/50 cursor-pointer transition-all active:scale-95"
              title="End Voice Call"
            >
              <PhoneOff className="w-5 h-5" />
              <span>End Call</span>
            </button>
          </div>
        </div>

        {/* Footer info note */}
        <div className="w-full px-5 py-2 border-t border-neutral-800/80 bg-neutral-950/60 text-center text-[10px] text-neutral-400 flex items-center justify-center gap-1.5">
          <span>Continuous Loop:</span>
          <span className="text-emerald-400 font-medium">CONNECTED</span>
          <span>→</span>
          <span className="text-emerald-400 font-medium">LISTENING</span>
          <span>→</span>
          <span className="text-sky-400 font-medium">USER SPEAKING</span>
          <span>→</span>
          <span className="text-purple-400 font-medium">PROCESSING</span>
          <span>→</span>
          <span className="text-rose-400 font-medium">SPEAKING</span>
          <span>→</span>
          <span className="text-emerald-400 font-medium">LISTENING</span>
        </div>
      </div>
    </div>
  );
};
