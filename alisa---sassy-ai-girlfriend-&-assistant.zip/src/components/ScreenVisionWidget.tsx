import React, { useState, useEffect, useRef } from 'react';
import {
  Monitor,
  Video,
  VideoOff,
  Pause,
  Play,
  Square,
  Sparkles,
  HelpCircle,
  AlertTriangle,
  Code,
  FileText,
  Type,
  Image as ImageIcon,
  Send,
  X,
  Minimize2,
  Maximize2,
  RefreshCw,
  Eye,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { screenVisionService, ScreenVisionState } from '../services/screenVisionService';

interface ScreenVisionWidgetProps {
  isOpen: boolean;
  onClose: () => void;
  onSendScreenQuestion?: (question: string, compressedImage: string) => void;
}

export const ScreenVisionWidget: React.FC<ScreenVisionWidgetProps> = ({
  isOpen,
  onClose,
  onSendScreenQuestion,
}) => {
  const [visionState, setVisionState] = useState<ScreenVisionState>(screenVisionService.getState());
  const [isMinimized, setIsMinimized] = useState(false);
  const [customQuestion, setCustomQuestion] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [capturedThumbnail, setCapturedThumbnail] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Subscribe to Screen Vision service state changes
  useEffect(() => {
    const unsubscribe = screenVisionService.subscribe((state) => {
      setVisionState(state);
      if (videoRef.current && state.stream) {
        if (videoRef.current.srcObject !== state.stream) {
          videoRef.current.srcObject = state.stream;
          videoRef.current.play().catch(() => {});
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Update video element when stream or modal opens
  useEffect(() => {
    if (videoRef.current && visionState.stream) {
      videoRef.current.srcObject = visionState.stream;
      videoRef.current.play().catch(() => {});
    }
  }, [visionState.stream, isOpen, isMinimized]);

  if (!isOpen && !visionState.isSharing) return null;

  // Handle Start Sharing
  const handleStartSharing = async () => {
    setAnalysisError(null);
    try {
      await screenVisionService.startSharing();
    } catch (err: any) {
      console.warn('Screen sharing error:', err);
    }
  };

  // Handle Pause / Resume
  const handleTogglePause = () => {
    if (visionState.isPaused) {
      screenVisionService.resumeSharing();
    } else {
      screenVisionService.pauseSharing();
    }
  };

  // Handle Stop Sharing
  const handleStopSharing = () => {
    screenVisionService.stopSharing();
    setAnalysisResult(null);
    setCapturedThumbnail(null);
  };

  // Execute Screen Analysis with Compressed Frame
  const handleAskScreenQuestion = async (questionText: string) => {
    if (!visionState.isSharing) {
      setAnalysisError('Please click "Start Screen Sharing" first so Myraa can see your screen.');
      return;
    }
    if (visionState.isPaused) {
      setAnalysisError('Screen sharing is paused. Resume sharing to allow Myraa to inspect your screen.');
      return;
    }

    setIsAnalyzing(true);
    setAnalysisError(null);

    try {
      // Capture responsibly compressed frame (~60KB to 90KB JPEG)
      const compressedBase64 = await screenVisionService.captureCompressedFrame(1280, 0.7);

      if (!compressedBase64) {
        throw new Error('Unable to capture visible frame. Ensure screen sharing is active.');
      }

      setCapturedThumbnail(`data:image/jpeg;base64,${compressedBase64}`);

      // Call external handler if provided (for chat timeline integration)
      if (onSendScreenQuestion) {
        onSendScreenQuestion(questionText, compressedBase64);
      }

      // Fetch dedicated visual analysis from /api/screen-vision
      const res = await fetch('/api/screen-vision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: compressedBase64,
          question: questionText,
          previousVisualContext: visionState.lastVisualContext,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `Server responded with ${res.status}`);
      }

      const data = await res.json();
      setAnalysisResult(data.reply);
      screenVisionService.setVisualContext(data.reply.slice(0, 300));
    } catch (err: any) {
      console.error('Screen vision request failed:', err);
      setAnalysisError(err.message || 'Screen analysis failed. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Quick Preset Prompts requested by user
  const quickPrompts = [
    { label: 'What is on my screen?', icon: Eye, prompt: 'What is on my screen?' },
    { label: 'What website am I on?', icon: Monitor, prompt: 'What website am I on?' },
    { label: 'Do you see an error?', icon: AlertTriangle, prompt: 'Do you see an error?' },
    { label: 'Explain this code', icon: Code, prompt: 'Explain this code.' },
    { label: 'Summarize this page', icon: FileText, prompt: 'Summarize this page.' },
    { label: 'Read the visible text', icon: Type, prompt: 'Read the visible text.' },
    { label: 'How is this thumbnail?', icon: ImageIcon, prompt: 'How is this thumbnail?' },
  ];

  // Minimized PiP View
  if (isMinimized && visionState.isSharing) {
    return (
      <div className="fixed bottom-4 right-4 z-50 bg-neutral-900/95 border border-cyan-500/50 rounded-2xl shadow-2xl p-2.5 backdrop-blur-md flex items-center gap-3 animate-in fade-in">
        <div className="relative w-28 h-16 bg-neutral-950 rounded-lg overflow-hidden border border-neutral-800">
          <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
          {visionState.isPaused && (
            <div className="absolute inset-0 bg-neutral-950/80 flex items-center justify-center text-[10px] text-amber-400 font-mono">
              PAUSED
            </div>
          )}
        </div>

        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span className="text-xs font-bold text-white">Screen Vision</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => handleAskScreenQuestion('What is on my screen?')}
              disabled={isAnalyzing}
              className="px-2 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-white text-[10px] font-semibold cursor-pointer"
            >
              {isAnalyzing ? 'Inspecting...' : 'Inspect Screen'}
            </button>
            <button
              onClick={() => setIsMinimized(false)}
              className="p-1 rounded bg-neutral-800 text-neutral-300 hover:text-white cursor-pointer"
              title="Expand"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-neutral-950/85 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="px-5 py-3.5 border-b border-neutral-800 bg-neutral-950/70 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Monitor className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display font-bold text-base text-white">
                  Real Screen Vision
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-[10px] font-mono font-semibold uppercase">
                  MYRAA V5
                </span>
                {visionState.isSharing && (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>LIVE SHARING</span>
                  </span>
                )}
                {visionState.isPaused && (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 text-[10px] font-mono">
                    <span>PAUSED</span>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-neutral-400">
                Native Screen Capture API · Select Entire Screen, App Window, or Tab
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {visionState.isSharing && (
              <button
                onClick={() => setIsMinimized(true)}
                className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-all cursor-pointer"
                title="Minimize to Picture-in-Picture"
              >
                <Minimize2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-neutral-800/80 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-all cursor-pointer"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 md:p-6 overflow-y-auto space-y-4">
          {/* 1. Live Screen Video Preview Container */}
          <div className="relative w-full aspect-video md:h-72 bg-neutral-950 rounded-2xl overflow-hidden border border-neutral-800 shadow-inner flex items-center justify-center">
            {visionState.isSharing ? (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className={`w-full h-full object-contain ${
                    visionState.isPaused ? 'opacity-40 filter grayscale' : ''
                  }`}
                />
                {visionState.isPaused && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-neutral-950/60 backdrop-blur-xs">
                    <Pause className="w-8 h-8 text-amber-400 mb-1" />
                    <span className="text-xs font-semibold text-amber-300">
                      Screen Sharing Paused
                    </span>
                    <span className="text-[10px] text-neutral-400">
                      No frames captured while paused
                    </span>
                  </div>
                )}
                {/* Surface badge */}
                <div className="absolute top-2 left-2 px-2.5 py-1 rounded-lg bg-neutral-950/80 border border-neutral-800 text-[10px] font-mono text-neutral-300 flex items-center gap-1.5 backdrop-blur-sm">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span>
                    Surface: {visionState.displaySurface || 'Screen / Window'}
                  </span>
                </div>
              </>
            ) : (
              <div className="flex flex-col items-center text-center p-6 max-w-md">
                <div className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 text-neutral-400 mb-3">
                  <Monitor className="w-8 h-8 text-cyan-400" />
                </div>
                <h3 className="font-semibold text-white text-sm mb-1">
                  Ready to Share Your Screen
                </h3>
                <p className="text-xs text-neutral-400 mb-4 leading-relaxed">
                  Click below to activate the browser's native screen picker. You can choose to share your{' '}
                  <span className="text-cyan-300">Entire Screen</span>, a specific{' '}
                  <span className="text-cyan-300">Application Window</span>, or an individual{' '}
                  <span className="text-cyan-300">Browser Tab</span>.
                </p>
                <button
                  onClick={handleStartSharing}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-xs flex items-center gap-2 cursor-pointer shadow-lg shadow-cyan-950/40 active:scale-95 transition-all"
                >
                  <Video className="w-4 h-4" />
                  <span>Start Screen Sharing</span>
                </button>
              </div>
            )}
          </div>

          {/* 2. Controls Toolbar */}
          {visionState.isSharing && (
            <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-2xl bg-neutral-950/60 border border-neutral-800">
              <div className="flex items-center gap-2">
                <button
                  onClick={handleTogglePause}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                    visionState.isPaused
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-200'
                  }`}
                >
                  {visionState.isPaused ? (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Resume</span>
                    </>
                  ) : (
                    <>
                      <Pause className="w-3.5 h-3.5" />
                      <span>Pause</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleStopSharing}
                  className="px-3 py-1.5 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <Square className="w-3.5 h-3.5 fill-current" />
                  <span>Stop Sharing</span>
                </button>
              </div>

              <div className="flex items-center gap-2 text-xs text-neutral-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Frames captured on-demand · Compressed JPEG (1280px)</span>
              </div>
            </div>
          )}

          {/* Error Message banner */}
          {(visionState.error || analysisError) && (
            <div className="p-3 rounded-xl bg-red-950/40 border border-red-900/50 text-red-400 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{visionState.error || analysisError}</span>
            </div>
          )}

          {/* 3. Preset Visual Questions */}
          <div>
            <span className="text-[11px] font-semibold text-neutral-400 uppercase tracking-wider block mb-2">
              ⚡ Ask Myraa About Your Screen:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 text-xs">
              {quickPrompts.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <button
                    key={idx}
                    onClick={() => handleAskScreenQuestion(item.prompt)}
                    disabled={!visionState.isSharing || visionState.isPaused || isAnalyzing}
                    className="p-2.5 rounded-xl bg-neutral-950/80 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-medium flex items-center gap-2 transition-all cursor-pointer active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    <Icon className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 4. Custom Question Input */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (customQuestion.trim()) {
                handleAskScreenQuestion(customQuestion.trim());
                setCustomQuestion('');
              }
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={customQuestion}
              onChange={(e) => setCustomQuestion(e.target.value)}
              placeholder="Ask anything about the screen (e.g., 'What is causing this traceback?')..."
              disabled={!visionState.isSharing || visionState.isPaused || isAnalyzing}
              className="flex-1 px-4 py-2.5 bg-neutral-950 border border-neutral-800 focus:border-cyan-500/60 rounded-xl text-xs text-white placeholder-neutral-500 outline-none transition-all disabled:opacity-40"
            />
            <button
              type="submit"
              disabled={!customQuestion.trim() || !visionState.isSharing || isAnalyzing}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-md shadow-cyan-950/30"
            >
              {isAnalyzing ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
              <span>{isAnalyzing ? 'Analyzing...' : 'Ask'}</span>
            </button>
          </form>

          {/* 5. Analysis Output Card */}
          {analysisResult && (
            <div className="p-4 rounded-2xl bg-neutral-950 border border-cyan-500/30 text-xs animate-in fade-in space-y-2">
              <div className="flex items-center justify-between text-neutral-400 border-b border-neutral-800/80 pb-2">
                <span className="font-semibold text-cyan-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Myraa's Visual Analysis</span>
                </span>
                <span className="text-[10px] text-neutral-500 font-mono">
                  Gemini Multimodal Vision
                </span>
              </div>
              <p className="text-neutral-200 leading-relaxed whitespace-pre-line text-[13px]">
                {analysisResult}
              </p>
            </div>
          )}
        </div>

        {/* Footer Note */}
        <div className="px-5 py-2.5 border-t border-neutral-800 bg-neutral-950/70 text-[11px] text-neutral-400 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
            <span>Privacy Guarantee: Screen frames are only read on demand. Stop anytime.</span>
          </div>
          <span className="text-[10px] font-mono text-neutral-500">
            navigator.mediaDevices.getDisplayMedia
          </span>
        </div>
      </div>
    </div>
  );
};
