import React, { useRef, useEffect, useState, useMemo } from 'react';
import { MoodType } from '../types';
import { Zap, Volume2, Sparkles, Radio } from 'lucide-react';

export type CharacterState = 'IDLE' | 'THINKING' | 'TALKING';

export interface AlisaAvatarProps {
  mood?: MoodType;
  isSpeaking?: boolean;
  isThinking?: boolean;
  characterState?: CharacterState;
  innerMonologue?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showStatusIndicator?: boolean;
}

export const AlisaAvatar: React.FC<AlisaAvatarProps> = ({
  mood = 'sassy',
  isSpeaking = false,
  isThinking = false,
  characterState,
  innerMonologue,
  size = 'md',
  className = '',
  showStatusIndicator = true,
}) => {
  // Video element references for each of the three states
  const idleVideoRef = useRef<HTMLVideoElement>(null);
  const thinkingVideoRef = useRef<HTMLVideoElement>(null);
  const talkingVideoRef = useRef<HTMLVideoElement>(null);

  // Track video loading/error states for graceful fallback
  const [videoLoaded, setVideoLoaded] = useState({
    idle: false,
    thinking: false,
    talking: false,
  });

  // Determine active character state from props or state machine
  const activeState: CharacterState = useMemo(() => {
    if (characterState) return characterState;
    if (isSpeaking) return 'TALKING';
    if (isThinking) return 'THINKING';
    return 'IDLE';
  }, [characterState, isSpeaking, isThinking]);

  // Synchronize video playback with active character state
  useEffect(() => {
    const playSafe = (video: HTMLVideoElement | null) => {
      if (!video) return;
      try {
        const promise = video.play();
        if (promise !== undefined) {
          promise.catch(() => {
            // Ignore benign browser autoplay policy rejections
          });
        }
      } catch {
        // Silently continue
      }
    };

    if (activeState === 'IDLE') {
      playSafe(idleVideoRef.current);
    } else if (activeState === 'THINKING') {
      if (thinkingVideoRef.current) {
        thinkingVideoRef.current.currentTime = 0;
      }
      playSafe(thinkingVideoRef.current);
    } else if (activeState === 'TALKING') {
      if (talkingVideoRef.current) {
        talkingVideoRef.current.currentTime = 0;
      }
      playSafe(talkingVideoRef.current);
    }
  }, [activeState]);

  // Mood configuration styling
  const moodConfig: Record<
    MoodType,
    {
      label: string;
      color: string;
      gradient: string;
      subtext: string;
      borderColor: string;
    }
  > = {
    sassy: {
      label: 'Sassy 💅',
      color: 'text-fuchsia-400',
      gradient: 'from-pink-500 via-purple-600 to-rose-500',
      subtext: 'Judging your texting speed...',
      borderColor: 'border-fuchsia-500/50',
    },
    flirty: {
      label: 'Flirty 😉',
      color: 'text-rose-400',
      gradient: 'from-rose-500 via-pink-600 to-red-500',
      subtext: 'Teasing your heartstrings',
      borderColor: 'border-rose-500/50',
    },
    blushing: {
      label: 'Blushing 😳',
      color: 'text-rose-300',
      gradient: 'from-rose-400 via-pink-400 to-red-400',
      subtext: 'Wait, that was actually smooth...',
      borderColor: 'border-pink-400/50',
    },
    smug: {
      label: 'Smug 😏',
      color: 'text-amber-400',
      gradient: 'from-amber-400 via-orange-500 to-pink-500',
      subtext: 'I told you I was right!',
      borderColor: 'border-amber-500/50',
    },
    loving: {
      label: 'Loving 🥰',
      color: 'text-red-400',
      gradient: 'from-red-500 via-pink-500 to-rose-400',
      subtext: 'Secretly crazy about you',
      borderColor: 'border-rose-500/50',
    },
    pouty: {
      label: 'Pouty 😤',
      color: 'text-violet-400',
      gradient: 'from-purple-500 via-indigo-500 to-pink-500',
      subtext: 'You didn\'t reply for 2 minutes!',
      borderColor: 'border-purple-500/50',
    },
    shocked: {
      label: 'Shocked 😱',
      color: 'text-cyan-400',
      gradient: 'from-cyan-400 via-blue-500 to-indigo-500',
      subtext: 'Wait... did you really just say that?!',
      borderColor: 'border-cyan-400/50',
    },
    playful: {
      label: 'Playful ✨',
      color: 'text-emerald-400',
      gradient: 'from-emerald-400 via-teal-500 to-pink-500',
      subtext: 'Plotting a mischievous comeback',
      borderColor: 'border-emerald-400/50',
    },
  };

  const currentMoodInfo = moodConfig[mood] || moodConfig.sassy;

  // Responsive dimension styles
  const sizeClasses = {
    sm: 'w-12 h-12 md:w-14 md:h-14',
    md: 'w-24 h-24 md:w-28 md:h-28',
    lg: 'w-36 h-36 md:w-48 md:h-48',
    xl: 'w-48 h-48 md:w-56 md:h-56',
  };

  // State-specific subtle ambient ring glow effects
  const getStateGlowStyle = () => {
    switch (activeState) {
      case 'THINKING':
        return 'ring-2 md:ring-4 ring-amber-400/40 shadow-lg shadow-amber-950/50 scale-[1.02]';
      case 'TALKING':
        return 'ring-2 md:ring-4 ring-rose-400/60 shadow-xl shadow-rose-950/60 scale-[1.03]';
      case 'IDLE':
      default:
        return 'shadow-lg shadow-rose-950/30';
    }
  };

  return (
    <div className={`flex flex-col items-center select-none relative ${className}`}>
      {/* Outer audio pulse wave rings when talking (synchronized with audio) */}
      {activeState === 'TALKING' && (
        <>
          <div className="absolute inset-0 rounded-full bg-rose-500/20 animate-ping pointer-events-none scale-125" />
          <div className="absolute inset-0 rounded-full bg-pink-500/25 animate-pulse pointer-events-none scale-110" />
        </>
      )}

      {/* Outer amber pulse ring when thinking */}
      {activeState === 'THINKING' && (
        <div className="absolute inset-0 rounded-full bg-amber-500/15 animate-pulse pointer-events-none scale-110" />
      )}

      {/* Main Avatar Character Frame */}
      <div
        className={`relative ${sizeClasses[size]} rounded-full p-[3px] bg-gradient-to-tr ${currentMoodInfo.gradient} transition-all duration-500 overflow-hidden ${getStateGlowStyle()}`}
      >
        {/* Inner Video Container (No black interface, no controls, object-cover) */}
        <div className="w-full h-full rounded-full bg-neutral-950 overflow-hidden relative flex items-center justify-center border border-neutral-900/90">
          {/* Subtle Ambient Background Gradient behind video */}
          <div className="absolute inset-0 bg-gradient-to-tr from-rose-950/40 via-purple-950/30 to-neutral-900 pointer-events-none" />

          {/* Fallback Artwork Layer (always present so there is zero black screen) */}
          <div className="absolute inset-0 w-full h-full flex items-center justify-center pointer-events-none bg-neutral-950">
            <img
              src="/src/assets/images/myraa_character_idle_1790433024627.jpg"
              alt="Myraa Character"
              className="w-full h-full object-cover opacity-80"
              onError={(e) => {
                // Silently hide image if unavailable
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
          </div>

          {/* 1. IDLE VIDEO STATE (JUST WAITNG.mp4) */}
          <video
            ref={idleVideoRef}
            muted
            autoPlay
            loop
            playsInline
            controls={false}
            disablePictureInPicture
            disableRemotePlayback
            onLoadedData={() => setVideoLoaded((prev) => ({ ...prev, idle: true }))}
            className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-400 ease-in-out pointer-events-none ${
              activeState === 'IDLE' ? 'opacity-100 z-20' : 'opacity-0 z-0'
            }`}
          >
            <source src="/JUST WAITNG.mp4" type="video/mp4" />
            <source src="/JUST%20WAITNG.mp4" type="video/mp4" />
            <source src="/videos/JUST WAITNG.mp4" type="video/mp4" />
            <source src="/JUST_WAITNG.mp4" type="video/mp4" />
          </video>

          {/* 2. THINKING VIDEO STATE (ANIMA GIRL THINKING.mp4) */}
          <video
            ref={thinkingVideoRef}
            muted
            autoPlay
            loop
            playsInline
            controls={false}
            disablePictureInPicture
            disableRemotePlayback
            onLoadedData={() => setVideoLoaded((prev) => ({ ...prev, thinking: true }))}
            className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-400 ease-in-out pointer-events-none ${
              activeState === 'THINKING' ? 'opacity-100 z-20' : 'opacity-0 z-0'
            }`}
          >
            <source src="/ANIMA GIRL THINKING.mp4" type="video/mp4" />
            <source src="/ANIMA%20GIRL%20THINKING.mp4" type="video/mp4" />
            <source src="/videos/ANIMA GIRL THINKING.mp4" type="video/mp4" />
            <source src="/ANIMA_GIRL_THINKING.mp4" type="video/mp4" />
          </video>

          {/* 3. TALKING VIDEO STATE (ANIMA GIRL TAKING.mp4) */}
          <video
            ref={talkingVideoRef}
            muted
            autoPlay
            loop
            playsInline
            controls={false}
            disablePictureInPicture
            disableRemotePlayback
            onLoadedData={() => setVideoLoaded((prev) => ({ ...prev, talking: true }))}
            className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-400 ease-in-out pointer-events-none ${
              activeState === 'TALKING' ? 'opacity-100 z-20' : 'opacity-0 z-0'
            }`}
          >
            <source src="/ANIMA GIRL TAKING.mp4" type="video/mp4" />
            <source src="/ANIMA%20GIRL%20TAKING.mp4" type="video/mp4" />
            <source src="/videos/ANIMA GIRL TAKING.mp4" type="video/mp4" />
            <source src="/ANIMA_GIRL_TAKING.mp4" type="video/mp4" />
          </video>

          {/* Subtle State Overlay Badges */}
          {activeState === 'THINKING' && (
            <div className="absolute top-2 right-2 z-30 bg-amber-500/90 text-neutral-950 p-1 rounded-full shadow-md backdrop-blur-sm animate-pulse">
              <Zap className="w-3 h-3 fill-neutral-950" />
            </div>
          )}

          {activeState === 'TALKING' && (
            <div className="absolute top-2 right-2 z-30 bg-rose-500/90 text-white p-1 rounded-full shadow-md backdrop-blur-sm animate-bounce">
              <Volume2 className="w-3 h-3" />
            </div>
          )}
        </div>

        {/* Live Status Indicator Dot at bottom right */}
        {showStatusIndicator && (
          <div className="absolute bottom-0 right-0 bg-neutral-950 p-0.5 rounded-full border border-neutral-800 z-30">
            {activeState === 'TALKING' ? (
              <div
                className="w-3 h-3 rounded-full bg-rose-500 animate-ping shadow-sm shadow-rose-500/50"
                title="Talking"
              />
            ) : activeState === 'THINKING' ? (
              <div
                className="w-3 h-3 rounded-full bg-amber-400 animate-pulse shadow-sm shadow-amber-400/50"
                title="Thinking"
              />
            ) : (
              <div
                className="w-3 h-3 rounded-full bg-emerald-400 shadow-sm shadow-emerald-500/50"
                title="Idle (Online)"
              />
            )}
          </div>
        )}
      </div>

      {/* Mood Title & State Subtext for medium/large sizes */}
      {size !== 'sm' && (
        <div className="mt-2 text-center">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-neutral-900/90 border border-neutral-800 text-xs font-medium">
            <span className={currentMoodInfo.color}>{currentMoodInfo.label}</span>
            <span className="text-[10px] text-neutral-500">·</span>
            <span className="text-[10px] font-mono uppercase text-neutral-400">
              {activeState}
            </span>
          </div>
          <p className="text-[11px] text-neutral-400 mt-1 max-w-[170px] truncate">
            {activeState === 'TALKING'
              ? 'Speaking with you...'
              : activeState === 'THINKING'
              ? 'Analyzing & generating...'
              : currentMoodInfo.subtext}
          </p>
        </div>
      )}

      {/* Secret Inner Monologue preview */}
      {innerMonologue && (size === 'lg' || size === 'xl') && (
        <div className="mt-2 text-xs text-rose-300/80 bg-rose-950/30 border border-rose-900/40 rounded-xl px-3 py-1.5 max-w-xs text-center italic shadow-inner">
          <span className="font-semibold text-rose-400 not-italic">Thought: </span>
          &ldquo;{innerMonologue.replace(/[()]/g, '')}&rdquo;
        </div>
      )}
    </div>
  );
};
