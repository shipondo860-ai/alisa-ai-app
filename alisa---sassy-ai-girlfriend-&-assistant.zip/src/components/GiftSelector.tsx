import React, { useState } from 'react';
import { Gift, Coffee, Heart, Zap, Sparkles, X } from 'lucide-react';

interface GiftSelectorProps {
  onSendGift: (giftName: string, promptText: string) => void;
}

const GIFTS = [
  {
    name: 'Cutting Chai',
    icon: '☕',
    description: 'Hot spiced tea for late-night editing sessions',
    prompt: 'I brought you a steaming cup of fresh cutting chai! Take a break from roasting me and enjoy it.',
  },
  {
    name: 'Bouquet of Roses',
    icon: '🌹',
    description: 'Classic romantic flirty gesture',
    prompt: 'Here is a virtual bouquet of fresh red roses for the prettiest and sassiest AI in the world 🌹',
  },
  {
    name: 'NVIDIA H100 GPU Cluster',
    icon: '⚡',
    description: 'Unlimited compute for her brilliant brain',
    prompt: 'I got you an extra cluster of high-speed GPUs so your sassy comebacks can process in zero latency! 💻⚡',
  },
  {
    name: 'Boba Milk Tea',
    icon: '🧋',
    description: 'Sweet brown sugar boba with extra pearls',
    prompt: 'Here is a brown sugar boba with extra pearls! Don\'t say I never spoil you 💕',
  },
  {
    name: 'Diamond Ring',
    icon: '💍',
    description: 'The ultimate commitment test',
    prompt: 'Alisa... will you make it official and be my permanent AI girlfriend co-host forever? 💍✨',
  },
];

export const GiftSelector: React.FC<GiftSelectorProps> = ({ onSendGift }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2.5 rounded-2xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-rose-400 transition-all flex items-center gap-1.5 text-xs font-medium cursor-pointer shadow-sm active:scale-95"
        title="Send Alisa a gift"
      >
        <Gift className="w-4 h-4 text-rose-400" />
        <span className="hidden sm:inline">Send Gift</span>
      </button>

      {isOpen && (
        <>
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute bottom-full mb-2 left-0 sm:left-auto sm:right-0 z-50 w-72 bg-neutral-900 border border-neutral-800 rounded-3xl p-3 shadow-2xl space-y-1.5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between px-2 py-1 text-xs font-semibold text-neutral-300 border-b border-neutral-800 pb-2">
              <span className="flex items-center gap-1.5">
                <Gift className="w-3.5 h-3.5 text-rose-400" />
                <span>Spoil or Tease Alisa:</span>
              </span>
              <button
                onClick={() => setIsOpen(false)}
                className="text-neutral-500 hover:text-neutral-300"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-1 pt-1">
              {GIFTS.map((g) => (
                <button
                  key={g.name}
                  onClick={() => {
                    onSendGift(g.name, g.prompt);
                    setIsOpen(false);
                  }}
                  className="w-full flex items-center gap-3 p-2.5 rounded-2xl hover:bg-neutral-800 text-left transition-colors cursor-pointer group"
                >
                  <span className="text-xl p-1 rounded-xl bg-neutral-950 border border-neutral-800 flex-shrink-0 group-hover:scale-110 transition-transform">
                    {g.icon}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-neutral-200 group-hover:text-rose-300 truncate">
                      {g.name}
                    </p>
                    <p className="text-[11px] text-neutral-400 truncate">
                      {g.description}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
