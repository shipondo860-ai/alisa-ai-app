import React, { useState, useEffect } from 'react';
import {
  ListFilter,
  X,
  Trash2,
  Download,
  Copy,
  Check,
  CheckCircle2,
  XCircle,
  Clock,
  Search,
  Terminal,
} from 'lucide-react';
import { AssistantActivityLog } from '../types/assistant';
import { getActivityLogs, clearActivityLogs, subscribeToLogs } from '../services/actionLog';

interface ActionLogModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ActionLogModal: React.FC<ActionLogModalProps> = ({ isOpen, onClose }) => {
  const [logs, setLogs] = useState<AssistantActivityLog[]>([]);
  const [filter, setFilter] = useState<'all' | 'success' | 'failed' | 'cancelled'>('all');
  const [search, setSearch] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    const unsubscribe = subscribeToLogs((updated) => setLogs(updated));
    return () => unsubscribe();
  }, [isOpen]);

  if (!isOpen) return null;

  const filteredLogs = logs.filter((log) => {
    if (filter !== 'all' && log.resultStatus !== filter) return false;
    if (search) {
      const q = search.toLowerCase();
      return (
        log.userSpeech.toLowerCase().includes(q) ||
        log.actionSummary.toLowerCase().includes(q) ||
        log.resultMessage.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCopyLogs = () => {
    const text = filteredLogs
      .map(
        (l) =>
          `${l.timeFormatted}\nUser: "${l.userSpeech}"\nRequested action: ${l.actionSummary}\n\n${l.timeFormatted}\nMyraa: "${l.resultMessage}"\n\nResult:\n${
            l.resultStatus === 'success'
              ? 'SUCCESS'
              : l.resultStatus === 'cancelled'
              ? 'CANCELLED'
              : 'FAILED'
          }`
      )
      .join('\n\n-------------------------\n\n');

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportJson = () => {
    const blob = new Blob([JSON.stringify(logs, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `alisa_assistant_activity_log_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-neutral-950/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-neutral-800 flex items-center justify-between bg-gradient-to-r from-blue-950/40 via-neutral-900 to-neutral-900">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-blue-600/20 border border-blue-500/30 text-blue-400">
              <Terminal className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-base md:text-lg text-white">
                  Assistant Activity & Audit Log
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-[10px] font-mono">
                  {logs.length} Recorded
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Visible local timeline of voice commands, executed actions, and safety results.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter bar */}
        <div className="p-3 bg-neutral-950/60 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            {(['all', 'success', 'failed', 'cancelled'] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setFilter(mode)}
                className={`px-3 py-1.5 rounded-xl capitalize font-medium transition-all cursor-pointer ${
                  filter === mode
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 flex-1 max-w-xs">
            <div className="relative w-full">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-500" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search speech, action, result..."
                className="w-full bg-neutral-900 border border-neutral-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleCopyLogs}
              className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors cursor-pointer"
              title="Copy formatted log"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
            <button
              onClick={handleExportJson}
              className="p-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors cursor-pointer"
              title="Export JSON"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              onClick={clearActivityLogs}
              className="p-2 rounded-xl bg-neutral-800 hover:bg-red-900/60 text-neutral-400 hover:text-red-300 transition-colors cursor-pointer"
              title="Clear log"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content list */}
        <div className="p-4 md:p-6 overflow-y-auto space-y-3 flex-1 font-mono text-xs">
          {filteredLogs.length === 0 ? (
            <div className="py-12 text-center text-neutral-500">
              No activity logs recorded yet. Speak a voice command!
            </div>
          ) : (
            filteredLogs.map((log) => (
              <div
                key={log.id}
                className="p-3.5 rounded-2xl bg-neutral-950/80 border border-neutral-800/80 hover:border-neutral-700 transition-colors space-y-2.5"
              >
                {/* Time & User speech line */}
                <div className="flex items-start justify-between gap-2 border-b border-neutral-850 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-cyan-400 font-bold font-mono px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40 text-[11px]">
                      {log.timeFormatted}
                    </span>
                    <span className="text-neutral-400 text-xs">User:</span>
                    <span className="text-white font-semibold">
                      &ldquo;{log.userSpeech}&rdquo;
                    </span>
                  </div>
                  <span
                    className={`uppercase tracking-wider font-bold text-[10px] px-2.5 py-0.5 rounded-full border ${
                      log.resultStatus === 'success'
                        ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                        : log.resultStatus === 'cancelled'
                        ? 'bg-amber-500/15 border-amber-500/30 text-amber-400'
                        : 'bg-red-500/15 border-red-500/30 text-red-400'
                    }`}
                  >
                    {log.resultStatus === 'success'
                      ? 'SUCCESS'
                      : log.resultStatus === 'cancelled'
                      ? 'CANCELLED'
                      : 'FAILED'}
                  </span>
                </div>

                {/* Requested Action */}
                <div className="text-[11px] text-neutral-400 flex items-center gap-2">
                  <span className="text-neutral-500 font-semibold">Requested Action:</span>
                  <span className="text-neutral-300 font-mono">{log.actionSummary}</span>
                </div>

                {/* Myraa response line */}
                <div className="flex items-start gap-2 pl-3 border-l-2 border-rose-500/40 py-0.5">
                  <span className="text-rose-400 font-bold whitespace-nowrap text-xs">
                    {log.timeFormatted} — Myraa:
                  </span>
                  <span
                    className={`text-xs ${
                      log.resultStatus === 'success'
                        ? 'text-emerald-300'
                        : log.resultStatus === 'cancelled'
                        ? 'text-amber-300'
                        : 'text-red-300'
                    }`}
                  >
                    &ldquo;{log.resultMessage}&rdquo;
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950/60 flex items-center justify-between text-xs text-neutral-400">
          <span>Format: [Time] — User: "..." / [Time] — Alisa: ...</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
