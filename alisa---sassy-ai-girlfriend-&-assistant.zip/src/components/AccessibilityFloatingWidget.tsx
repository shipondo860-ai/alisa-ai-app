import React, { useState } from 'react';
import {
  Eye,
  ArrowDown,
  ArrowUp,
  ArrowLeft,
  MousePointerClick,
  Keyboard,
  ShieldCheck,
  ChevronUp,
  ChevronDown,
  Check,
  AlertCircle,
} from 'lucide-react';
import { executeAccessibilityAction } from '../services/accessibilityService';

export const AccessibilityFloatingWidget: React.FC = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [tapTarget, setTapTarget] = useState('');
  const [typeText, setTypeText] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const runAction = async (
    type: 'scroll_down' | 'scroll_up' | 'back' | 'tap' | 'type_text',
    target?: string,
    value?: string
  ) => {
    setStatusMessage(null);
    const res = await executeAccessibilityAction({ type, target, value }, `Accessibility: ${type}`);
    setStatusMessage(res.message);
    setTimeout(() => {
      setStatusMessage(null);
    }, 4000);
  };

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end">
      {/* Expanded Control Box */}
      {isExpanded && (
        <div className="mb-2 w-72 sm:w-80 bg-neutral-900/95 border border-purple-500/40 rounded-3xl p-4 shadow-2xl shadow-purple-950/50 backdrop-blur-md space-y-3 animate-in fade-in slide-in-from-bottom duration-150 text-xs">
          {/* Header */}
          <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-xl bg-purple-500/20 text-purple-400">
                <Eye className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-neutral-100">Accessibility Service</h4>
                <p className="text-[10px] text-purple-300 font-mono">Module 2 · User-Authorized</p>
              </div>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-bold">
              ACTIVE
            </span>
          </div>

          {/* Status Message */}
          {statusMessage && (
            <div className="p-2 rounded-xl bg-neutral-950 border border-purple-500/30 text-[11px] text-neutral-200">
              {statusMessage}
            </div>
          )}

          {/* Navigation & Gesture Controls */}
          <div className="grid grid-cols-3 gap-1.5">
            <button
              onClick={() => runAction('scroll_down')}
              className="flex flex-col items-center justify-center p-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
              title="Scroll page down"
            >
              <ArrowDown className="w-4 h-4 text-purple-400 mb-0.5" />
              <span className="text-[10px]">Scroll Down</span>
            </button>

            <button
              onClick={() => runAction('scroll_up')}
              className="flex flex-col items-center justify-center p-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
              title="Scroll page up"
            >
              <ArrowUp className="w-4 h-4 text-purple-400 mb-0.5" />
              <span className="text-[10px]">Scroll Up</span>
            </button>

            <button
              onClick={() => runAction('back')}
              className="flex flex-col items-center justify-center p-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white transition-colors cursor-pointer"
              title="Trigger Android Back Navigation"
            >
              <ArrowLeft className="w-4 h-4 text-purple-400 mb-0.5" />
              <span className="text-[10px]">Back Button</span>
            </button>
          </div>

          {/* Tap Element by Visible Label */}
          <div className="space-y-1 pt-1">
            <span className="text-[10px] text-neutral-400 font-semibold block">
              Tap Screen Element by Name:
            </span>
            <div className="flex gap-1.5">
              <input
                type="text"
                value={tapTarget}
                onChange={(e) => setTapTarget(e.target.value)}
                placeholder="e.g. Live Call, Send, Reset..."
                className="flex-1 bg-neutral-950 border border-neutral-800 rounded-xl px-2.5 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-purple-500"
              />
              <button
                onClick={() => {
                  if (tapTarget.trim()) runAction('tap', tapTarget.trim());
                }}
                disabled={!tapTarget.trim()}
                className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white font-bold cursor-pointer transition-colors"
              >
                Tap
              </button>
            </div>
          </div>

          {/* Type text into allowed field */}
          <div className="space-y-1">
            <span className="text-[10px] text-neutral-400 font-semibold block">
              Type Text into Field:
            </span>
            <div className="flex gap-1.5">
              <input
                type="text"
                value={typeText}
                onChange={(e) => setTypeText(e.target.value)}
                placeholder="Text to inject..."
                className="flex-1 bg-neutral-950 border border-neutral-800 rounded-xl px-2.5 py-1.5 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-purple-500"
              />
              <button
                onClick={() => {
                  if (typeText.trim()) runAction('type_text', undefined, typeText.trim());
                }}
                disabled={!typeText.trim()}
                className="px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 disabled:opacity-40 text-neutral-200 font-semibold cursor-pointer transition-colors"
              >
                Type
              </button>
            </div>
          </div>

          {/* Security Safeguard Footer */}
          <div className="pt-2 border-t border-neutral-800 text-[10px] text-neutral-500 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-purple-400 flex-shrink-0" />
            <span>Password fields & lock screens remain protected.</span>
          </div>
        </div>
      )}

      {/* Floating Toggle Pill */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex items-center gap-2 px-3.5 py-2.5 rounded-full bg-neutral-900 hover:bg-neutral-800 border border-purple-500/50 shadow-xl shadow-purple-950/40 text-purple-300 font-bold text-xs transition-all cursor-pointer hover:scale-105 active:scale-95"
        title="Android Accessibility Service Controller (Module 2)"
      >
        <Eye className="w-4 h-4 text-purple-400" />
        <span className="font-sans">Accessibility</span>
        {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
      </button>
    </div>
  );
};
