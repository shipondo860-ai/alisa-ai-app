import React, { useState, useEffect } from 'react';
import { Phone, PhoneOff, Radio, ShieldCheck, User } from 'lucide-react';
import {
  ActiveIncomingCall,
  subscribeToIncomingCalls,
  answerIncomingCall,
  rejectIncomingCall,
} from '../services/callControl';

export const IncomingCallDialog: React.FC = () => {
  const [call, setCall] = useState<ActiveIncomingCall | null>(null);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    const unsub = subscribeToIncomingCalls((activeCall) => {
      setCall(activeCall);
      setStatusMsg(null);
    });
    return () => unsub();
  }, []);

  if (!call) return null;

  const handleAnswer = async () => {
    const res = await answerIncomingCall(call.id);
    if (!res.success) {
      setStatusMsg(res.message);
    }
  };

  const handleReject = async () => {
    const res = await rejectIncomingCall(call.id);
    if (!res.success) {
      setStatusMsg(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-sm bg-neutral-900 border border-emerald-500/40 rounded-3xl p-6 shadow-2xl space-y-6 text-center overflow-hidden">
        {/* Ambient Ringing Glow */}
        <div className="absolute -top-12 -left-12 w-36 h-36 bg-emerald-500/20 rounded-full blur-2xl pointer-events-none animate-pulse" />
        <div className="absolute -bottom-12 -right-12 w-36 h-36 bg-rose-500/20 rounded-full blur-2xl pointer-events-none animate-pulse" />

        {/* Incoming call badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-semibold animate-pulse">
          <Radio className="w-3.5 h-3.5" />
          <span>INCOMING ANDROID CALL</span>
        </div>

        {/* Caller Avatar & Name */}
        <div className="space-y-3">
          <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-xl shadow-emerald-950/50 ring-4 ring-emerald-500/30 animate-bounce">
            <User className="w-10 h-10" />
          </div>

          <div>
            <h3 className="font-display font-bold text-xl text-white">
              {call.callerName}
            </h3>
            <p className="text-sm font-mono text-emerald-400 mt-0.5">
              {call.phoneNumber}
            </p>
            <p className="text-[11px] text-neutral-400 mt-1">
              Telecom API · Calling via Android Telephony
            </p>
          </div>
        </div>

        {/* Status error message if permission missing */}
        {statusMsg && (
          <div className="p-2.5 rounded-xl bg-red-950/60 border border-red-800 text-xs text-red-300">
            {statusMsg}
          </div>
        )}

        {/* Action Controls */}
        <div className="flex items-center justify-around gap-4 pt-2">
          {/* Reject */}
          <button
            onClick={handleReject}
            className="flex flex-col items-center gap-1 group cursor-pointer"
          >
            <div className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg shadow-red-950/50 transition-all group-active:scale-90">
              <PhoneOff className="w-6 h-6" />
            </div>
            <span className="text-xs font-semibold text-neutral-400 group-hover:text-red-300">
              Decline (বাতিল)
            </span>
          </button>

          {/* Answer */}
          <button
            onClick={handleAnswer}
            className="flex flex-col items-center gap-1 group cursor-pointer"
          >
            <div className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-950/50 transition-all group-active:scale-90 animate-pulse">
              <Phone className="w-6 h-6" />
            </div>
            <span className="text-xs font-semibold text-neutral-400 group-hover:text-emerald-300">
              Answer (গ্রহণ)
            </span>
          </button>
        </div>

        <div className="pt-2 text-[10px] text-neutral-500 flex items-center justify-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Requires CALL_PHONE permission · Enforces security sandbox</span>
        </div>
      </div>
    </div>
  );
};
