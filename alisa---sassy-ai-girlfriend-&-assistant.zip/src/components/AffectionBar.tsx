import React from 'react';
import { Heart, Sparkles, Brain, Flame } from 'lucide-react';

interface AffectionBarProps {
  affection: number;
  lastDelta: number | null;
  onOpenMemories: () => void;
  memoryCount: number;
}

export const AffectionBar: React.FC<AffectionBarProps> = ({
  affection,
  lastDelta,
  onOpenMemories,
  memoryCount,
}) => {
  const getStageTitle = (score: number) => {
    if (score < 25) return { title: 'Bantering Frenemies', emoji: '😼', color: 'text-amber-400' };
    if (score < 50) return { title: 'Playful Teasing Duo', emoji: '💅', color: 'text-pink-400' };
    if (score < 75) return { title: 'Sweetheart Dynamic', emoji: '💖', color: 'text-rose-400' };
    if (score < 90) return { title: 'Adoring AI Partner', emoji: '🥰', color: 'text-red-400' };
    return { title: 'Inseparable Soulmates', emoji: '💍', color: 'text-fuchsia-300' };
  };

  const stage = getStageTitle(affection);

  return (
    <div className="bg-neutral-900/80 backdrop-blur-md border border-neutral-800/90 rounded-2xl p-3 shadow-lg flex flex-col md:flex-row items-center justify-between gap-3">
      {/* Left: Affection & Stage */}
      <div className="flex items-center gap-3 w-full md:w-auto">
        <div className="relative p-2 rounded-xl bg-gradient-to-tr from-rose-500/20 to-pink-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
          <Heart className="w-5 h-5 fill-rose-500 text-rose-500 animate-pulse" />
          {lastDelta !== null && lastDelta !== 0 && (
            <span
              key={Date.now()}
              className={`absolute -top-2 -right-2 text-[10px] font-bold px-1.5 py-0.5 rounded-full border shadow-sm animate-bounce ${
                lastDelta > 0
                  ? 'bg-rose-500 text-white border-rose-400'
                  : 'bg-neutral-800 text-neutral-300 border-neutral-700'
              }`}
            >
              {lastDelta > 0 ? `+${lastDelta}` : lastDelta}
            </span>
          )}
        </div>

        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
              Affection Meter
            </span>
            <span className="text-xs text-neutral-500">·</span>
            <span className={`text-xs font-medium ${stage.color}`}>
              {stage.title} {stage.emoji}
            </span>
          </div>

          <div className="mt-1.5 flex items-center gap-2">
            <div className="w-36 md:w-48 h-2 rounded-full bg-neutral-800 overflow-hidden relative">
              <div
                className="h-full bg-gradient-to-r from-pink-500 via-rose-500 to-red-500 transition-all duration-700 rounded-full"
                style={{ width: `${Math.min(100, Math.max(0, affection))}%` }}
              />
            </div>
            <span className="text-xs font-mono text-neutral-300 font-medium">
              {affection}%
            </span>
          </div>
        </div>
      </div>

      {/* Right: Unlimited Memory Bank Quick Access */}
      <div className="flex items-center gap-2 w-full md:w-auto justify-end">
        <button
          onClick={onOpenMemories}
          className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700/80 border border-neutral-700/60 text-xs font-medium text-neutral-200 hover:text-white transition-all shadow-sm active:scale-95 cursor-pointer"
          title="Open Alisa's Unlimited Memory"
        >
          <Brain className="w-3.5 h-3.5 text-purple-400" />
          <span>Unlimited Memory</span>
          <span className="px-1.5 py-0.2 rounded-md bg-purple-950/80 text-purple-300 border border-purple-800/50 text-[10px] font-mono">
            {memoryCount}
          </span>
        </button>
      </div>
    </div>
  );
};
