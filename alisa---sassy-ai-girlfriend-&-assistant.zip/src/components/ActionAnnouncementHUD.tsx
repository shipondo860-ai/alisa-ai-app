import React, { useState, useEffect } from 'react';
import { Radio, Sparkles, Volume2 } from 'lucide-react';
import { ActionAnnouncement, subscribeToAnnouncements } from '../services/actionAnnouncer';

export const ActionAnnouncementHUD: React.FC = () => {
  const [announcement, setAnnouncement] = useState<ActionAnnouncement | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToAnnouncements((data) => {
      setAnnouncement(data);
    });
    return () => unsubscribe();
  }, []);

  if (!announcement) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 pointer-events-none animate-in fade-in slide-in-from-top duration-200 max-w-lg w-[92%] px-2">
      <div className="bg-neutral-900/95 border border-rose-500/50 shadow-2xl shadow-rose-950/60 rounded-2xl p-3 backdrop-blur-md flex items-center gap-3">
        <div className="p-2 rounded-xl bg-gradient-to-tr from-rose-600 to-pink-500 text-white shadow-md animate-pulse flex-shrink-0">
          <Volume2 className="w-4 h-4" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
              Alisa Voice Announcement
            </span>
            <span className="text-[10px] text-neutral-500 font-mono">
              {announcement.timestamp}
            </span>
          </div>
          <p className="text-sm font-bold text-white mt-0.5 truncate">
            &ldquo;{announcement.bn}&rdquo;
          </p>
          <p className="text-xs text-neutral-400 truncate">
            {announcement.en}
          </p>
        </div>
        <div className="flex items-center gap-0.5 pr-1 flex-shrink-0">
          <span className="w-1 h-3 bg-rose-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <span className="w-1 h-5 bg-pink-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <span className="w-1 h-4 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
      </div>
    </div>
  );
};
