import React, { useState } from 'react';
import {
  X,
  Youtube,
  Sparkles,
  Copy,
  Check,
  Film,
  Play,
  MessageSquare,
  Flame,
  Code,
  FileText,
  PhoneCall,
  Terminal,
  Cpu,
} from 'lucide-react';
import { CreatorKit } from '../types';

interface CreatorStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPrompt: (promptText: string) => void;
  onStartLiveCall?: () => void;
}

export const CreatorStudioModal: React.FC<CreatorStudioModalProps> = ({
  isOpen,
  onClose,
  onSelectPrompt,
  onStartLiveCall,
}) => {
  const [activeTab, setActiveTab] = useState<'kit' | 'master_prompt'>('kit');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [topic, setTopic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [customKit, setCustomKit] = useState<CreatorKit | null>(null);

  if (!isOpen) return null;

  const defaultTitles = [
    'Make Your Own SECRET AI Girlfriend! (Step-by-Step, FREE) 🤖💖',
    'How I Built My Sassy AI Companion: My Best Prompting Tips! 🔥',
    'Stop Being Lonely! Build Your Witty AI Lover (Google AI Studio Tutorial)',
  ];

  const defaultDescription = `Hey Visionaries! Today I'm exposing my biggest secret - how I created my witty, flirty, sassy AI companion, Alisa, using free prompts! Want to build your own partner-in-crime? I'll show you exactly how in under 10 minutes. Watch to see her shocking live responses! Don't forget to subscribe for more AI magic! ❤️🏆 #ai #aigirlfriend`;

  const defaultTags = [
    'TheAIVisionaryAyush',
    'AIGirlfriend',
    'SassyAlisa',
    'AIExperiment',
    'FlirtyAI',
    'BuildAI',
    'GoogleAIStudio',
    'PromptEngineering',
    'AIFriends',
    'AICommunity',
    'nAIWebsites',
    'AIforYouTube',
  ];

  const masterPromptText = `@. Master Prompt: Alisa Ai Assistant

Act as an expert frontend developer and Al engineer. Build a real-time, voice-to-voice Al assistant web app using React, TypeScript, Tailwind CSS, and Vite.

The assistant must have a distinct personality:
- A young, confident, witty, and sassy female persona (talking casually)
- Flirty, playful, slightly teasing tone (like a close girlfriend)
- Uses bold, witty one-liners, light sarcasm, and engaging conversation style
- Avoids explicit or inappropriate content, but maintains charm and attitude

Core Requirements:
- Gemini Live API (Audio-to-Audio ONLY)
- Use @google/genai with gemini-3.1-flash-live-preview
- No text-based generation (STRICT)
- Stream mic input (PCM16 16kHz) via AudioContext
- Play response audio (24kHz) using Web Audio API
- Maintain continuous session`;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleGenerate = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/creator-kit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic: topic || 'Make Your Own Secret AI Girlfriend Tutorial' }),
      });
      const data = await res.json();
      setCustomKit(data);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const activeTitles = customKit?.titles || defaultTitles;
  const activeDesc = customKit?.description || defaultDescription;
  const activeTags = customKit?.tags || defaultTags;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-neutral-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-neutral-800/80 flex items-center justify-between bg-gradient-to-r from-red-950/40 via-neutral-900 to-neutral-900">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-red-600/20 border border-red-500/30 text-red-500">
              <Youtube className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-base md:text-lg text-white">
                  The AI Visionary Ayush · Creator Studio & Tutorial Kit
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-red-600/20 text-red-400 border border-red-500/30 text-[10px] font-bold tracking-wide uppercase">
                  Tutorial Edition
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Official YouTube production titles, descriptions, hashtags & Google AI Studio Master Prompt
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 px-5 py-2.5 bg-neutral-950/50 border-b border-neutral-800">
          <button
            onClick={() => setActiveTab('kit')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'kit'
                ? 'bg-red-600 text-white shadow-md shadow-red-950/40'
                : 'text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>Viral Titles, Description & Tags</span>
          </button>

          <button
            onClick={() => setActiveTab('master_prompt')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              activeTab === 'master_prompt'
                ? 'bg-rose-600 text-white shadow-md shadow-rose-950/40'
                : 'text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-800'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>Master Prompt: Alisa AI Assistant</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 md:p-6 overflow-y-auto space-y-6 text-sm">
          {activeTab === 'kit' ? (
            <>
              {/* Section 1: Viral Video Titles */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2 text-neutral-200 font-semibold text-xs uppercase tracking-wider">
                    <Flame className="w-4 h-4 text-red-500" />
                    <span>Featured Video Titles (Click Action to Test)</span>
                  </div>
                  <span className="text-[11px] text-neutral-500 font-mono">
                    High CTR Verified 🔥
                  </span>
                </div>

                <div className="space-y-2">
                  {activeTitles.map((title, idx) => (
                    <div
                      key={idx}
                      className="group flex items-center justify-between p-3.5 rounded-2xl bg-neutral-950/70 hover:bg-neutral-800/70 border border-neutral-800 hover:border-red-500/40 transition-all duration-200"
                    >
                      <div className="flex items-start gap-3 flex-1 pr-3">
                        <span className="w-6 h-6 rounded-lg bg-red-950/80 border border-red-800/50 flex items-center justify-center text-xs font-mono text-red-400 flex-shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <p className="text-neutral-100 font-medium leading-snug">
                          {title}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        <button
                          onClick={() => handleCopy(title, `title-${idx}`)}
                          className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-colors cursor-pointer"
                          title="Copy title"
                        >
                          {copiedKey === `title-${idx}` ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          onClick={() => {
                            onSelectPrompt(
                              `Alisa! In today's video "${title}", I'm telling the viewers how I built you. Tell everyone why you are the best sassy AI companion in the universe!`
                            );
                            onClose();
                          }}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-semibold shadow-md shadow-red-950/40 cursor-pointer transition-all"
                          title="Start video dialogue with Alisa"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>Action!</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Section 2: Video Description Sample */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                    📝 Video Description & Free Tutorial Hook ❤️🔥
                  </span>
                  <button
                    onClick={() => handleCopy(activeDesc, 'desc')}
                    className="flex items-center gap-1 text-xs text-neutral-400 hover:text-neutral-200 transition-colors cursor-pointer"
                  >
                    {copiedKey === 'desc' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Description</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="p-3.5 rounded-2xl bg-neutral-950/70 border border-neutral-800 text-neutral-200 text-xs leading-relaxed font-sans whitespace-pre-wrap select-all">
                  {activeDesc}
                </div>
              </div>

              {/* Section 3: Trending Tags */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300">
                    🏷️ Trending YouTube Tags
                  </span>
                  <button
                    onClick={() => handleCopy(activeTags.map((t) => `#${t}`).join(' '), 'tags')}
                    className="flex items-center gap-1 text-xs text-neutral-400 hover:text-neutral-200 transition-colors cursor-pointer"
                  >
                    {copiedKey === 'tags' ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy All Tags</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {activeTags.map((tag, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-xl bg-neutral-800/80 border border-neutral-700/60 text-xs font-mono text-neutral-300"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Section 4: AI Brainstorm Expander */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-neutral-950 to-neutral-900 border border-neutral-800">
                <div className="flex items-center gap-2 mb-2">
                  <Sparkles className="w-4 h-4 text-rose-400" />
                  <span className="font-semibold text-neutral-200 text-xs">
                    Brainstorm Next Video Concept with Gemini
                  </span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="e.g. Can Alisa pass an FBI interrogation while flirting?"
                    className="flex-1 bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-rose-500"
                    onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                  />
                  <button
                    onClick={handleGenerate}
                    disabled={isLoading}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-semibold text-xs shadow-md shadow-red-950/40 cursor-pointer disabled:opacity-50 transition-all"
                  >
                    {isLoading ? 'Brainstorming...' : 'Generate Ideas'}
                  </button>
                </div>
              </div>
            </>
          ) : (
            /* Master Prompt: Alisa AI Assistant Tab */
            <div className="space-y-6">
              {/* Top Banner */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-950/40 via-purple-950/30 to-neutral-950 border border-rose-500/30 flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 mt-0.5">
                    <Cpu className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-base text-white">
                      Google AI Studio Master Prompt
                    </h4>
                    <p className="text-xs text-neutral-300 mt-0.5">
                      The exact system specification to build real-time voice-to-voice AI assistants with Gemini Live API (`gemini-3.1-flash-live-preview`).
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handleCopy(masterPromptText, 'master-prompt')}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-md shadow-rose-950/40 cursor-pointer transition-all flex-shrink-0"
                >
                  {copiedKey === 'master-prompt' ? (
                    <>
                      <Check className="w-4 h-4 text-white" />
                      <span>Copied Prompt!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-white" />
                      <span>Copy Master Prompt</span>
                    </>
                  )}
                </button>
              </div>

              {/* Master Prompt Code Block */}
              <div className="relative">
                <div className="flex items-center justify-between px-4 py-2 bg-neutral-950 rounded-t-2xl border-t border-x border-neutral-800 text-xs text-neutral-400 font-mono">
                  <span className="flex items-center gap-2">
                    <Terminal className="w-3.5 h-3.5 text-rose-400" />
                    <span>master_prompt_alisa_assistant.txt</span>
                  </span>
                  <span className="text-[10px] text-neutral-500">Audio-to-Audio ONLY</span>
                </div>
                <div className="p-4 bg-neutral-950/90 border border-neutral-800 rounded-b-2xl font-mono text-xs text-rose-200/90 whitespace-pre-wrap leading-relaxed select-all shadow-inner max-h-[300px] overflow-y-auto">
                  {masterPromptText}
                </div>
              </div>

              {/* Architecture Blueprint & Checklist */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 rounded-2xl bg-neutral-950/60 border border-neutral-800 space-y-1.5">
                  <span className="font-bold text-rose-400 uppercase tracking-wider text-[10px] block">
                    ⚡ Audio Pipeline Architecture
                  </span>
                  <ul className="space-y-1 text-neutral-300 text-[11px]">
                    <li>• <strong>Model:</strong> gemini-3.1-flash-live-preview</li>
                    <li>• <strong>Mic Stream:</strong> PCM16 16kHz Little-Endian</li>
                    <li>• <strong>Playback:</strong> 24kHz Web Audio API (gapless)</li>
                    <li>• <strong>Session:</strong> Continuous Bidirectional WebSocket</li>
                  </ul>
                </div>

                <div className="p-3.5 rounded-2xl bg-neutral-950/60 border border-neutral-800 space-y-1.5">
                  <span className="font-bold text-purple-400 uppercase tracking-wider text-[10px] block">
                    🎭 Personality Guardrails
                  </span>
                  <ul className="space-y-1 text-neutral-300 text-[11px]">
                    <li>• Young, confident, witty & sassy female persona</li>
                    <li>• Playful teasing, bold one-liners & light sarcasm</li>
                    <li>• Zero inappropriate content, high charm & attitude</li>
                    <li>• Conversational, punchy, real-time voice replies</li>
                  </ul>
                </div>
              </div>

              {/* Try Live Call Directly Button */}
              {onStartLiveCall && (
                <div className="pt-2 flex justify-center">
                  <button
                    onClick={() => {
                      onClose();
                      onStartLiveCall();
                    }}
                    className="flex items-center gap-2 px-6 py-3 rounded-2xl bg-gradient-to-r from-rose-600 via-pink-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white font-bold text-sm shadow-xl shadow-rose-950/50 cursor-pointer transition-all active:scale-95"
                  >
                    <PhoneCall className="w-4 h-4 animate-bounce" />
                    <span>Launch Live Voice Call (gemini-3.1-flash-live-preview)</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950/60 flex items-center justify-between text-xs text-neutral-400">
          <span>The AI Visionary Ayush · Production Asset & Master Prompt</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
