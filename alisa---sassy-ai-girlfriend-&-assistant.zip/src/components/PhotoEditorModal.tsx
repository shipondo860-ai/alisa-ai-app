import React, { useState, useRef, useEffect } from 'react';
import {
  Image as ImageIcon,
  X,
  Sliders,
  RotateCw,
  Sparkles,
  Download,
  Check,
  Upload,
} from 'lucide-react';
import {
  PhotoFilterSettings,
  DEFAULT_FILTER_SETTINGS,
  SAMPLE_GALLERY_PHOTOS,
} from '../services/mediaWorkflow';
import { addActivityLog } from '../services/actionLog';
import { announceAction, COMMON_ANNOUNCEMENTS } from '../services/actionAnnouncer';

interface PhotoEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  photoUrl: string | null;
  photoName: string | null;
  onOpenNewPhoto: () => void;
  onSelectPresetPhoto?: (url: string, name: string) => void;
}

export const PhotoEditorModal: React.FC<PhotoEditorModalProps> = ({
  isOpen,
  onClose,
  photoUrl,
  photoName,
  onOpenNewPhoto,
  onSelectPresetPhoto,
}) => {
  const [settings, setSettings] = useState<PhotoFilterSettings>(DEFAULT_FILTER_SETTINGS);
  const [isExporting, setIsExporting] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const activePhoto = photoUrl || SAMPLE_GALLERY_PHOTOS[0].url;
  const activeName = photoName || SAMPLE_GALLERY_PHOTOS[0].name;

  useEffect(() => {
    if (!isOpen) return;
    renderCanvas();
  }, [activePhoto, settings, isOpen]);

  if (!isOpen) return null;

  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = activePhoto;
    img.onload = () => {
      canvas.width = img.naturalWidth || 600;
      canvas.height = img.naturalHeight || 400;

      ctx.save();
      ctx.filter = `brightness(${settings.brightness}%) contrast(${settings.contrast}%) saturate(${settings.saturation}%) sepia(${settings.sepia}%) grayscale(${settings.grayscale}%)`;
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      ctx.restore();

      // Draw sassy watermark/caption overlay
      if (settings.caption) {
        ctx.save();
        ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
        ctx.fillRect(0, canvas.height - 50, canvas.width, 50);

        ctx.font = 'bold 20px "Plus Jakarta Sans", sans-serif';
        ctx.fillStyle = '#f43f5e';
        ctx.fillText(settings.caption, 24, canvas.height - 18);
        ctx.restore();
      }
    };
  };

  const handleExport = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setIsExporting(true);

    try {
      const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `alisa_edited_${activeName}.jpg`;
      a.click();

      const successMsg = `Photo "${activeName}" successfully edited & saved to Android Gallery.`;
      addActivityLog('Save edited photo', 'Media Workflow: Export', 'success', successMsg);
      await announceAction(COMMON_ANNOUNCEMENTS.ACTION_COMPLETED);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-neutral-950/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-neutral-800 flex items-center justify-between bg-gradient-to-r from-pink-950/40 via-neutral-900 to-neutral-900">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-pink-600/20 border border-pink-500/30 text-pink-400">
              <ImageIcon className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-base md:text-lg text-white">
                  Alisa Photo Editor & Gallery Workflow
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 text-[10px] font-mono">
                  {activeName}
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Module 5: Media & Photo Editing with authorized UI controls.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Area: Photo Canvas + Controls */}
        <div className="p-4 md:p-6 overflow-y-auto flex-1 flex flex-col lg:flex-row gap-6">
          {/* Left Canvas Preview */}
          <div className="flex-1 flex flex-col items-center justify-center bg-neutral-950/80 rounded-2xl border border-neutral-800 p-4 min-h-[300px]">
            <canvas
              ref={canvasRef}
              className="max-h-[360px] max-w-full rounded-xl object-contain shadow-lg"
            />

            {/* Quick Preset Selector */}
            <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
              <span className="text-[10px] text-neutral-400 font-semibold">Test Presets:</span>
              {SAMPLE_GALLERY_PHOTOS.map((sample) => (
                <button
                  key={sample.id}
                  onClick={() => {
                    if (onSelectPresetPhoto) onSelectPresetPhoto(sample.url, sample.name);
                  }}
                  className={`px-2.5 py-1 rounded-xl text-[10px] font-medium border transition-colors cursor-pointer ${
                    activeName === sample.name
                      ? 'bg-pink-600/30 text-pink-300 border-pink-500/40'
                      : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                  }`}
                >
                  {sample.title.split(':')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Right Editing Controls */}
          <div className="w-full lg:w-80 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-neutral-300 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-pink-400" />
                <span>Adjustments</span>
              </span>
              <button
                onClick={() => setSettings(DEFAULT_FILTER_SETTINGS)}
                className="text-[11px] text-neutral-500 hover:text-neutral-300 cursor-pointer"
              >
                Reset
              </button>
            </div>

            {/* Brightness */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-neutral-400">
                <span>Brightness</span>
                <span className="font-mono">{settings.brightness}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="150"
                value={settings.brightness}
                onChange={(e) => setSettings({ ...settings, brightness: Number(e.target.value) })}
                className="w-full accent-pink-500 cursor-pointer"
              />
            </div>

            {/* Contrast */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-neutral-400">
                <span>Contrast</span>
                <span className="font-mono">{settings.contrast}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="150"
                value={settings.contrast}
                onChange={(e) => setSettings({ ...settings, contrast: Number(e.target.value) })}
                className="w-full accent-pink-500 cursor-pointer"
              />
            </div>

            {/* Saturation */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs text-neutral-400">
                <span>Saturation</span>
                <span className="font-mono">{settings.saturation}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="200"
                value={settings.saturation}
                onChange={(e) => setSettings({ ...settings, saturation: Number(e.target.value) })}
                className="w-full accent-pink-500 cursor-pointer"
              />
            </div>

            {/* Sepia & Grayscale */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                onClick={() =>
                  setSettings((prev) => ({ ...prev, sepia: prev.sepia > 0 ? 0 : 70, grayscale: 0 }))
                }
                className={`py-2 px-3 rounded-xl border text-xs font-medium cursor-pointer transition-colors ${
                  settings.sepia > 0
                    ? 'bg-amber-900/40 text-amber-300 border-amber-500/40'
                    : 'bg-neutral-950 text-neutral-400 border-neutral-800'
                }`}
              >
                Vintage Sepia
              </button>

              <button
                onClick={() =>
                  setSettings((prev) => ({ ...prev, grayscale: prev.grayscale > 0 ? 0 : 100, sepia: 0 }))
                }
                className={`py-2 px-3 rounded-xl border text-xs font-medium cursor-pointer transition-colors ${
                  settings.grayscale > 0
                    ? 'bg-neutral-800 text-white border-neutral-600'
                    : 'bg-neutral-950 text-neutral-400 border-neutral-800'
                }`}
              >
                B&W Noir
              </button>
            </div>

            {/* Caption Overlay */}
            <div className="space-y-1 pt-2">
              <span className="text-xs text-neutral-400 block">Caption Overlay:</span>
              <input
                type="text"
                value={settings.caption}
                onChange={(e) => setSettings({ ...settings, caption: e.target.value })}
                placeholder="Caption text"
                className="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-3 py-2 text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-pink-500"
              />
            </div>

            {/* Actions */}
            <div className="pt-3 space-y-2">
              <button
                onClick={handleExport}
                disabled={isExporting}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white font-bold text-xs shadow-lg shadow-pink-950/40 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>Save to Android Gallery</span>
              </button>

              <button
                onClick={onOpenNewPhoto}
                className="w-full py-2.5 rounded-2xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Choose From File Picker</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950/60 flex items-center justify-between text-xs text-neutral-400">
          <span>Protected Android storage workflow · Zero unauthorized access</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
