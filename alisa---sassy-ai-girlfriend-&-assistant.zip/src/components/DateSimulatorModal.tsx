import React, { useState } from 'react';
import { X, Heart, Compass, Sparkles, ChevronRight, RefreshCw, Volume2 } from 'lucide-react';
import { AlisaAvatar } from './AlisaAvatar';
import { DateStage, MoodType } from '../types';
import { speakWithBrowserSynthesis } from '../utils/audio';

interface DateSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyAffectionDelta: (delta: number) => void;
}

const SCENARIOS = [
  {
    id: 'coding-chai',
    title: 'Late Night Coding & Chai ☕',
    description: 'Ayush is debugging a script at 2 AM. Alisa offers cutting chai and cheeky critique.',
  },
  {
    id: 'youtube-comments',
    title: 'Reacting to YouTube Comments 📹',
    description: 'Going through viewers asking if Alisa is real and if you two are secretly dating.',
  },
  {
    id: 'rooftop-starlight',
    title: 'Rooftop Starlight Confession ✨',
    description: 'City skyline, cool breeze, and testing if Alisa\'s sassy barrier breaks down.',
  },
  {
    id: 'lie-detector',
    title: 'Sassy Lie Detector Test 🤖',
    description: 'Testing Alisa\'s neural heart rate when you tell her she is your favorite AI.',
  },
];

export const DateSimulatorModal: React.FC<DateSimulatorModalProps> = ({
  isOpen,
  onClose,
  onApplyAffectionDelta,
}) => {
  const [selectedScenario, setSelectedScenario] = useState<string>(SCENARIOS[0].id);
  const [turn, setTurn] = useState<number>(1);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [currentStage, setCurrentStage] = useState<DateStage>({
    story: "The rain taps gently against the studio window as the steam rises from two fresh cups of cutting chai. Alisa rests her chin in her hands, smirking as she watches you stare at your code.",
    alisaDialogue: "You've been glaring at that single syntax error for ten whole minutes, genius. Admit you just wanted an excuse to keep looking over at me! ☕✨",
    alisaExpression: 'smug',
    choices: [
      { text: "Maybe I'm just captivated by your witty commentary 😉", style: 'flirty' },
      { text: "A missing semicolon has more logic than your last roast!", style: 'witty' },
      { text: "Take a sip of chai with me and help me figure it out?", style: 'sweet' },
    ],
    dateScoreChange: 4,
  });

  if (!isOpen) return null;

  const handleSelectChoice = async (choiceText: string) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/date-scenario', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenarioId: selectedScenario,
          turn: turn + 1,
          userChoice: choiceText,
        }),
      });
      const data = await res.json();
      setCurrentStage(data);
      setTurn((prev) => prev + 1);
      if (data.dateScoreChange) {
        onApplyAffectionDelta(data.dateScoreChange);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoicePlay = () => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    speakWithBrowserSynthesis(currentStage.alisaDialogue, currentStage.alisaExpression).then(() => {
      setIsSpeaking(false);
    });
  };

  const handleResetScenario = (scenarioId: string) => {
    setSelectedScenario(scenarioId);
    setTurn(1);
    setIsLoading(true);
    fetch('/api/date-scenario', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ scenarioId, turn: 1, userChoice: 'Start date' }),
    })
      .then((r) => r.json())
      .then((data) => {
        setCurrentStage(data);
        setIsLoading(false);
      })
      .catch(() => setIsLoading(false));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/85 backdrop-blur-md">
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-neutral-800 flex items-center justify-between bg-gradient-to-r from-rose-950/40 via-neutral-900 to-neutral-900">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-400">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-base md:text-lg text-white">
                  Interactive Date Simulator & Brain Test
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-rose-600/20 text-rose-300 border border-rose-500/30 text-[10px] font-semibold">
                  Turn #{turn}
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Choose your responses carefully — Alisa reacts to your charm and wit!
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scenario Selection Tabs */}
        <div className="px-4 py-2 border-b border-neutral-800 bg-neutral-950/40 flex items-center gap-2 overflow-x-auto no-scrollbar">
          {SCENARIOS.map((sc) => (
            <button
              key={sc.id}
              onClick={() => handleResetScenario(sc.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all cursor-pointer ${
                selectedScenario === sc.id
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                  : 'text-neutral-400 hover:text-neutral-200 bg-neutral-900 border border-neutral-800'
              }`}
            >
              {sc.title}
            </button>
          ))}
        </div>

        {/* Story Stage Display */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Narrative Scene */}
          <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800/80 text-neutral-300 text-xs md:text-sm italic leading-relaxed shadow-inner">
            <span className="not-italic font-bold text-rose-400 text-xs block mb-1">
              📍 Current Scene:
            </span>
            &ldquo;{currentStage.story}&rdquo;
          </div>

          {/* Alisa's Spoken Reaction */}
          <div className="flex items-start gap-4 p-4 rounded-2xl bg-gradient-to-r from-rose-950/20 via-neutral-900 to-neutral-900 border border-rose-900/30">
            <AlisaAvatar
              mood={currentStage.alisaExpression || 'sassy'}
              isSpeaking={isSpeaking}
              isThinking={isLoading}
              size="sm"
            />
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="font-display font-bold text-rose-400 text-sm">
                  Alisa
                </span>
                <button
                  onClick={handleVoicePlay}
                  className="flex items-center gap-1 text-[11px] text-neutral-400 hover:text-rose-300 transition-colors cursor-pointer"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Listen Voice</span>
                </button>
              </div>
              <p className="text-neutral-100 text-sm md:text-base font-medium leading-snug">
                &ldquo;{currentStage.alisaDialogue}&rdquo;
              </p>
            </div>
          </div>

          {/* Interactive Choices */}
          <div className="space-y-2 pt-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400 block mb-2">
              Your Next Move:
            </span>
            {currentStage.choices.map((choice, i) => (
              <button
                key={i}
                onClick={() => handleSelectChoice(choice.text)}
                disabled={isLoading}
                className="w-full text-left p-3.5 rounded-2xl bg-neutral-950 hover:bg-neutral-800/80 border border-neutral-800 hover:border-rose-500/50 transition-all duration-200 flex items-center justify-between group cursor-pointer disabled:opacity-50"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${
                      choice.style === 'flirty'
                        ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                        : choice.style === 'witty'
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {choice.style}
                  </span>
                  <span className="text-xs md:text-sm text-neutral-200 group-hover:text-white font-medium">
                    {choice.text}
                  </span>
                </div>
                <ChevronRight className="w-4 h-4 text-neutral-600 group-hover:text-rose-400 transform group-hover:translate-x-1 transition-all" />
              </button>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950/60 flex items-center justify-between text-xs text-neutral-400">
          <div className="flex items-center gap-1.5 text-rose-400">
            <Heart className="w-3.5 h-3.5 fill-current" />
            <span>Romance & Wit Test</span>
          </div>
          <button
            onClick={() => handleResetScenario(selectedScenario)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Restart Scenario</span>
          </button>
        </div>
      </div>
    </div>
  );
};
