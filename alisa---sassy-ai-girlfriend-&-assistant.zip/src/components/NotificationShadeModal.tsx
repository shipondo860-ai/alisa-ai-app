import React, { useState, useEffect } from 'react';
import {
  Bell,
  X,
  ShieldCheck,
  Eye,
  EyeOff,
  Volume2,
  RefreshCw,
  PlusCircle,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import {
  MOCK_NOTIFICATIONS,
  AndroidNotificationItem,
  readAndSummarizeNotifications,
} from '../services/notificationService';
import { isPermissionGranted, requestAndroidPermission } from '../services/permissionCenter';

interface NotificationShadeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNotificationSpoken?: (summary: string) => void;
}

export const NotificationShadeModal: React.FC<NotificationShadeModalProps> = ({
  isOpen,
  onClose,
  onNotificationSpoken,
}) => {
  const [notifications, setNotifications] = useState<AndroidNotificationItem[]>(MOCK_NOTIFICATIONS);
  const [hasPermission, setHasPermission] = useState<boolean>(false);
  const [summaryResult, setSummaryResult] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);

  const checkPerm = async () => {
    const granted = await isPermissionGranted('notifications');
    setHasPermission(granted);
  };

  useEffect(() => {
    if (isOpen) {
      checkPerm();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleGrantPermission = async () => {
    const res = await requestAndroidPermission('notifications');
    setHasPermission(res.success);
  };

  const handleSummarize = async () => {
    setIsSummarizing(true);
    try {
      const res = await readAndSummarizeNotifications('Read and summarize notifications');
      setSummaryResult(res.summary);
      if (onNotificationSpoken) {
        onNotificationSpoken(res.summary);
      }
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleSimulateNew = () => {
    const newNotif: AndroidNotificationItem = {
      id: `notif-${Date.now()}`,
      appName: 'YouTube Studio',
      appIcon: '📹',
      sender: 'Ayush (Creator)',
      title: 'Alisa Video Premiering Soon!',
      summary: 'Alisa Sassy AI Girlfriend test video goes live in 30 minutes.',
      timestamp: 'Just now',
      isSensitive: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-neutral-950/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-neutral-800 flex items-center justify-between bg-gradient-to-r from-amber-950/40 via-neutral-900 to-neutral-900">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-600/20 border border-amber-500/30 text-amber-400">
              <Bell className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-base md:text-lg text-white">
                  Android Notification Access Shade
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-mono">
                  {notifications.length} Pending
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Module 6: Privacy-first summary engine · Sensitive contents masked.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Permission Banner if not granted */}
        {!hasPermission && (
          <div className="p-4 bg-amber-950/40 border-b border-amber-500/30 flex items-center justify-between gap-3 text-xs text-amber-300">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <span>Notification access is not enabled. Grant permission to read alerts.</span>
            </div>
            <button
              onClick={handleGrantPermission}
              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold transition-colors cursor-pointer flex-shrink-0"
            >
              Grant Access
            </button>
          </div>
        )}

        {/* Action Controls */}
        <div className="p-3 bg-neutral-950/60 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={handleSummarize}
              disabled={isSummarizing || !hasPermission}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-neutral-950 font-bold transition-all cursor-pointer shadow-md shadow-amber-950/40"
            >
              <Volume2 className="w-4 h-4" />
              <span>{isSummarizing ? 'Alisa Reading...' : 'Alisa: Read & Summarize'}</span>
            </button>

            <button
              onClick={handleSimulateNew}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
              <span>Simulate Incoming Alert</span>
            </button>
          </div>

          <div className="flex items-center gap-1 text-[11px] text-neutral-400 font-mono">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Privacy Guard Active</span>
          </div>
        </div>

        {/* Spoken summary callout if produced */}
        {summaryResult && (
          <div className="p-3.5 bg-neutral-950 border-b border-amber-500/20 text-xs">
            <span className="font-bold text-amber-400 block mb-1">
              🎙️ Alisa Voice Summary:
            </span>
            <p className="text-neutral-200 italic font-sans leading-relaxed">
              &ldquo;{summaryResult}&rdquo;
            </p>
          </div>
        )}

        {/* Notifications List */}
        <div className="p-4 md:p-6 overflow-y-auto space-y-3 flex-1">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800 hover:border-neutral-700 transition-colors flex items-start gap-3.5"
            >
              <div className="text-2xl p-2 rounded-xl bg-neutral-900 border border-neutral-800 flex-shrink-0">
                {notif.appIcon}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-neutral-200 text-xs">
                      {notif.appName}
                    </span>
                    <span className="text-[10px] text-neutral-500">· {notif.timestamp}</span>
                  </div>

                  {notif.isSensitive ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 text-[10px] font-mono">
                      <EyeOff className="w-3 h-3" />
                      <span>SENSITIVE</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-400 text-[10px] font-mono">
                      <Eye className="w-3 h-3" />
                      <span>STANDARD</span>
                    </span>
                  )}
                </div>

                <h4 className="font-bold text-sm text-neutral-100 mt-1">
                  {notif.title}
                </h4>

                <p className="text-xs text-neutral-400 mt-0.5 leading-snug">
                  {notif.isSensitive ? 'Private sender details protected by Alisa.' : notif.summary}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950/60 flex items-center justify-between text-xs text-neutral-400">
          <span>Android NotificationListenerService protocol compliant</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
