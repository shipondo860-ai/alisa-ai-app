import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  X,
  Mic,
  Phone,
  BookUser,
  Bell,
  Eye,
  Camera,
  Image,
  Bluetooth,
  MapPin,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RefreshCw,
  ExternalLink,
  PackageCheck,
} from 'lucide-react';
import { AndroidPermissionItem, AndroidPermissionKey, PermissionState } from '../types/assistant';
import { getAndroidPermissions, requestAndroidPermission, toggleAndroidPermission } from '../services/permissionCenter';

interface PermissionCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PermissionCenterModal: React.FC<PermissionCenterModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [permissions, setPermissions] = useState<AndroidPermissionItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const fetchPermissions = async () => {
    setIsLoading(true);
    try {
      const data = await getAndroidPermissions();
      setPermissions(data);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchPermissions();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleToggle = async (key: AndroidPermissionKey, currentStatus: PermissionState) => {
    setActionMessage(null);
    if (currentStatus === 'granted') {
      const res = await toggleAndroidPermission(key);
      setActionMessage(res.message);
    } else {
      const res = await requestAndroidPermission(key);
      setActionMessage(res.message);
    }
    await fetchPermissions();
  };

  const getPermissionIcon = (key: AndroidPermissionKey) => {
    switch (key) {
      case 'microphone':
        return <Mic className="w-5 h-5 text-rose-400" />;
      case 'phone':
        return <Phone className="w-5 h-5 text-emerald-400" />;
      case 'contacts':
        return <BookUser className="w-5 h-5 text-blue-400" />;
      case 'notifications':
        return <Bell className="w-5 h-5 text-amber-400" />;
      case 'accessibility':
        return <Eye className="w-5 h-5 text-purple-400" />;
      case 'camera':
        return <Camera className="w-5 h-5 text-cyan-400" />;
      case 'photos_files':
        return <Image className="w-5 h-5 text-pink-400" />;
      case 'bluetooth':
        return <Bluetooth className="w-5 h-5 text-indigo-400" />;
      case 'location':
        return <MapPin className="w-5 h-5 text-teal-400" />;
      case 'install_unknown_apps':
        return <PackageCheck className="w-5 h-5 text-emerald-400" />;
    }
  };

  const renderBadge = (status: PermissionState) => {
    if (status === 'granted') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold uppercase tracking-wider">
          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
          <span>GRANTED</span>
        </span>
      );
    }
    if (status === 'denied') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-500/30 text-[10px] font-bold uppercase tracking-wider">
          <XCircle className="w-3 h-3 text-red-400" />
          <span>DENIED</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-neutral-800 text-neutral-400 border border-neutral-700 text-[10px] font-bold uppercase tracking-wider">
        <HelpCircle className="w-3 h-3 text-neutral-400" />
        <span>NOT REQUIRED</span>
      </span>
    );
  };

  const grantedCount = permissions.filter((p) => p.status === 'granted').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-neutral-950/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-neutral-800 flex items-center justify-between bg-gradient-to-r from-purple-950/40 via-neutral-900 to-neutral-900">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-purple-600/20 border border-purple-500/30 text-purple-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-base md:text-lg text-white">
                  Android Assistant Permission Center
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-semibold">
                  {grantedCount} of {permissions.length} Active
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Privacy-first authorization. Never bypasses native Android permission dialogs.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action feedback toast */}
        {actionMessage && (
          <div className="px-6 py-2.5 bg-neutral-950/80 border-b border-neutral-800 text-xs text-rose-300 flex items-center justify-between">
            <span>{actionMessage}</span>
            <button
              onClick={() => setActionMessage(null)}
              className="text-neutral-500 hover:text-neutral-300"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Content list */}
        <div className="p-4 md:p-6 overflow-y-auto space-y-3 flex-1">
          {isLoading ? (
            <div className="py-12 text-center text-xs text-neutral-500 flex items-center justify-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-purple-400" />
              <span>Querying Android hardware & web permissions...</span>
            </div>
          ) : (
            permissions.map((perm) => (
              <div
                key={perm.key}
                className="p-4 rounded-2xl bg-neutral-950/70 border border-neutral-800/80 hover:border-neutral-700 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3 flex-1">
                  <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 mt-0.5">
                    {getPermissionIcon(perm.key)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-semibold text-neutral-100 text-sm">
                        {perm.name}
                      </h4>
                      {renderBadge(perm.status)}
                    </div>
                    <p className="text-xs text-neutral-400 mt-0.5 leading-snug">
                      {perm.description}
                    </p>
                    <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[10px]">
                      <span className="font-mono text-neutral-500">
                        {perm.androidPermission}
                      </span>
                      <span className="text-neutral-600">·</span>
                      <span className="text-neutral-400">
                        Required for: {perm.isRequiredFor.join(', ')}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Toggle / Request button */}
                <div className="flex items-center gap-2 self-end sm:self-center flex-shrink-0">
                  <button
                    onClick={() => handleToggle(perm.key, perm.status)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      perm.status === 'granted'
                        ? 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                        : 'bg-gradient-to-r from-purple-600 to-rose-600 hover:from-purple-500 hover:to-rose-500 text-white shadow-md shadow-purple-950/40'
                    }`}
                  >
                    {perm.status === 'granted' ? 'Revoke / Toggle' : 'Grant Permission'}
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-950/60 flex items-center justify-between text-xs text-neutral-400">
          <span>Android 14+ Security Sandboxing Compliant</span>
          <button
            onClick={fetchPermissions}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Re-check Permissions</span>
          </button>
        </div>
      </div>
    </div>
  );
};
