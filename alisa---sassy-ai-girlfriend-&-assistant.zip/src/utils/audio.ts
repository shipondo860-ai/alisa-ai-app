/**
 * Audio helpers for Myraa's natural voice & speech synthesis
 * Target Voice: Soft, Gentle, Warm, Natural, Clear, Expressive, Friendly, Slightly Playful
 * Avoids: robotic delivery, monotone delivery, corporate assistant style, excessively deep voice
 * Uses natural pauses and standard unsupported pitch avoidance.
 */

let activeAudioSource: AudioBufferSourceNode | null = null;
let activeGainNode: GainNode | null = null;
let audioContext: AudioContext | null = null;

/**
 * Deduplication Guard State
 * Enforces: ONE USER TURN -> ONE MODEL RESPONSE -> ONE AUDIO PLAYBACK
 */
const playedResponseIds = new Set<string>();
const recentPlaybackHashes = new Map<string, number>();
let activePlaybackTurnId: string | null = null;
let isPlaybackActive = false;

/**
 * Generates a cryptographically strong unique turn ID for every user turn
 */
export function generateTurnId(): string {
  return `turn_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

/**
 * Checks if a turn/response ID has already been played or claimed
 */
export function isTurnAlreadyPlayed(turnId: string): boolean {
  if (!turnId) return false;
  return playedResponseIds.has(turnId) || activePlaybackTurnId === turnId;
}

/**
 * Logs DUPLICATE_RESPONSE_BLOCKED and dispatches event
 */
function logDuplicateBlocked(reason: string, turnId?: string, detail?: string) {
  console.warn(`[DEDUPLICATION_GUARD] DUPLICATE_RESPONSE_BLOCKED: ${reason}`, { turnId, detail });
  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('myraa:duplicate_blocked', {
        detail: {
          turnId,
          reason,
          detail,
          timestamp: Date.now(),
        },
      })
    );
  }
}

/**
 * Claims a turn ID for audio playback.
 * Returns true if playback can proceed, or false if blocked as duplicate.
 */
export function claimTurnPlayback(turnId?: string, contentIdentifier?: string): boolean {
  const now = Date.now();

  // 1. If explicit turnId is provided and already played or playing, BLOCK duplicate
  if (turnId) {
    if (playedResponseIds.has(turnId)) {
      logDuplicateBlocked('Turn ID was already processed and played', turnId);
      stopCurrentAudio();
      return false;
    }
    if (activePlaybackTurnId === turnId) {
      logDuplicateBlocked('Turn ID is currently actively playing', turnId);
      stopCurrentAudio();
      return false;
    }
  }

  // 2. Prevent identical speech / audio hash playback within 3500ms
  if (contentIdentifier && contentIdentifier.trim().length > 3) {
    const hash = contentIdentifier.trim().toLowerCase().slice(0, 150);
    const lastPlayed = recentPlaybackHashes.get(hash);
    if (lastPlayed && now - lastPlayed < 3500) {
      logDuplicateBlocked('Identical audio response detected within cooldown window', turnId, hash);
      stopCurrentAudio();
      return false;
    }
    recentPlaybackHashes.set(hash, now);

    // Prune stale hashes older than 15s
    if (recentPlaybackHashes.size > 50) {
      for (const [h, time] of recentPlaybackHashes.entries()) {
        if (now - time > 15000) recentPlaybackHashes.delete(h);
      }
    }
  }

  // 3. Prevent overlapping audio playback from multiple parallel handlers
  if (isPlaybackActive) {
    // If a different playback is actively playing, safely stop the previous one
    stopCurrentAudio();
  }

  // Register turn
  if (turnId) {
    playedResponseIds.add(turnId);
    activePlaybackTurnId = turnId;
  }
  isPlaybackActive = true;

  // Keep set bounded to last 200 turns
  if (playedResponseIds.size > 200) {
    const arr = Array.from(playedResponseIds);
    arr.slice(0, 50).forEach((id) => playedResponseIds.delete(id));
  }

  return true;
}

/**
 * Releases the active turn playback claim when playback ends
 */
export function releaseTurnPlayback(turnId?: string) {
  if (turnId && activePlaybackTurnId === turnId) {
    activePlaybackTurnId = null;
  }
  isPlaybackActive = false;
}

/**
 * Clears playback history (e.g., when a fresh session is deliberately initiated)
 */
export function resetPlaybackDeduplication() {
  playedResponseIds.clear();
  recentPlaybackHashes.clear();
  activePlaybackTurnId = null;
  isPlaybackActive = false;
}

/**
 * Gets or initializes the shared AudioContext safely handling suspended states
 */
export async function getOrCreateAudioContext(sampleRate = 24000): Promise<AudioContext> {
  if (!audioContext || audioContext.state === 'closed') {
    audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({
      sampleRate,
    });
  }

  if (audioContext.state === 'suspended') {
    try {
      await audioContext.resume();
    } catch (e) {
      console.warn('AudioContext resume notice:', e);
    }
  }

  return audioContext;
}

export function stopCurrentAudio() {
  if (activeGainNode && audioContext) {
    try {
      // Fast 15ms gentle fade out to avoid clicks
      activeGainNode.gain.setValueAtTime(activeGainNode.gain.value, audioContext.currentTime);
      activeGainNode.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.015);
    } catch {}
  }

  if (activeAudioSource) {
    try {
      activeAudioSource.stop();
      activeAudioSource.disconnect();
    } catch {
      // already stopped
    }
    activeAudioSource = null;
  }
  activeGainNode = null;

  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

/**
 * Plays high-fidelity PCM audio with smooth envelope and gapless decoding
 * Strictly enforces: ONE USER TURN -> ONE MODEL RESPONSE -> ONE AUDIO PLAYBACK
 */
export async function playPcmAudio(base64: string, sampleRate = 24000, turnId?: string): Promise<boolean> {
  // Deduplication check
  if (!claimTurnPlayback(turnId, base64.slice(0, 100))) {
    return false;
  }

  stopCurrentAudio();

  try {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    const int16Array = new Int16Array(bytes.buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 32768.0;
    }

    const ctx = await getOrCreateAudioContext(sampleRate);

    const buffer = ctx.createBuffer(1, float32Array.length, sampleRate);
    buffer.copyToChannel(float32Array, 0);

    const source = ctx.createBufferSource();
    source.buffer = buffer;

    // Gain envelope to avoid speaker pops
    const gainNode = ctx.createGain();
    const now = ctx.currentTime;
    gainNode.gain.setValueAtTime(0, now);
    gainNode.gain.linearRampToValueAtTime(1.0, now + 0.008); // 8ms soft attack

    // Soft decay at buffer end
    if (buffer.duration > 0.03) {
      gainNode.gain.setValueAtTime(1.0, now + buffer.duration - 0.012);
      gainNode.gain.linearRampToValueAtTime(0.001, now + buffer.duration);
    }

    source.connect(gainNode);
    gainNode.connect(ctx.destination);

    activeAudioSource = source;
    activeGainNode = gainNode;
    source.start(0);

    return new Promise((resolve) => {
      source.onended = () => {
        if (activeAudioSource === source) {
          activeAudioSource = null;
          activeGainNode = null;
        }
        releaseTurnPlayback(turnId);
        resolve(true);
      };
    });
  } catch (err) {
    releaseTurnPlayback(turnId);
    console.error('Failed to decode/play PCM audio:', err);
    throw err;
  }
}

/**
 * High-quality conversational SpeechSynthesis fallback
 * Formatted for soft, gentle, warm, and natural human delivery.
 * Strictly enforces: ONE USER TURN -> ONE MODEL RESPONSE -> ONE AUDIO PLAYBACK
 */
export function speakWithBrowserSynthesis(text: string, mood = 'flirty', turnId?: string): Promise<boolean> {
  // Deduplication check
  if (!claimTurnPlayback(turnId, text)) {
    return Promise.resolve(false);
  }

  stopCurrentAudio();

  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      releaseTurnPlayback(turnId);
      resolve(true);
      return;
    }

    // Clean text: strip emojis, asterisks, brackets, and system prompts
    const clean = text
      .replace(/[*_~`#]/g, '')
      .replace(/\[.*?\]/g, '')
      .replace(/\(.*?\)/g, '')
      .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
      .trim();

    if (!clean) {
      releaseTurnPlayback(turnId);
      resolve(true);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(clean);

    // Pick the most natural, soft female voice available on the device
    const voices = window.speechSynthesis.getVoices();
    const gentleFemaleVoice =
      voices.find(
        (v) =>
          (v.name.includes('Google UK English Female') ||
            v.name.includes('Natural') ||
            v.name.includes('Jenny') ||
            v.name.includes('Samantha') ||
            v.name.includes('Victoria') ||
            v.name.includes('Karen') ||
            v.name.includes('Female')) &&
          v.lang.startsWith('en')
      ) ||
      voices.find((v) => v.lang.startsWith('en') && !v.name.includes('David') && !v.name.includes('Mark')) ||
      voices.find((v) => v.lang.startsWith('en'));

    if (gentleFemaleVoice) {
      utterance.voice = gentleFemaleVoice;
    }

    // Natural parameters: standard supported pitch (avoid distortion/chipmunk), pleasant conversational rate
    utterance.pitch = 1.0; // Standard pitch to preserve natural timbre
    utterance.rate = 0.98; // Relaxed, soft, pleasant cadence for long conversations

    // Subtle emotional inflection without forcing unsupported pitch
    if (mood === 'loving' || mood === 'flirty') {
      utterance.rate = 0.96;
    } else if (mood === 'playful' || mood === 'sassy') {
      utterance.rate = 1.0;
    }

    utterance.onend = () => {
      releaseTurnPlayback(turnId);
      resolve(true);
    };
    utterance.onerror = () => {
      releaseTurnPlayback(turnId);
      resolve(false);
    };

    window.speechSynthesis.speak(utterance);
  });
}
