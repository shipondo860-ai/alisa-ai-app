/**
 * Android Assistant Control Architecture - Type Definitions
 */

export type AndroidPermissionKey =
  | 'microphone'
  | 'phone'
  | 'contacts'
  | 'notifications'
  | 'accessibility'
  | 'camera'
  | 'photos_files'
  | 'bluetooth'
  | 'location'
  | 'install_unknown_apps';

export type PermissionState = 'granted' | 'denied' | 'prompt' | 'restricted';

export interface AndroidPermissionItem {
  key: AndroidPermissionKey;
  name: string;
  androidPermission: string;
  description: string;
  status: PermissionState;
  isRequiredFor: string[];
}

export interface AndroidApp {
  id: string;
  name: string;
  category: 'social' | 'media' | 'system' | 'communication' | 'tools';
  packageName: string;
  intentUrl: string;
  webFallbackUrl: string;
  icon: string;
  aliases: string[];
}

export type AccessibilityActionType =
  | 'tap'
  | 'scroll_down'
  | 'scroll_up'
  | 'back'
  | 'navigate'
  | 'type_text';

export interface AccessibilityActionRequest {
  type: AccessibilityActionType;
  target?: string;
  value?: string;
}

export interface ConfirmationRequest {
  id: string;
  title: string;
  description: string;
  impactLevel: 'medium' | 'high' | 'critical';
  actionType: 'call' | 'message' | 'delete' | 'setting' | 'system';
  targetDetails: {
    recipient?: string;
    phoneNumber?: string;
    messageBody?: string;
    settingKey?: string;
    additionalInfo?: string;
  };
  onConfirm: () => Promise<void> | void;
  onCancel: () => void;
}

export interface AssistantActivityLog {
  id: string;
  timestamp: string;
  timeFormatted: string; // e.g. "20:41"
  userSpeech: string;
  actionSummary: string;
  resultStatus: 'success' | 'failed' | 'cancelled' | 'pending_confirmation';
  resultMessage: string;
  details?: string;
}

export interface VoiceCommandParseResult {
  isSystemCommand: boolean;
  module?: 'launcher' | 'call' | 'message' | 'media' | 'accessibility' | 'notification' | 'permission' | 'log';
  action?: string;
  parameters?: Record<string, any>;
  spokenAnnouncement?: {
    bn: string;
    en: string;
  };
  requiresConfirmation?: boolean;
  confirmationDetails?: Partial<ConfirmationRequest>;
}
