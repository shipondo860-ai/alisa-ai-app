export type MoodType =
  | 'sassy'
  | 'flirty'
  | 'blushing'
  | 'smug'
  | 'loving'
  | 'pouty'
  | 'shocked'
  | 'playful';

export type PersonaType = 'sassy' | 'flirty' | 'tsundere' | 'sweet' | 'cohost';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  mood?: MoodType;
  innerMonologue?: string;
  affectionDelta?: number;
  audioBase64?: string;
}

export interface UserProfile {
  name: string;
  nickname: string;
  interests: string[];
}

export interface DateChoice {
  text: string;
  style: 'flirty' | 'witty' | 'sweet';
}

export interface DateStage {
  story: string;
  alisaDialogue: string;
  alisaExpression: MoodType;
  choices: DateChoice[];
  dateScoreChange: number;
}

export interface CreatorKit {
  titles: string[];
  description: string;
  tags: string[];
  thumbnailConcepts: string[];
  introScript: Array<{ speaker: string; text: string }>;
}
