/**
 * Alisa APK Installer Module - Type Definitions
 * Meets Android 15 PackageInstaller & Content URI Security Requirements
 */

export interface ApkMetadata {
  fileName: string;
  fileSizeBytes: number;
  fileSizeFormatted: string;
  packageName: string | null;
  appName: string | null;
  versionName: string | null;
  versionCode: number | null;
  minSdkVersion: number | null;
  targetSdkVersion: number | null;
  permissionsDetected: string[];
  isSafelyParsed: boolean;
  parseNotes?: string;
  signatureScheme?: string;
  rawFile?: File;
}

export type InstallerStatus =
  | 'idle'
  | 'APK selected'
  | 'Preparing installer...'
  | 'Waiting for Android confirmation...'
  | 'Installation completed'
  | 'Installation cancelled'
  | 'Installation failed';

export type RuntimeEnvironment = 'web_preview' | 'android_bridge';

export interface ApkInstallSession {
  sessionId?: string;
  apk: ApkMetadata;
  status: InstallerStatus;
  startedAt: string;
  finishedAt?: string;
  message?: string;
}
